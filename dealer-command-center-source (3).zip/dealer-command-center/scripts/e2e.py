"""End-to-end browser test. Usage: python3 scripts/e2e.py [url] [fixtures_dir]"""
import sys, re, json, time
from playwright.sync_api import sync_playwright
URL = sys.argv[1] if len(sys.argv) > 1 else "http://localhost:5173"
FX = sys.argv[2] if len(sys.argv) > 2 else "/home/claude/fixtures"
SHOTS = "/home/claude/shots2"
errors, results = [], []
def check(name, cond):
    results.append((name, bool(cond))); print(("PASS " if cond else "FAIL ") + name)

def table_scores(pg):
    rows = pg.locator("#table tbody tr")
    out = {}
    for i in range(rows.count()):
        tds = rows.nth(i).locator("td")
        if tds.count() < 11: continue
        dealer = tds.nth(0).inner_text()
        did = dealer.split()[-1]
        out[did] = (int(tds.nth(8).inner_text()), tds.nth(9).inner_text().strip(), tds.nth(10).inner_text().strip())
    return out

def matches_engine(pg, expected):
    got = table_scores(pg)
    return len(got) == len(expected) and all(got.get(e["id"]) == (e["score"], e["risk"], e["priority"]) for e in expected)

with sync_playwright() as p:
    b = p.chromium.launch()
    pg = b.new_page(viewport={"width": 1440, "height": 900})
    pg.on("console", lambda m: m.type == "error" and errors.append(m.text))
    pg.on("pageerror", lambda e: errors.append(str(e)))
    def close_detail():
        pg.keyboard.press("Escape")
        try: pg.wait_for_selector("[role=dialog]", state="detached", timeout=5000)
        except Exception: check("Dealer detail closes on Escape", False); raise
    tab = lambda n: pg.get_by_role("navigation", name="Pages").get_by_role("button", name=re.compile(f"^{n}"))
    pg.goto(URL); pg.wait_for_selector("#queue")

    # ── Synthetic mode: dashboard
    pg.screenshot(path=f"{SHOTS}/01_dashboard.png")
    check("Synthetic label shown by default", pg.inner_text("[data-testid=data-label]") == "Synthetic Data | Illustrative Scoring Model")
    kp = pg.inner_text("#kpis")
    check("Dashboard has 4 KPIs (Total/Critical/P1/Avg)", all(k in kp for k in ["Total dealers", "Critical dealers", "P1 dealers", "Average health score"]) and "Watch dealers" not in kp)
    check("KPIs: 50 / 9 / 13 / 64", re.search(r"Total dealers\s*50", kp) and re.search(r"Critical dealers\s*9", kp) and re.search(r"P1 dealers\s*13", kp) and re.search(r"Average health score\s*64", kp))
    check("Queue top 5 includes D008", pg.locator("#queue ol > li").count() == 5 and pg.locator("#queue-row-D008").count() == 1)
    check("No charts on dashboard (moved to Insights)", pg.locator(".recharts-surface").count() == 0)
    pg.click("#queue-row-D008 button"); pg.wait_for_selector("#detail-why")
    d8 = pg.inner_text("#detail-score")
    check("D008 detail: 58/100, Watch, P1", "58" in d8 and "Watch" in d8 and "P1" in d8)
    check("D008 detail: combined action", "inventory reduction and payment recovery" in pg.inner_text("#detail-actions"))
    pos = lambda a, b: pg.evaluate(f"document.getElementById('{a}').compareDocumentPosition(document.getElementById('{b}')) & 4") > 0
    check("Detail order: score > why > root cause > actions > detailed metrics", pos("detail-score", "detail-why") and pos("detail-why", "detail-rootcause") and pos("detail-rootcause", "detail-actions") and pos("detail-actions", "detail-breakdown"))
    hvp = pg.inner_text("[data-testid=health-vs-priority]")
    check("Health vs Priority explained (Watch + P1)", "Why P1 while health is Watch?" in hvp and "Severe inventory and payment risks require intervention" in hvp)
    prim = pg.inner_text("[data-testid=primary-hypothesis]")
    check("Primary hypothesis with Cause > Why > Evidence > Validate > Action", all(k in prim for k in ["PRIMARY HYPOTHESIS", "POSSIBLE CAUSE", "WHY WE THINK THIS", "EVIDENCE", "HOW TO VALIDATE", "RECOMMENDED ACTION"]))
    check("Confidence meaning shown", "additional data is required to confirm it" in prim)
    oc = pg.locator("[data-testid=other-causes]")
    check("Other possible causes collapsed by default", oc.count() == 1 and oc.get_attribute("open") is None and "OTHER POSSIBLE CAUSES (3)" in oc.inner_text())
    oc.locator("summary").first.click(); pg.locator("[data-testid=hypothesis] summary").first.click(); pg.wait_for_timeout(150)
    check("Secondary hypothesis expands with validation step", "HOW TO VALIDATE" in pg.locator("[data-testid=hypothesis]").first.inner_text())
    rc = pg.inner_text("#detail-rootcause")
    check("Root-cause: hedged framing", "hypotheses that require validation" in rc and "Possible cause" in rc)
    check("Root-cause: no certainty language", not re.search(r"is causing|caused by|confirmed cause is|definitely|incompetent", rc))
    pg.locator("[data-testid=not-assessed] summary").click(); pg.wait_for_timeout(100)
    check("Core data: 'deeper diagnostic unavailable because … not provided'", "Deeper diagnostic unavailable" in pg.inner_text("[data-testid=not-assessed]") and "were not provided" in pg.inner_text("[data-testid=not-assessed]"))
    check("No 'What changed?' on single-snapshot synthetic data", pg.locator("[data-testid=what-changed]").count() == 0)
    check("Matched-to-cause actions in action plan", pg.locator("[data-testid=matched-actions]").count() == 1)
    pg.locator("#detail-rootcause").screenshot(path=f"{SHOTS}/10_rootcause_core.png")
    pg.locator("[role=dialog] [id=detail-score]").screenshot(path=f"{SHOTS}/12_health_priority.png")
    close_detail()
    check("Dashboard stays simple (no diagnostics on it)", pg.locator("#detail-rootcause, #patterns").count() == 0)
    check("Dashboard essential insights incl. cross-dealer pattern", "South: elevated complaints" in pg.inner_text("[data-testid=essential-insights]"))

    # ── Dealers page
    tab("Dealers").click(); pg.wait_for_selector("#table")
    check("Hash routing (#/dealers)", pg.url.endswith("#/dealers"))
    check("Synthetic table scores == engine (all 50)", matches_engine(pg, json.load(open(f"{FX}/expected_synthetic.json"))))
    cnt = lambda: pg.inner_text("[data-testid=row-count]")
    pg.fill("input[aria-label='Search dealers']", "mumbai"); check("Search 'mumbai' -> 3", cnt().startswith("3 of")); pg.fill("input[aria-label='Search dealers']", "")
    pg.select_option("select[aria-label='Region filter']", "South"); check("Region filter", cnt().startswith("11 of"))
    pg.select_option("select[aria-label='Health status filter']", "Critical"); check("Health status filter stacks", cnt().startswith("2 of"))
    pg.get_by_role("button", name="Reset filters").click(); check("Reset", cnt().startswith("50 of"))
    pg.select_option("select[aria-label='Priority filter']", "P1"); check("Priority filter", cnt().startswith("13 of"))
    pg.get_by_role("button", name="Reset filters").click()
    pg.select_option("select[aria-label='Risk flag filter']", "payment_risk"); n_pay = int(cnt().split()[0]); check(f"Risk flag filter (payment risk: {n_pay})", 0 < n_pay < 50)
    pg.get_by_role("button", name="Reset filters").click()
    rows = pg.locator("#table tbody tr")
    pg.select_option("select[aria-label='Sort order']", "inventory_desc")
    ages = [int(rows.nth(i).locator("td").nth(5).inner_text().split()[0]) for i in range(rows.count())]
    check("Sort by inventory age", ages == sorted(ages, reverse=True))
    pg.select_option("select[aria-label='Sort order']", "score_asc")
    sc = [int(rows.nth(i).locator("td").nth(8).inner_text()) for i in range(rows.count())]; check("Sort by health score", sc == sorted(sc))
    pg.get_by_role("button", name="Sort by priority").click()
    pr = [rows.nth(i).locator("td").nth(10).inner_text() for i in range(rows.count())]; check("Sort by priority", pr == sorted(pr))
    pg.fill("input[aria-label='Search dealers']", "D012"); pg.locator("#table tbody tr").first.click(); pg.wait_for_selector("#detail-rootcause")
    ins = pg.inner_text("[data-testid=insufficient]")
    check("D012: 'Insufficient evidence — additional data required' with specific data", "Insufficient evidence — additional data required" in ins and "Conversion rate" in ins)
    close_detail(); pg.fill("input[aria-label='Search dealers']", "")
    pg.locator("#table tbody tr", has_text="Riverbend Auto").click(); pg.wait_for_selector("#detail-breakdown")
    check("Detail from table (D009 77 Healthy P3)", "77" in pg.inner_text("#detail-score") and "P3" in pg.inner_text("#detail-score"))
    close_detail()
    pg.screenshot(path=f"{SHOTS}/02_dealers.png")

    # ── Insights
    tab("Insights").click(); pg.wait_for_selector("#comparison")
    comp = pg.inner_text("#comparison")
    check("Comparison is D003 vs D009", "PREMIER DRIVE (D003)" in comp and "RIVERBEND AUTO (D009)" in comp and "tell different stories" in comp)
    pg.wait_for_timeout(500)
    pat = pg.inner_text("#patterns")
    check("Insights: cross-dealer pattern (South complaints) on core data", "South: elevated complaints" in pat and "core metrics only" in pat)
    check("All 5 charts render on Insights", all(pg.locator(f"#{i} .recharts-surface").count() >= 1 for i in ["scatter", "risk-distribution", "risk-drivers", "regional", "health-bars"]))
    pg.screenshot(path=f"{SHOTS}/03_insights.png", full_page=True)

    # ── Methodology
    tab("Methodology").click(); pg.wait_for_selector("#health-vs-priority")
    hp = pg.inner_text("#health-vs-priority")
    check("Health vs Priority explained with live Watch+P1 example", "overall dealer condition" in hp and "urgency of management intervention" in hp and "P1" in hp)
    check("Limitation retained", "not been statistically validated" in pg.inner_text("#limitation"))
    check("Market potential explained as contextual", "contextual, not a dealer-performance metric" in pg.inner_text("[data-testid=market-potential-note]"))
    check("Methodology weights still match engine (25/15/15/15/10/10/10)", all(w in pg.inner_text("#method") for w in ["25%", "15%", "10%"]))
    pg.screenshot(path=f"{SHOTS}/04_method.png", full_page=True)

    # ── Data: invalid files
    tab("Data").click(); pg.wait_for_selector("#import")
    check("Imported option disabled before import", pg.get_by_role("radio", name=re.compile("Imported Data")).is_disabled())
    fi = pg.locator("[data-testid=file-input]")
    fi.set_input_files(f"{FX}/not_data.pdf"); pg.wait_for_timeout(300)
    check("Rejects non-CSV/Excel file", "not a CSV or Excel file" in pg.inner_text("#import"))
    fi.set_input_files(f"{FX}/missing_column.csv"); pg.wait_for_selector("[data-testid=import-report]")
    rep = pg.inner_text("[data-testid=import-report]")
    check("Missing column named, import blocked", "Missing required column: Payment delay" in rep and "Import blocked" in rep and pg.get_by_role("button", name="Confirm Import").is_disabled())
    pg.get_by_role("button", name="Cancel").click()
    fi.set_input_files(f"{FX}/bad_rows.csv"); pg.wait_for_selector("[data-testid=import-report]")
    rep = pg.inner_text("[data-testid=import-report]")
    pg.screenshot(path=f"{SHOTS}/05_invalid.png", full_page=True)
    check("Bad rows: counts", "10 dealer rows · 4 valid · 6 invalid" in rep)
    check("Bad rows: grouped messages", "2 rows have missing payment delay" in rep and "non-numeric inventory age" in rep and "service performance out of range" in rep and "Dealer ID already used" in rep and "missing market growth" in rep)
    check("Bad rows: blocked", pg.get_by_role("button", name="Confirm Import").is_disabled() and "Import blocked" in rep)
    pg.get_by_role("button", name="Cancel").click()
    check("Still synthetic after blocked import", pg.inner_text("[data-testid=data-label]").startswith("Synthetic"))

    fi.set_input_files(f"{FX}/semicolon.csv"); pg.wait_for_selector("[data-testid=import-report]")
    check("Incomplete file: blocked, lists the exact missing columns", "Missing required columns: Sales target" in pg.inner_text("[data-testid=import-report]") and pg.get_by_role("button", name="Confirm Import").is_disabled())
    pg.get_by_role("button", name="Cancel").click()
    fi.set_input_files(f"{FX}/semicolon_full.csv"); pg.wait_for_selector("[data-testid=import-report]")
    check("Semicolon-delimited CSV (European Excel) is detected and validates", "✓ 5 valid dealers" in pg.inner_text("[data-testid=import-report]"))
    pg.get_by_role("button", name="Cancel").click()
    fi.set_input_files(f"{FX}/fake.xlsx"); pg.wait_for_timeout(1500)
    txt = pg.inner_text("#import")
    check("Corrupt .xlsx: rejected with a clear message, nothing imported", ("could not be read" in txt or "Import blocked" in txt) and pg.inner_text("[data-testid=data-label]").startswith("Synthetic"))
    if pg.get_by_role("button", name="Cancel").count(): pg.get_by_role("button", name="Cancel").click()

    # ── Data: valid CSV with friendly headers
    fi.set_input_files(f"{FX}/valid_network.csv"); pg.wait_for_selector("[data-testid=import-report]")
    rep = pg.inner_text("[data-testid=import-report]")
    pg.screenshot(path=f"{SHOTS}/06_preview.png", full_page=True)
    check("Valid CSV: 20 valid, derived growth, preview shown", "✓ 20 valid dealers" in rep and "derived from Sales growth %" in rep and pg.locator("[data-testid=import-report] tbody tr").count() == 8)
    check("Valid CSV: extra column ignored", "Ignored extra columns: Notes" in rep)
    pg.get_by_role("button", name="Confirm Import").click()
    check("Import success + label switched", "Import complete" in pg.inner_text("main") and pg.inner_text("[data-testid=data-label]") == "Imported Dealer Data | Illustrative Scoring Model")
    pg.get_by_role("button", name="View dashboard").click(); pg.wait_for_selector("#queue")
    kp = pg.inner_text("#kpis"); exp = json.load(open(f"{FX}/expected_valid.json"))
    check("Imported KPIs recalculated (20 dealers)", re.search(r"Total dealers\s*20", kp) is not None)
    check("Imported avg score matches engine", f"{round(sum(e['score'] for e in exp)/len(exp))}" in kp)
    first = pg.locator("#queue ol > li").first.inner_text()
    check("Queue #1 matches engine", exp[0]["name"] in first)
    pg.screenshot(path=f"{SHOTS}/07_imported_dashboard.png")
    tab("Dealers").click(); pg.wait_for_selector("#table")
    check("Imported table scores == engine (all 20)", matches_engine(pg, exp))
    check("Imported regions in filter", "Karnataka North" in pg.inner_text("select[aria-label='Region filter']"))
    pg.locator("#table tbody tr").first.click(); pg.wait_for_selector("#detail-why")
    check("Imported dealer detail opens with imported label", "Imported Dealer Data" in pg.inner_text("[role=dialog]"))
    close_detail()
    tab("Insights").click(); pg.wait_for_timeout(600)
    check("Imported: charts render", pg.locator(".recharts-surface").count() >= 5)
    check("Imported: comparison uses imported dealers", "KA-" in pg.inner_text("#comparison") or "No pair" in pg.inner_text("#comparison"))
    pg.screenshot(path=f"{SHOTS}/08_imported_insights.png")

    # ── Switch back to synthetic and forth
    tab("Data").click(); pg.get_by_role("radio", name=re.compile("Synthetic Demo Data")).click()
    tab("Dashboard").click(); kp = pg.inner_text("#kpis")
    check("Switch back restores synthetic (50, 13 P1)", re.search(r"Total dealers\s*50", kp) and re.search(r"P1 dealers\s*13", kp) and pg.locator("#queue-row-D008").count() == 1)
    tab("Insights").click(); check("D003/D009 comparison restored", "PREMIER DRIVE (D003)" in pg.inner_text("#comparison"))
    tab("Data").click(); pg.get_by_role("radio", name=re.compile("Imported Data")).click()
    tab("Dashboard").click(); check("Switch to imported again", re.search(r"Total dealers\s*20", pg.inner_text("#kpis")) is not None)

    # ── Download Data Template → edit → upload back
    tab("Data").click(); pg.wait_for_selector("[data-testid=template-box]")
    with pg.expect_download() as dl_info:
        pg.get_by_role("button", name="Download Data Template").click()
    dl = dl_info.value; path = f"{SHOTS}/{dl.suggested_filename}"; dl.save_as(path)
    check(f"Template download fired: {dl.suggested_filename}", dl.suggested_filename == "dealer-data-template.csv" and "Data template downloaded" in pg.inner_text("[data-testid=save-msg]"))
    raw = open(path, encoding="utf-8-sig").read().splitlines()
    hdr = raw[0].split(",")
    check("Template header = importer's internal field names (core + optional)", hdr[:3] == ["dealer_id", "dealer_name", "region"] and "market_growth" in hdr and "product_category" in hdr and "service_resolution_days" in hdr and len(hdr) == 34)
    # Round trip exactly as specified: upload the SAME file back → validate → preview → confirm → app updates
    fi = pg.locator("[data-testid=file-input]"); fi.set_input_files(path); pg.wait_for_selector("[data-testid=import-report]")
    rep = pg.inner_text("[data-testid=import-report]")
    check("Unchanged template validates: all columns recognised, 3 example rows valid, guidance skipped", "Missing required" not in rep and "Ignored extra columns" not in rep and "✓ 3 valid dealers" in rep and "2 template guidance/example rows" in rep)
    check("Example rows flagged as synthetic examples (not real data)", "template example rows (synthetic)" in rep)
    check("Preview shows the example rows", pg.locator("[data-testid=import-report] tbody tr").count() == 3 and "EXAMPLE-01" in pg.inner_text("[data-testid=import-report] tbody"))
    pg.get_by_role("button", name="Confirm Import").click()
    tab("Dashboard").click()
    check("Template import → KPIs show 3 dealers", re.search(r"Total dealers\s*3", pg.inner_text("#kpis")) is not None)
    check("Template import → queue shows example dealers only", pg.locator("#queue ol > li").count() == 3 and all("EXAMPLE" in pg.locator("#queue ol > li").nth(i).inner_text() for i in range(3)))
    pg.locator("#queue ol > li button").first.click(); pg.wait_for_selector("#detail-why")
    check("Template import → dealer detail uses imported data + label", "Imported Dealer Data" in pg.inner_text("[role=dialog]") and "synthetic example" in pg.inner_text("[role=dialog] header"))
    close_detail()
    tab("Dealers").click(); check("Template import → dealer list has 3", pg.inner_text("[data-testid=row-count]").startswith("3 of 3"))
    tab("Insights").click(); pg.wait_for_timeout(500)
    ins = pg.inner_text("main")
    check("Template import → Insights charts + subtitle use imported data", "All 3 dealers" in ins and pg.locator(".recharts-surface").count() >= 5 and "PREMIER DRIVE" not in ins)
    check("Template import → regional chart shows imported regions", all(r in pg.inner_text("#regional") for r in ["West", "North", "South"]) and "Central" not in pg.inner_text("#regional"))
    tab("Methodology").click(); check("Template import → Methodology example not from synthetic", "Metro Flagship" not in pg.inner_text("#health-vs-priority"))
    tab("Data").click(); fi = pg.locator("[data-testid=file-input]")
    # a manager fills it in: 3 dealers, core only for two, one with diagnostic + previous values; growth % instead of PY sales on one row
    blanks = "," * 18
    rows = raw[:3] + [
        "DLR-101,Shivneri Motors,West,Pune,90,84,80,,110,58,14,80,40,900,74,7" + blanks,
        "DLR-102,Godavari Cars,West,Nashik,50,52,,6,60,35,3,88,14,560,60,6" + blanks,
        "DLR-103,Narmada Auto,Central,Indore,70,52,61,,140,72,25,70,55,600,82,8,SUV,2.4,0.9,0.5,2,76,4100,14,92,30,3.1,120,62,6.5,51,9,3.2,80",
    ]
    filled = f"{SHOTS}/dealer-data-filled.csv"; open(filled, "w", encoding="utf-8-sig").write("\n".join(rows))
    fi.set_input_files(filled); pg.wait_for_selector("[data-testid=import-report]")
    rep = pg.inner_text("[data-testid=import-report]")
    check("Filled template imports: 3 valid, guidance rows skipped, optional data found", "✓ 3 valid dealers" in rep and "skipped" in rep and "Optional diagnostic columns found" in rep and not pg.get_by_role("button", name="Confirm Import").is_disabled())
    pg.get_by_role("button", name="Confirm Import").click()
    tab("Dashboard").click(); check("Filled-template data drives the dashboard (3 dealers)", re.search(r"Total dealers\s*3", pg.inner_text("#kpis")) is not None)
    tab("Dealers").click(); pg.fill("input[aria-label='Search dealers']", "DLR-103"); pg.locator("#table tbody tr").first.click(); pg.wait_for_selector("#detail-rootcause")
    check("Filled template: diagnostics + What changed work on user data", pg.locator("[data-testid=primary-hypothesis]").count() == 1 and pg.locator("[data-testid=what-changed]").count() == 1)
    close_detail(); pg.fill("input[aria-label='Search dealers']", "")

    # ── Diagnostic sample (opt-in, synthetic)
    tab("Data").click(); pg.get_by_role("button", name="Load diagnostic sample").click(); pg.wait_for_selector("[data-testid=import-report]")
    of = pg.inner_text("[data-testid=optional-found]")
    check("Diagnostic sample validated: 14 diagnostic + previous-period columns", "Optional diagnostic columns found (14)" in of and "What changed?" in of)
    pg.get_by_role("button", name="Confirm Import").click()
    check("Sample label is explicitly synthetic", pg.inner_text("[data-testid=data-label]") == "Synthetic Diagnostic Sample | Illustrative Scoring Model")
    tab("Dashboard").click(); kp = pg.inner_text("#kpis")
    check("Optional fields don't change scores (KPIs same as synthetic)", re.search(r"P1 dealers\s*13", kp) and re.search(r"Average health score\s*64", kp))
    tab("Insights").click(); pat = pg.inner_text("#patterns")
    check("Sample: EV product pattern + Central transport pattern", "EV: elevated product complaints" in pat and "Central: elevated product damage" in pat)
    tab("Dealers").click(); pg.fill("input[aria-label='Search dealers']", "D014"); pg.locator("#table tbody tr").first.click(); pg.wait_for_selector("#detail-rootcause")
    prim = pg.inner_text("[data-testid=primary-hypothesis]")
    check("D014 primary: regional transport issue, High", "Regional logistics / transport issue" in prim and "High confidence" in prim and "Part of a wider pattern" in pg.inner_text("#detail-rootcause"))
    check("D014: same product fine elsewhere + validate via provider/route", "travels normally elsewhere" in prim and "transport provider and delivery route" in prim)
    pg.locator("#detail-rootcause").screenshot(path=f"{SHOTS}/11_rootcause_D014.png")
    close_detail(); pg.fill("input[aria-label='Search dealers']", "D021"); pg.locator("#table tbody tr").first.click(); pg.wait_for_selector("#detail-rootcause")
    prim = pg.inner_text("[data-testid=primary-hypothesis]")
    check("D021 primary: potential sales execution gap (not blame)", "Potential sales execution gap" in prim and "incompetent" not in prim.lower())
    close_detail(); pg.fill("input[aria-label='Search dealers']", "D038"); pg.locator("#table tbody tr").first.click(); pg.wait_for_selector("#detail-rootcause")
    check("D038 primary: product-specific EV issue", "Product / quality issue — EV" in pg.inner_text("[data-testid=primary-hypothesis]"))
    close_detail(); pg.fill("input[aria-label='Search dealers']", "D044"); pg.locator("#table tbody tr").first.click(); pg.wait_for_selector("[data-testid=what-changed]")
    wc = pg.inner_text("[data-testid=what-changed]")
    check("What changed? shown from supplied previous-period data (D044)", "Emerging deterioration" in wc and "37 → 56" in wc)
    pg.locator("[data-testid=what-changed]").screenshot(path=f"{SHOTS}/13_what_changed.png")
    close_detail(); pg.fill("input[aria-label='Search dealers']", "")

    # ── Excel import replaces imported set
    tab("Data").click(); fi = pg.locator("[data-testid=file-input]")
    fi.set_input_files(f"{FX}/dealers_12.xlsx"); pg.wait_for_selector("[data-testid=import-report]")
    check("Excel parsed: 12 valid", "✓ 12 valid dealers" in pg.inner_text("[data-testid=import-report]"))
    pg.get_by_role("button", name="Confirm Import").click()
    tab("Dealers").click(); got = table_scores(pg); exx = json.load(open(f"{FX}/expected_xlsx.json"))
    check("Excel import scores == engine", len(got) == 12 and all(got[e["id"]][0] == e["score"] for e in exx))
    tab("Data").click(); pg.get_by_role("button", name="Remove imported data").click()
    check("Remove imported -> synthetic", pg.inner_text("[data-testid=data-label]").startswith("Synthetic"))

    # ── Zero-P1 dataset: no misleading "Show all 0 P1 dealers" button
    tab("Data").click(); pg.locator("[data-testid=file-input]").set_input_files(f"{FX}/healthy_only.csv"); pg.get_by_role("button", name="Confirm Import").click()
    tab("Dashboard").click()
    check("Zero P1: queue keeps its rows, no empty-expand button", pg.locator("#queue ol > li").count() == 4 and pg.locator("#queue footer button").count() == 0)
    tab("Data").click(); pg.get_by_role("button", name="Remove imported data").click()

    # ── Competitor logic on core synthetic data: states absence, never invents values
    tab("Dealers").click(); pg.fill("input[aria-label='Search dealers']", "D017"); pg.locator("#table tbody tr").first.click(); pg.wait_for_selector("#detail-rootcause")
    pg.locator("[data-testid=other-causes] summary").first.click()
    for i in range(pg.locator("[data-testid=hypothesis] summary").count()): pg.locator("[data-testid=hypothesis] summary").nth(i).click()
    rc = pg.inner_text("#detail-rootcause")
    check("Competitor: absence stated, no competitor values invented", "Competitor price, market-share and promotion data is not currently available" in rc and not re.search(r"Competitor (share|price index|promotion intensity) [\d+-]", rc))
    close_detail(); pg.fill("input[aria-label='Search dealers']", "")

    # ── Guided tour on synthetic (navigates pages)
    tab("Dashboard").click(); pg.evaluate("window.scrollTo(0,0)")
    pg.get_by_role("button", name="Guided tour (60s)").click()
    t0 = time.time(); seen = []
    for k in range(75):
        pg.wait_for_timeout(1000)
        st = pg.locator("div[role=status].bg-cab")
        if st.count() == 0: break
        title = st.locator(".font-semibold").first.inner_text()
        if title not in seen:
            seen.append(title); pg.wait_for_timeout(700); pg.screenshot(path=f"{SHOTS}/tour_{len(seen):02d}.png")
    dur = round(time.time() - t0)
    check(f"Tour: {len(seen)} steps, {dur}s, ended on dashboard", len(seen) == 9 and 55 <= dur <= 80 and pg.url.endswith("#/dashboard"))
    print("TOUR:", seen)

    # ── Tablet
    pg.set_viewport_size({"width": 820, "height": 1100}); pg.wait_for_timeout(300)
    for t in ["Dashboard", "Dealers", "Insights", "Data", "Methodology"]:
        tab(t).click(); pg.wait_for_timeout(250)
        if pg.evaluate("document.documentElement.scrollWidth > window.innerWidth"): check(f"Tablet overflow on {t}", False)
    pg.screenshot(path=f"{SHOTS}/09_tablet.png")
    check("Tablet: no page-level horizontal overflow", True)
    b.close()
real = [e for e in errors if "fonts.g" not in e and "Failed to load resource" not in e]
print("CONSOLE ERRORS:", real if real else "none")
print("SUMMARY:", sum(r for _, r in results), "/", len(results), "passed")
