import { DEALERS } from '../src/data/dealers';
import { scoreAll, byAttention } from '../src/model/scoring';
const s = scoreAll(DEALERS).sort(byAttention);
for (const d of s) console.log(d.dealer_id, d.dealer_name.padEnd(24), String(d.sales_achievement_pct).padStart(5), String(d.health_score).padStart(3), d.risk_level.padEnd(8), d.priority, String(d.attention_index).padStart(5), d.primary_risk.padEnd(16), '|', d.archetype, "₹"+d.capital_at_risk_cr);
const c = (f:(x:any)=>boolean)=>s.filter(f).length;
console.log('Healthy',c(d=>d.risk_level==='Healthy'),'Watch',c(d=>d.risk_level==='Watch'),'Critical',c(d=>d.risk_level==='Critical'),'P1',c(d=>d.priority==='P1'),'P2',c(d=>d.priority==='P2'),'P3',c(d=>d.priority==='P3'));
