import { writeFileSync } from 'fs';
import * as XLSX from 'xlsx';
import { DEALERS } from '../src/data/dealers';
import { analyzeTable, toCsv } from '../src/data/importDealers';
import { scoreAll, byAttention } from '../src/model/scoring';
const out = '/home/claude/fixtures';

// A different network: 20 dealers, new IDs/regions, shifted metrics, friendly headers, growth % instead of PY sales
const header = ['Dealer Code','Dealer Name','Zone','City','Sales Target (₹ Cr)','Actual Sales (₹ Cr)','Sales Growth %','Stock Units','Inventory Ageing (days)','Payment Delay (days)','Service Score','Complaints','Vehicles Sold','Market Potential','Market Growth %','Notes'];
const rows = DEALERS.filter((_, i) => i % 5 !== 0).slice(0, 20).map((d, i) => {
  const growth = Math.round(((d.actual_sales - d.previous_year_sales) / d.previous_year_sales) * 100 - 3);
  return [`KA-${100 + i}`, d.dealer_name.replace('Motors', 'Automobiles'), i % 2 ? 'Karnataka North' : 'Karnataka South', d.city, `₹${d.sales_target}`, d.actual_sales, `${growth}%`,
    d.inventory_units, d.inventory_age_days + (i % 3) * 6, Math.max(0, d.payment_delay_days - 2), d.service_performance, d.customer_complaints, d.vehicles_sold, d.market_potential, d.market_growth, 'n/a'];
});
const toCsvRows = (t: unknown[][]) => t.map((r) => r.map((c) => (/[",]/.test(String(c)) ? `"${c}"` : c)).join(',')).join('\n');
writeFileSync(`${out}/valid_network.csv`, toCsvRows([header, ...rows]));

const rep = analyzeTable([header, ...rows].map((r) => r.map(String)), 'valid_network.csv');
const scored = scoreAll(rep.dealers).sort(byAttention);
writeFileSync(`${out}/expected_valid.json`, JSON.stringify(scored.map((d) => ({ id: d.dealer_id, name: d.dealer_name, score: d.health_score, risk: d.risk_level, priority: d.priority })), null, 0));
writeFileSync(`${out}/expected_synthetic.json`, JSON.stringify(scoreAll(DEALERS).sort(byAttention).map((d) => ({ id: d.dealer_id, name: d.dealer_name, score: d.health_score, risk: d.risk_level, priority: d.priority }))));

// Excel version of 12 synthetic dealers with canonical headers
const syn = toCsv(DEALERS.slice(0, 12)).split('\n').map((l, i) => l.split(',').map((c, j) => (i > 0 && j >= 4 ? Number(c) : c)));
const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.aoa_to_sheet(syn), 'Dealers');
writeFileSync(`${out}/dealers_12.xlsx`, XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }));
writeFileSync(`${out}/expected_xlsx.json`, JSON.stringify(scoreAll(DEALERS.slice(0, 12)).map((d) => ({ id: d.dealer_id, score: d.health_score }))));

// Missing column
writeFileSync(`${out}/missing_column.csv`, toCsv(DEALERS.slice(0, 10)).split('\n').map((l) => l.split(',').filter((_, j) => j !== 9).join(',')).join('\n'));
// Bad rows
const bad = toCsv(DEALERS.slice(0, 10)).split('\n').map((l) => l.split(','));
bad[2][9] = ''; bad[3][9] = ''; bad[4][8] = 'sixty'; bad[5][10] = '140'; bad[6][0] = bad[7][0]; bad[8][14] = '';
writeFileSync(`${out}/bad_rows.csv`, bad.map((r) => r.join(',')).join('\n'));
writeFileSync(`${out}/not_data.pdf`, 'nope');
console.log('fixtures written; valid file dealers:', rep.validCount, 'canImport', rep.canImport, 'growthFromPct', rep.growthFromPct, 'pair-capable P1s:', scored.filter(d=>d.priority==='P1').length);
