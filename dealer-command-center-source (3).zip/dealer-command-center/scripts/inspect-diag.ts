import { DEALERS } from '../src/data/dealers';
import { buildDiagnosticSample } from '../src/data/diagnosticSample';
import { scoreAll } from '../src/model/scoring';
import { buildDiagnostics } from '../src/model/diagnostics';
const ids = process.argv.slice(3);
for (const [name, data] of [['CORE', DEALERS], ['SAMPLE', buildDiagnosticSample()]] as const) {
  const sc = scoreAll(data as any); const dg = buildDiagnostics(sc);
  console.log(`\n===== ${name} | optional fields: ${dg.available.length} | patterns: ${dg.patterns.length}`);
  for (const p of dg.patterns) console.log('  PATTERN', p.scope, p.confidence, '|', p.title);
  for (const id of ids) {
    const d = dg.byDealer.get(id)!; console.log(`\n  [${id}] ${d.scopeSummary}`);
    for (const t of d.trees) { console.log(`   ${t.symptom}:`); for (const b of t.branches) console.log(`     ${b.status.padEnd(13)} ${(b.confidence ?? '').padEnd(6)} ${b.scope.padEnd(16)} ${b.title}${b.dataNeeded.length ? '  [needs: ' + b.dataNeeded.join(', ') + ']' : ''}`); }
  }
}
