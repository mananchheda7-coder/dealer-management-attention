# Dealer Command Center

**Which dealers need management attention — why — and what should management do?**

A decision-support prototype for an automobile manufacturer's regional managers.
It turns dealer data into a ranked attention queue with explanations and matched actions:

DATA → HEALTH → RISK → PRIORITY → WHY → ACTION

> Synthetic Data | Illustrative Scoring Model — no real manufacturer or dealer data.

## Run it

```bash
npm install
npm run dev          # http://localhost:5173
npm run build        # production build -> dist/
npm test             # 45 tests: scoring model, import validation + template + malformed files, diagnostics
npm run build:single # one self-contained HTML file -> dist-single/index.html
```

Requires Node 18+.

## Navigation

| Page | What it answers |
|---|---|
| **Dashboard** | Who needs attention, why, and what to do: 4 KPIs + the Management Attention Queue |
| **Dealers** | Full directory: search, filter by health status / priority / region / risk flag, sort by score, priority or any key metric |
| **Insights** | "Why sales alone is not enough" (D003 vs D009) and all analytical charts |
| **Data** | Data source switch and CSV / Excel import with validation and preview |
| **Methodology** | Health vs Priority, weights, flags, priority logic, recommendation rules, limitation |

The 60-second guided tour is in the header (secondary).

## Final-pass refinements

- **Ranked root causes.** Each dealer shows one *primary hypothesis* — possible cause → why we think this →
  evidence → how to validate → recommended action — with other possible causes collapsed behind it. Causes
  are ranked by confidence, then the severity of the symptom they explain, then net evidence.
- **Confidence in plain English.** High = multiple independent indicators; Medium = meaningful pattern,
  more data needed; Low = initial signal only. If nothing is supported: *Insufficient evidence —
  additional data required*, naming the missing fields.
- **Health vs Priority** is explained on every dealer where they diverge ("Why P1 while health is Watch?").
- **Dealer detail order:** health + priority → (what changed) → why flagged → root cause → interpretation →
  actions → detailed metrics and score breakdown.
- **What changed?** appears only when a file supplies previous-period values (`prev_*` columns). The
  default synthetic data is a single snapshot, so no trends are shown or invented.
- **Download Data Template** (Data page) downloads `dealer-data-template.csv`: the importer's exact
  column names (core, then optional), a field-type row and a unit/rule row (both start with `#` and are
  skipped on import), and three example rows `EXAMPLE-01…03` labelled "(synthetic example)". The template
  round-trips as-is; example rows always carry an import warning so they are never mistaken for real dealers.
  On claude.ai the download goes through the platform's `downloads` capability (the viewer confirms);
  everywhere else it is a normal browser download. A copy is in `sample-data/`.

## Root-cause diagnostics

Inside each dealer's detail, **Root-cause investigation** follows *Why flagged*:

SYMPTOM → PATTERN → POSSIBLE CAUSE → EVIDENCE → INVESTIGATION → ACTION

- Four diagnostic trees (sales, complaints, inventory, payment). Every branch is either *supported*
  (with evidence, a High/Medium/Low confidence and the reason for it), *not supported* (with the
  evidence against), or *cannot assess yet* (with the data that would be needed).
- Each problem is classed as dealer-specific, regional, product-specific or network-wide by comparing
  the dealer with its region, other regions and the whole network. Insights lists cross-dealer patterns.
- Outputs are **hypotheses, not confirmed causes**; a unit test fails if any output uses certainty language.
- The layer never changes health scores, flags, priorities or the existing recommendations. It adds
  root-cause-matched actions beneath the existing action plan.
- **No fabricated data.** The default synthetic dataset has core metrics only, so transport, product,
  funnel and competitor hypotheses say which data is needed. 14 optional import columns unlock them
  (see the Data page). `sample-data/synthetic-diagnostic-sample.csv` (also loadable in-app via
  *Load diagnostic sample*) is a clearly labelled synthetic file with designed patterns: a Central-region
  transport problem, an EV quality issue across 4 regions, sales-execution and competitive-pressure
  cases, and a pure customer-service case.

## Importing your own dealer data

Data → **Import Dealer Data** → validate → preview → **Confirm Import**. CSV and .xlsx are supported.

- Use the same columns as the synthetic data (download the template from the Data page). Headers are
  matched loosely: `Inventory Ageing (days)`, `Payment Delay`, `Dealer Code`, `Sales Growth %` all work.
- `sales_growth_pct` may replace `previous_year_sales` (previous-year sales is then derived).
- Missing columns, empty/non-numeric values, out-of-range values (e.g. service > 100, negative delays)
  and duplicate Dealer IDs **block the import**; no values are ever filled in. Implausible but valid
  values (e.g. achievement > 200%) are imported with a warning.
- Imported data lives for the browser session only. Synthetic Demo Data stays the default and is always
  one click away. Scoring uses the same fixed business anchors, so a dealer's score never depends on
  which other dealers are in the file.

## What's inside

| Path | Purpose |
|---|---|
| `src/data/dealers.ts` | 50 synthetic dealers designed from 14 business archetypes (not random rows) |
| `src/data/importDealers.ts` | Header mapping, value parsing, row validation, CSV template export |
| `src/model/diagnostics.ts` | Root-cause trees, cross-dealer patterns, evidence and confidence |
| `src/data/diagnosticSample.ts` | Opt-in synthetic diagnostic sample (designed patterns) |
| `src/model/insights.ts` | Picks the comparison pair and tour dealer for any dataset |
| `src/pages/` | Dashboard and Data pages |
| `src/model/scoring.ts` | Health score, risk flags, priority, capital at risk, explanations, recommendation engine |
| `src/model/scoring.test.ts` | Unit tests incl. the D003 vs D009 and D008 business-story checks |
| `src/components/` | Queue, comparison, charts, table, dealer detail, method, guided demo |
| `scripts/e2e.py` | Playwright browser test (95 checks) incl. template download → edit → re-upload, diagnostics, switching, tour |
| `src/lib/download.ts` | File downloads: platform capability when hosted, browser download elsewhere |
| `scripts/make-fixtures.ts` | Builds import test files (valid CSV, Excel, invalid files) |

## The model in one page

**Health score (0–100).** Seven metrics, each normalised linearly between fixed business anchors
(not dataset min/max, so a dealer's score doesn't move when others change):

| Component | Weight | Full points | Zero points |
|---|---|---|---|
| Sales vs target | 25% | 110% | 50% |
| Sales growth | 15% | +20% | −20% |
| Inventory ageing | 15% | 30 days | 90 days |
| Payment delays | 15% | 0 days | 45 days |
| Service performance | 10% | 95 | 55 |
| Complaints per 100 vehicles | 10% | 1 | 8 |
| Market potential | 10% | 95 | 30 |

Healthy 75–100 · Watch 50–74 · Critical 0–49.

**Risk flags** (moderate / severe) are evaluated separately from the score, so a dealer can be
Healthy overall and still carry a severe risk (e.g. Indus Motors, D031).

**Priority.** P1 = score < 50, or ≥ 2 severe risks, or sharply falling sales where market demand
exists. P2 = one severe risk, ≥ 2 moderate risks, score < 65, or untapped demand. P3 = monitor.

**Queue order** within a band = risk depth + **capital at risk** (₹ value of stock above a
1.25-month cover + overdue receivables). Sales volume is never a ranking input.

## Key limitation

The scoring weights and thresholds are illustrative and have not been statistically validated
against historical dealer outcomes. Production deployment would require calibration using actual
dealer performance and recovery/failure outcomes. The data is also point-in-time (no monthly trend
or seasonality).
