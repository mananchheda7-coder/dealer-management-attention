/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['"IBM Plex Sans"', 'system-ui', 'Segoe UI', 'Roboto', 'sans-serif'],
        cond: ['"IBM Plex Sans Condensed"', '"IBM Plex Sans"', 'Arial Narrow', 'sans-serif'],
      },
      colors: {
        ink: '#18222F',
        steel: { 50: '#F2F4F7', 100: '#E4E8EE', 200: '#CBD2DC', 400: '#8592A3', 500: '#5F6C7D', 700: '#36414F' },
        info: '#2E66A8',
        ok: { DEFAULT: '#1D8556', soft: '#E3F3EA' },
        warn: { DEFAULT: '#B87A0A', soft: '#FBF0D9' },
        crit: { DEFAULT: '#C2362B', soft: '#FBE5E2' },
        cab: '#1F2C3D',
      },
    },
  },
  plugins: [],
};
