import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

// `npm run build` -> standard multi-file build in dist/
// `npm run build:single` -> one self-contained HTML file in dist-single/ (for sharing)
export default defineConfig(({ mode }) => ({
  build: { chunkSizeWarningLimit: 1000 },
  plugins: mode === 'single' ? [react(), viteSingleFile()] : [react()],
}));
