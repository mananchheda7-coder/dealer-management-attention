import { useCallback, useEffect, useMemo, useState } from 'react';
import { DEALERS } from './data/dealers';
import { byAttention, scoreAll } from './model/scoring';
import { pickComparisonPair, pickFocusDealer } from './model/insights';
import { buildDiagnostics } from './model/diagnostics';
import Patterns from './components/Patterns';
import { DIAGNOSTIC_SAMPLE_NAME } from './data/diagnosticSample';
import Comparison from './components/Comparison';
import Charts from './components/Charts';
import DealerTable from './components/DealerTable';
import DealerDetail from './components/DealerDetail';
import Method from './components/Method';
import Demo, { buildSteps, type Page } from './components/Demo';
import Dashboard from './pages/Dashboard';
import DataPage, { type ImportedSet, type Source } from './pages/DataPage';

const PAGES: { id: Page; label: string }[] = [
  { id: 'dashboard', label: 'Dashboard' },
  { id: 'dealers', label: 'Dealers' },
  { id: 'insights', label: 'Insights' },
  { id: 'data', label: 'Data' },
  { id: 'methodology', label: 'Methodology' },
];

const pageFromHash = (): Page => {
  const h = window.location.hash.replace(/^#\/?/, '');
  return (PAGES.find((p) => p.id === h)?.id ?? 'dashboard') as Page;
};

export default function App() {
  // ── Single source of truth: the active dataset. Everything below is derived from it.
  const [source, setSource] = useState<Source>('synthetic');
  const [imported, setImported] = useState<ImportedSet | null>(null);
  const active = source === 'imported' && imported ? imported.dealers : DEALERS;
  const scored = useMemo(() => scoreAll(active), [active]);
  const queue = useMemo(() => [...scored].sort(byAttention), [scored]);
  const pair = useMemo(() => pickComparisonPair(scored), [scored]);
  const focus = useMemo(() => pickFocusDealer(queue), [queue]);
  const diagnostics = useMemo(() => buildDiagnostics(scored), [scored]);
  const nameOf = useCallback((id: string) => scored.find((d) => d.dealer_id === id)?.dealer_name ?? id, [scored]);
  const steps = useMemo(() => buildSteps(queue, focus, pair, focus ? diagnostics.byDealer.get(focus.dealer_id) : undefined), [queue, focus, pair, diagnostics]);
  const avg = Math.round(scored.reduce((s, d) => s + d.health_score, 0) / scored.length);
  const dataLabel =
    source === 'synthetic'
      ? 'Synthetic Data | Illustrative Scoring Model'
      : imported?.fileName === DIAGNOSTIC_SAMPLE_NAME
        ? 'Synthetic Diagnostic Sample | Illustrative Scoring Model'
        : 'Imported Dealer Data | Illustrative Scoring Model';
  const example = useMemo(() => queue.find((d) => d.priority === 'P1' && d.risk_level !== 'Critical') ?? null, [queue]);

  // ── Navigation (hash-based so browser back/forward works)
  const [page, setPageState] = useState<Page>(pageFromHash);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [demo, setDemo] = useState(false);
  useEffect(() => {
    const onHash = () => setPageState(pageFromHash());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  const setPage = useCallback((p: Page) => {
    setPageState((cur) => {
      if (cur !== p) window.scrollTo({ top: 0, behavior: 'auto' });
      return p;
    });
    if (window.location.hash !== `#/${p}`) history.replaceState(null, '', `#/${p}`);
  }, []);
  const go = (p: Page) => { if (window.location.hash !== `#/${p}`) window.location.hash = `/${p}`; setPage(p); };

  const selected = selectedId ? scored.find((d) => d.dealer_id === selectedId) ?? null : null;
  const open = useCallback((id: string | null) => setSelectedId(id), []);
  const close = useCallback(() => setSelectedId(null), []);
  const exitDemo = useCallback(() => { setDemo(false); setSelectedId(null); setPage('dashboard'); }, [setPage]);

  const switchSource = (s: Source) => { setSelectedId(null); setSource(s); };

  return (
    <div className="min-h-screen pb-28">
      <div className="sticky z-30" style={{ top: 'env(safe-area-inset-top, 0px)' }}>
        <header className="bg-cab text-white">
          <div className="mx-auto flex max-w-[1400px] flex-wrap items-center justify-between gap-x-6 gap-y-2 px-6 py-3">
            <div>
              <h1 className="font-cond text-2xl font-bold leading-tight tracking-wider">DEALER COMMAND CENTER</h1>
              <p className="text-[13px] text-steel-200">Dealer management decision &amp; diagnostic system for regional managers</p>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => go('data')}
                title="Change data source"
                data-testid="data-label"
                className={`rounded border px-2 py-1 text-[11px] font-medium ${source === 'synthetic' || imported?.fileName === DIAGNOSTIC_SAMPLE_NAME ? 'border-amber-300/50 bg-amber-300/10 text-amber-200' : 'border-sky-300/50 bg-sky-300/10 text-sky-200'}`}
              >
                {dataLabel}
              </button>
              <button
                onClick={() => { setSelectedId(null); setDemo(true); }}
                disabled={demo}
                className="rounded border border-white/25 px-3 py-1 text-[13px] text-steel-200 hover:border-white/60 hover:text-white disabled:opacity-50"
              >
                Guided tour (60s)
              </button>
            </div>
          </div>
        </header>
        <nav aria-label="Pages" className="border-b border-steel-200 bg-white">
          <div className="mx-auto flex max-w-[1400px] gap-1 overflow-x-auto px-4">
            {PAGES.map((p) => (
              <button
                key={p.id}
                onClick={() => go(p.id)}
                aria-current={page === p.id ? 'page' : undefined}
                className={`whitespace-nowrap border-b-2 px-4 py-3 text-sm font-medium ${page === p.id ? 'border-info text-ink' : 'border-transparent text-steel-500 hover:text-ink'}`}
              >
                {p.label}
                {p.id === 'dealers' && <span className="ml-1.5 rounded bg-steel-100 px-1.5 text-xs text-steel-500">{scored.length}</span>}
              </button>
            ))}
          </div>
        </nav>
      </div>

      <main className="mx-auto max-w-[1400px] px-6 py-6">
        {page === 'dashboard' && <Dashboard scored={scored} queue={queue} pair={pair} topPattern={diagnostics.patterns[0]} onOpen={open} onGo={go} />}

        {page === 'dealers' && <DealerTable key={source} dealers={scored} onOpen={open} />}

        {page === 'insights' && (
          <div className="space-y-8">
            <section>
              <h2 className="mb-3 text-lg font-semibold text-ink">The key insight</h2>
              {pair ? (
                <Comparison a={pair[0]} b={pair[1]} onOpen={open} />
              ) : (
                <div id="comparison" className="rounded-lg border border-steel-200 bg-white p-6 text-sm text-steel-700">
                  No pair in the current data shows a higher-selling dealer with weaker health than a lower-selling one. The sales vs inventory chart below still shows where strong sales and operational risk overlap.
                </div>
              )}
            </section>
            <section>
              <h2 className="mb-3 text-lg font-semibold text-ink">Is it the dealer, the region or the product?</h2>
              <Patterns patterns={diagnostics.patterns} hasOptional={diagnostics.available.length > 0} nameOf={nameOf} onOpen={open} onGoData={() => go('data')} />
            </section>
            <section>
              <h2 className="mb-3 text-lg font-semibold text-ink">Where risk sits in the network</h2>
              <Charts dealers={scored} onOpen={open} />
            </section>
          </div>
        )}

        {page === 'data' && (
          <DataPage
            source={source}
            imported={imported}
            onSetSource={switchSource}
            onImport={(set) => { setImported(set); switchSource('imported'); }}
            onRemoveImported={() => { setImported(null); switchSource('synthetic'); }}
            onGoDashboard={() => go('dashboard')}
          />
        )}

        {page === 'methodology' && <Method example={example} />}

        <footer className="mt-10 border-t border-steel-200 pt-4 text-center text-xs text-steel-500">
          Dealer Command Center · prototype · {dataLabel}
          {source === 'synthetic' || imported?.fileName === DIAGNOSTIC_SAMPLE_NAME ? ' — no real manufacturer or dealer data is used.' : ` — ${imported?.fileName}, scored with the same illustrative model.`} Root-cause outputs are hypotheses, not confirmed causes.
        </footer>
      </main>

      <DealerDetail dealer={selected} onClose={close} networkAvg={avg} dataLabel={dataLabel} diag={selected ? diagnostics.byDealer.get(selected.dealer_id) : undefined} nameOf={nameOf} onOpen={open} onGoData={() => { setSelectedId(null); go('data'); }} />
      {demo && steps.length > 0 && <Demo steps={steps} onSetPage={setPage} onSetDealer={open} onExit={exitDemo} />}
    </div>
  );
}
