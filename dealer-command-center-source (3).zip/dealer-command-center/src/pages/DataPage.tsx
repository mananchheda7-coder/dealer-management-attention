import { useEffect, useRef, useState } from 'react';
import type { Dealer } from '../data/dealers';
import { DEALERS } from '../data/dealers';
import type { ImportReport } from '../data/importDealers';
import { analyzeTable, buildTemplateCsv, FIELDS, OPTIONAL_FIELDS, readFileToTable, toCsv } from '../data/importDealers';
import { saveCsv, warmDownloads, type SaveOutcome } from '../lib/download';
import { buildDiagnosticSample, DIAGNOSTIC_SAMPLE_NAME } from '../data/diagnosticSample';
import { Panel } from '../components/ui';

export type Source = 'synthetic' | 'imported';
export interface ImportedSet { dealers: Dealer[]; fileName: string; importedAt: string }

interface Props {
  source: Source;
  imported: ImportedSet | null;
  onSetSource: (s: Source) => void;
  onImport: (set: ImportedSet) => void;
  onRemoveImported: () => void;
  onGoDashboard: () => void;
}

const STEPS = ['Upload file', 'Validate', 'Preview', 'Confirm import'];

const UNLOCKS: Record<string, string> = {
  product_category: 'Product-specific issues across dealers',
  product_complaint_rate: 'Storage vs product vs service causes',
  product_damage_rate: 'Transport / logistics issues',
  transport_complaint_rate: 'Transport / logistics issues',
  delivery_delay_days: 'Transport / logistics issues',
  storage_age_days: 'Storage / handling deterioration',
  lead_volume: 'Sales execution gap',
  conversion_rate: 'Sales execution gap',
  competitor_price_index: 'Competitive value gap',
  competitor_market_share: 'Competitive value gap',
  competitor_share_change: 'Competitive value gap',
  competitor_promotion_index: 'Competitive value gap',
  sales_rep_performance: 'Sales execution gap',
  service_resolution_days: 'Dealer customer-service gap',
  prev_inventory_age_days: 'What changed? (inventory trend)',
  prev_payment_delay_days: 'What changed? (payment trend)',
  prev_complaints_per_100: 'What changed? (complaint trend)',
  prev_service_performance: 'What changed? (service trend)',
};

export default function DataPage({ source, imported, onSetSource, onImport, onRemoveImported, onGoDashboard }: Props) {
  const input = useRef<HTMLInputElement>(null);
  const [report, setReport] = useState<ImportReport | null>(null);
  const [readError, setReadError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [justImported, setJustImported] = useState<string | null>(null);
  const [drag, setDrag] = useState(false);
  const [saveMsg, setSaveMsg] = useState<{ tone: 'ok' | 'warn'; text: string } | null>(null);
  useEffect(() => warmDownloads(), []);

  async function download(filename: string, csv: string, what: string) {
    setSaveMsg(null);
    const r: SaveOutcome = await saveCsv(filename, csv);
    const msg: Record<SaveOutcome, { tone: 'ok' | 'warn'; text: string }> = {
      saved: { tone: 'ok', text: `${what} saved as ${filename}.` },
      downloaded: { tone: 'ok', text: `${what} downloaded as ${filename}.` },
      declined: { tone: 'warn', text: 'Download cancelled.' },
      busy: { tone: 'warn', text: 'A save prompt is already open — finish it, then try again.' },
      failed: { tone: 'warn', text: 'The download could not start in this browser. The template is also in sample-data/ in the source package.' },
    };
    setSaveMsg(msg[r]);
  }

  // Steps reached: upload only → upload/validate/preview → all four when the file can be imported
  const reached = report ? (report.canImport ? 3 : 2) : 0;

  async function handleFile(file: File | undefined) {
    if (!file) return;
    setReadError(null);
    setJustImported(null);
    if (!/\.(csv|txt|xlsx|xls)$/i.test(file.name)) {
      setReport(null);
      setReadError(`${file.name} is not a CSV or Excel file. Upload a .csv or .xlsx file.`);
      return;
    }
    setBusy(true);
    try {
      const table = await readFileToTable(file);
      setReport(analyzeTable(table, file.name));
    } catch {
      setReport(null);
      setReadError(`${file.name} could not be read. Save it as CSV (UTF-8) or .xlsx and try again.`);
    } finally {
      setBusy(false);
      if (input.current) input.current.value = '';
    }
  }

  function loadSample() {
    setReadError(null);
    setJustImported(null);
    const csv = toCsv(buildDiagnosticSample());
    setReport(analyzeTable(csv.split('\n').map((l) => l.split(',')), DIAGNOSTIC_SAMPLE_NAME));
  }

  function confirm() {
    if (!report?.canImport) return;
    onImport({ dealers: report.dealers, fileName: report.fileName, importedAt: new Date().toLocaleString() });
    setJustImported(`${report.dealers.length} dealers imported from ${report.fileName}. Every score, flag, priority, chart and recommendation now uses this data.`);
    setReport(null);
  }

  const seg = (active: boolean) =>
    `flex-1 rounded-md px-4 py-3 text-left transition-colors ${active ? 'bg-cab text-white' : 'bg-white text-ink hover:bg-steel-50'} disabled:cursor-not-allowed disabled:opacity-50`;

  return (
    <div className="space-y-6">
      {/* Data source */}
      <Panel id="data-source" title="Data source" subtitle="Every page uses the dataset selected here. Synthetic demo data is always available.">
        <div role="radiogroup" aria-label="Data source" className="flex flex-col gap-2 rounded-lg border border-steel-200 bg-steel-50 p-1.5 sm:flex-row">
          <button role="radio" aria-checked={source === 'synthetic'} className={seg(source === 'synthetic')} onClick={() => onSetSource('synthetic')}>
            <span className="block font-semibold">Synthetic Demo Data</span>
            <span className={`block text-xs ${source === 'synthetic' ? 'text-steel-200' : 'text-steel-500'}`}>{DEALERS.length} designed dealers · Synthetic Data | Illustrative Scoring Model</span>
          </button>
          <button role="radio" aria-checked={source === 'imported'} disabled={!imported} className={seg(source === 'imported')} onClick={() => onSetSource('imported')}>
            <span className="block font-semibold">Imported Data</span>
            <span className={`block text-xs ${source === 'imported' ? 'text-steel-200' : 'text-steel-500'}`}>
              {imported ? `${imported.dealers.length} dealers from ${imported.fileName}${imported.fileName === DIAGNOSTIC_SAMPLE_NAME ? ' (synthetic)' : ''} · ${imported.importedAt}` : 'Nothing imported yet — use Import Dealer Data below'}
            </span>
          </button>
        </div>
        {imported && (
          <div className="mt-3 flex items-center justify-between text-sm">
            <span className="text-steel-500">Imported data is kept for this browser session only. Nothing is uploaded to a server.</span>
            <button onClick={onRemoveImported} className="font-medium text-crit hover:underline">Remove imported data</button>
          </div>
        )}
      </Panel>

      {justImported && (
        <div role="status" className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-ok/40 bg-ok-soft px-5 py-3 text-sm text-ink">
          <span><span className="font-semibold text-ok">✓ Import complete.</span> {justImported}</span>
          <button onClick={onGoDashboard} className="rounded bg-cab px-3 py-1.5 font-medium text-white hover:bg-ink">View dashboard</button>
        </div>
      )}

      {/* Import */}
      <Panel id="import" title="Import dealer data" subtitle="Upload your own dealers as CSV or Excel (.xlsx). The file is checked before anything changes.">
        <ol className="mb-5 flex flex-wrap gap-x-6 gap-y-1 text-sm">
          {STEPS.map((s, i) => (
            <li key={s} className={`flex items-center gap-2 ${i <= reached ? 'font-medium text-ink' : 'text-steel-400'}`}>
              <span className={`flex h-5 w-5 items-center justify-center rounded-full font-cond text-xs ${i <= reached ? 'bg-info text-white' : 'bg-steel-100 text-steel-500'}`}>{i + 1}</span>
              {s}
            </li>
          ))}
        </ol>

        {!report && (
          <div
            onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => { e.preventDefault(); setDrag(false); handleFile(e.dataTransfer.files[0]); }}
            className={`flex flex-col items-center gap-3 rounded-lg border-2 border-dashed px-6 py-10 text-center ${drag ? 'border-info bg-info/5' : 'border-steel-200 bg-steel-50'}`}
          >
            <button onClick={() => input.current?.click()} disabled={busy} className="rounded bg-info px-5 py-2.5 text-sm font-semibold text-white hover:bg-[#3B78BE] disabled:opacity-60">
              {busy ? 'Reading file…' : 'Import Dealer Data'}
            </button>
            <input ref={input} type="file" accept=".csv,.xlsx,.xls,text/csv" className="hidden" data-testid="file-input" onChange={(e) => handleFile(e.target.files?.[0])} />
            <p className="text-sm text-steel-500">or drop a .csv or .xlsx file here. One row per dealer, one header row.</p>
          </div>
        )}
        {!report && (
          <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 rounded-lg border border-steel-200 bg-white px-4 py-3" data-testid="template-box">
            <button
              onClick={() => download('dealer-data-template.csv', buildTemplateCsv(), 'Data template')}
              className="inline-flex items-center gap-2 rounded bg-cab px-4 py-2 text-sm font-semibold text-white hover:bg-ink"
            >
              <span aria-hidden>⬇</span> Download Data Template
            </button>
            <p className="min-w-[16rem] flex-1 text-[13px] text-steel-700">
              Download the template, add your dealer data, then upload it above. Optional diagnostic fields unlock deeper root-cause analysis.
              <span className="block text-xs text-steel-500">CSV with the importer's exact column names: required core fields first, then optional diagnostic and previous-period fields. Rows starting with # are guidance and examples, and are skipped on import.</span>
            </p>
            <button onClick={() => download('synthetic-dealers.csv', toCsv(DEALERS), 'Synthetic dataset')} className="text-xs font-medium text-info hover:underline">
              Or download the 50 synthetic dealers as CSV
            </button>
            {saveMsg && <p role="status" className={`w-full text-[13px] ${saveMsg.tone === 'ok' ? 'text-ok' : 'text-warn'}`} data-testid="save-msg">{saveMsg.text}</p>}
          </div>
        )}
        {!report && (
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-lg border border-steel-200 px-4 py-3">
            <div className="text-sm">
              <div className="font-medium text-ink">See what deeper data unlocks</div>
              <div className="text-steel-500">Load the synthetic diagnostic sample: the same 50 dealers plus optional fields (product, transport, funnel, competitor, service). Clearly labelled as synthetic.</div>
            </div>
            <button onClick={loadSample} className="whitespace-nowrap rounded border border-info px-3 py-1.5 text-sm font-medium text-info hover:bg-info/10">
              Load diagnostic sample
            </button>
          </div>
        )}

        {readError && <p role="alert" className="mt-3 rounded border border-crit/30 bg-crit-soft px-4 py-2.5 text-sm text-crit">{readError}</p>}

        {report && (
          <div className="space-y-5" data-testid="import-report">
            {/* Validation summary */}
            <div className="rounded-lg border border-steel-200 p-4">
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <h3 className="font-semibold text-ink">Validation · {report.fileName}</h3>
                <span className="text-sm text-steel-500">
                  {report.rows.length} dealer rows · {report.validCount} valid · {report.invalidCount} invalid
                </span>
              </div>
              <ul className="mt-3 space-y-1.5 text-sm">
                {report.validCount > 0 && <li className="text-ok">✓ {report.validCount} valid dealer{report.validCount > 1 ? 's' : ''}{report.growthFromPct ? ' (previous-year sales derived from Sales growth %)' : ''}</li>}
                {report.skippedRows > 0 && report.rows.length > 0 && <li className="text-steel-500">• {report.skippedRows} template guidance/example row{report.skippedRows > 1 ? 's' : ''} (starting with #) skipped</li>}
                {report.summary.map((s, i) => (
                  <li key={i} className={s.tone === 'error' ? 'text-crit' : 'text-warn'}>{s.tone === 'error' ? '✕' : '⚠'} {s.text}</li>
                ))}
                <li className={`pt-1 font-semibold ${report.canImport ? 'text-ok' : 'text-crit'}`} data-testid="import-verdict">
                  {report.canImport
                    ? `Ready to import ${report.validCount} dealers${report.warningCount ? ` — ${report.warningCount} with values worth double-checking` : ''}.`
                    : 'Import blocked until the issues above are fixed in the file. Nothing has been changed.'}
                </li>
              </ul>
              {report.missingColumns.length > 0 && (
                <p className="mt-3 text-[13px] text-steel-700">
                  Columns found: {report.headerRow.filter(Boolean).join(', ') || 'none'}. See the required columns below — header names are matched loosely, so “Inventory Ageing (days)” or “Payment Delay” also work.
                </p>
              )}
              {report.ignoredColumns.length > 0 && <p className="mt-2 text-xs text-steel-500">Ignored extra columns: {report.ignoredColumns.join(', ')}</p>}
              {report.missingColumns.length === 0 && (
                <p className="mt-2 text-[13px] text-steel-700" data-testid="optional-found">
                  {(() => {
                    const diag = report.optionalFound.filter((f) => f.group !== 'history');
                    const hist = report.optionalFound.filter((f) => f.group === 'history');
                    const filled = (k: string) => report.dealers.some((d) => (d as unknown as Record<string, unknown>)[k] !== undefined);
                    const diagFilled = diag.filter((f) => filled(f.key as string));
                    return (
                      <>
                        {diagFilled.length
                          ? `Optional diagnostic columns found (${diagFilled.length}): ${diagFilled.map((f) => f.label).join(', ')}. These unlock deeper root-cause diagnostics; blank cells stay blank.`
                          : 'No optional diagnostic data — deeper diagnostics will be unavailable and each hypothesis will state which data would validate it.'}
                        {hist.some((f) => filled(f.key as string)) && ' Previous-period values found: “What changed?” will be shown for those dealers.'}
                      </>
                    );
                  })()}
                </p>
              )}
            </div>

            {/* Preview */}
            {report.rows.length > 0 && (
              <div>
                <h3 className="mb-2 text-sm font-semibold text-ink">Preview · first {Math.min(8, report.rows.length)} of {report.rows.length} rows</h3>
                <div className="overflow-x-auto rounded-lg border border-steel-200">
                  <table className="w-full min-w-[900px] text-[13px]">
                    <thead className="bg-steel-50 text-left text-xs text-steel-500">
                      <tr>{['Row', 'Status', 'Dealer ID', 'Dealer', 'Region', 'City', 'Target', 'Sales', 'Stock age', 'Pay delay', 'Service', 'Complaints', 'Sold', 'Mkt potential'].map((h) => <th key={h} className="whitespace-nowrap px-3 py-2 font-medium">{h}</th>)}</tr>
                    </thead>
                    <tbody>
                      {report.rows.slice(0, 8).map((r) => (
                        <tr key={r.row} className={`border-t border-steel-100 ${r.dealer ? '' : 'bg-crit-soft/50'}`}>
                          <td className="px-3 py-1.5 text-steel-500 tnum">{r.row}</td>
                          <td className="px-3 py-1.5" title={[...r.errors, ...r.warnings].map((x) => x.message).join('\n')}>
                            {r.dealer ? (r.warnings.length ? <span className="text-warn">⚠ Check</span> : <span className="text-ok">✓ Valid</span>) : <span className="text-crit">✕ {r.errors[0]?.message}</span>}
                          </td>
                          {(['dealer_id', 'dealer_name', 'region', 'city', 'sales_target', 'actual_sales', 'inventory_age_days', 'payment_delay_days', 'service_performance', 'customer_complaints', 'vehicles_sold', 'market_potential'] as const).map((k) => (
                            <td key={k} className="whitespace-nowrap px-3 py-1.5 text-ink tnum">{r.raw[k] ?? ''}</td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {report.rows.some((r) => r.errors.length || r.warnings.length) && (
                  <details className="mt-2 text-[13px]">
                    <summary className="cursor-pointer font-medium text-info">All row issues ({report.rows.reduce((n, r) => n + r.errors.length + r.warnings.length, 0)})</summary>
                    <ul className="mt-2 max-h-48 space-y-0.5 overflow-y-auto">
                      {report.rows.flatMap((r) => [...r.errors.map((e) => ['✕', e] as const), ...r.warnings.map((w) => ['⚠', w] as const)]).map(([icon, x], i) => (
                        <li key={i} className={icon === '✕' ? 'text-crit' : 'text-warn'}>{icon} Row {x.row}: {x.message}</li>
                      ))}
                    </ul>
                  </details>
                )}
              </div>
            )}

            <div className="flex flex-wrap gap-2 border-t border-steel-100 pt-4">
              <button onClick={confirm} disabled={!report.canImport} className="rounded bg-cab px-5 py-2 text-sm font-semibold text-white hover:bg-ink disabled:cursor-not-allowed disabled:bg-steel-200 disabled:text-steel-500">
                Confirm Import
              </button>
              <button onClick={() => setReport(null)} className="rounded border border-steel-200 px-5 py-2 text-sm font-medium text-ink hover:border-info hover:text-info">
                Cancel
              </button>
            </div>
          </div>
        )}
      </Panel>

      {/* Schema reference */}
      <Panel id="core-columns" title="Core data — required" subtitle="The fields the health score and priority model read. Missing columns block the import; no values are ever filled in for you.">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-[13px]">
            <thead className="border-b border-steel-200 text-left text-xs text-steel-500">
              <tr><th className="py-1.5 font-medium">Column</th><th className="font-medium">Meaning</th><th className="font-medium">Unit</th><th className="font-medium">Rule</th><th className="font-medium">Also accepted as</th></tr>
            </thead>
            <tbody>
              {FIELDS.map((f) => (
                <tr key={f.key} className="border-b border-steel-100">
                  <td className="py-1.5 pr-3 font-mono text-[12px] text-ink">{f.key}</td>
                  <td className="pr-3 text-ink">{f.label}{f.key === 'sales_growth_pct' && <span className="text-steel-500"> (optional)</span>}</td>
                  <td className="pr-3 text-steel-700">{f.unit}</td>
                  <td className="pr-3 text-steel-700">{f.rule}</td>
                  <td className="text-steel-500">{f.aliases.slice(0, 3).join(', ')}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-steel-500">Derived automatically: sales achievement %, sales growth %, complaints per 100 vehicles, stock cover and capital at risk.</p>
      </Panel>

      <Panel id="optional-columns" title="Diagnostic data — optional" subtitle="Not required: the application works fully without them. When present, they let the root-cause layer test transport, product, sales-funnel, competitor and service hypotheses, and previous-period values enable “What changed?”. They never change health scores or priorities.">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-[13px]">
            <thead className="border-b border-steel-200 text-left text-xs text-steel-500">
              <tr><th className="py-1.5 font-medium">Column</th><th className="font-medium">Meaning</th><th className="font-medium">Unit</th><th className="font-medium">Rule</th><th className="font-medium">Tests</th></tr>
            </thead>
            <tbody>
              {OPTIONAL_FIELDS.map((f) => (
                <tr key={f.key} className="border-b border-steel-100">
                  <td className="py-1.5 pr-3 font-mono text-[12px] text-ink">{f.key}</td>
                  <td className="pr-3 text-ink">{f.label}</td>
                  <td className="pr-3 text-steel-700">{f.unit}</td>
                  <td className="pr-3 text-steel-700">{f.rule}</td>
                  <td className="text-steel-500">{UNLOCKS[f.key as string]}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
}
