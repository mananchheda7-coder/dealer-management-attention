import type { ScoredDealer } from '../model/scoring';
import type { NetworkPattern } from '../model/diagnostics';
import { ConfidenceChip } from '../components/RootCause';
import Queue from '../components/Queue';
import { RISK_COLOR } from '../components/ui';

interface Props {
  scored: ScoredDealer[];
  queue: ScoredDealer[];
  pair: [ScoredDealer, ScoredDealer] | null;
  topPattern?: NetworkPattern;
  onOpen: (id: string) => void;
  onGo: (page: 'insights' | 'dealers') => void;
}

export default function Dashboard({ scored, queue, pair, topPattern, onOpen, onGo }: Props) {
  const count = (f: (d: ScoredDealer) => boolean) => scored.filter(f).length;
  const avg = Math.round(scored.reduce((s, d) => s + d.health_score, 0) / scored.length);
  const p1 = count((d) => d.priority === 'P1');
  const hiddenP1 = count((d) => d.priority === 'P1' && d.risk_level !== 'Critical');

  const kpis = [
    { label: 'Total dealers', value: scored.length, note: `${new Set(scored.map((d) => d.region)).size} regions, ${new Set(scored.map((d) => d.city)).size} cities` },
    { label: 'Critical dealers', value: count((d) => d.risk_level === 'Critical'), note: 'Health score 0–49', color: RISK_COLOR.Critical },
    { label: 'P1 dealers', value: p1, note: `Immediate attention · ${hiddenP1} not Critical on score`, strong: true },
    { label: 'Average health score', value: avg, note: 'out of 100' },
  ];

  return (
    <div className="space-y-5">
      <div>
        <h2 className="text-2xl font-semibold text-ink">Which dealers need management attention today?</h2>
        <p className="mt-1 max-w-3xl text-[15px] text-steel-700">
          Each dealer below is ranked by urgency, with the reason it was flagged and the action management should take. Select a dealer for the full breakdown.
        </p>
      </div>

      <section id="kpis" aria-label="Key figures" className="grid grid-cols-2 gap-px overflow-hidden rounded-lg border border-steel-200 bg-steel-200 lg:grid-cols-4">
        {kpis.map((k) => (
          <div key={k.label} className={`px-5 py-3 ${k.strong ? 'bg-cab text-white' : 'bg-white'}`}>
            <div className={`text-xs ${k.strong ? 'text-steel-200' : 'text-steel-500'}`}>{k.label}</div>
            <div className="mt-1 font-cond text-4xl font-semibold leading-none tnum" style={{ color: k.strong ? '#fff' : k.color ?? '#18222F' }}>{k.value}</div>
            <div className={`mt-1.5 text-[11px] ${k.strong ? 'text-steel-200' : 'text-steel-500'}`}>{k.note}</div>
          </div>
        ))}
      </section>

      <Queue queue={queue} p1Count={p1} onOpen={onOpen} />

      <div className="grid gap-4 lg:grid-cols-3" data-testid="essential-insights">
        {pair ? (
          <button onClick={() => onGo('insights')} className="group rounded-lg border border-steel-200 bg-white p-5 text-left hover:border-info">
            <div className="text-sm font-semibold text-ink">Key insight: sales alone do not reveal sustainable dealer health</div>
            <div className="mt-3 grid grid-cols-2 gap-4 text-sm">
              {pair.map((d, i) => (
                <div key={d.dealer_id}>
                  <div className="font-medium text-ink">{d.dealer_name}</div>
                  <div className="text-steel-700">
                    {d.sales_achievement_pct}% of target → health{' '}
                    <span className="font-cond text-lg font-semibold" style={{ color: RISK_COLOR[d.risk_level] }}>{d.health_score}</span>, {d.priority}
                  </div>
                  <div className="text-xs text-steel-500">{i === 0 ? 'Higher sales, needs attention' : 'Lower sales, healthier'}</div>
                </div>
              ))}
            </div>
            <div className="mt-3 text-sm font-medium text-info group-hover:underline">See the full comparison in Insights</div>
          </button>
        ) : (
          <div className="rounded-lg border border-steel-200 bg-white p-5 text-sm text-steel-700">
            <div className="font-semibold text-ink">Key insight: sales alone do not reveal sustainable dealer health</div>
            <p className="mt-2">Insights shows how risk spreads across the network, including dealers that sell well while stock or payments deteriorate.</p>
          </div>
        )}
        <button onClick={() => onGo('insights')} className="group rounded-lg border border-steel-200 bg-white p-5 text-left hover:border-info">
          <div className="text-sm font-semibold text-ink">Dealer, region or product?</div>
          {topPattern ? (
            <>
              <div className="mt-2 flex flex-wrap items-center gap-2 text-sm">
                <span className="font-medium text-ink">{topPattern.title}</span>
                <ConfidenceChip c={topPattern.confidence} />
              </div>
              <p className="mt-1 text-[13px] text-steel-700">Possible {topPattern.scope.toLowerCase()} cause — avoid treating these as separate dealer failures. Requires validation.</p>
            </>
          ) : (
            <p className="mt-2 text-sm text-steel-700">No regional or product concentration detected; issues appear dealer-specific.</p>
          )}
          <div className="mt-3 text-sm font-medium text-info group-hover:underline">See cross-dealer patterns</div>
        </button>
        <button onClick={() => onGo('dealers')} className="group rounded-lg border border-steel-200 bg-white p-5 text-left hover:border-info">
          <div className="text-sm font-semibold text-ink">All {scored.length} dealers</div>
          <p className="mt-2 text-sm text-steel-700">
            {count((d) => d.priority === 'P2')} more are P2 (near-term attention) and {count((d) => d.priority === 'P3')} are P3 (monitor). Search, filter and sort the full network.
          </p>
          <div className="mt-3 text-sm font-medium text-info group-hover:underline">Open the dealer directory</div>
        </button>
      </div>
    </div>
  );
}
