// File downloads that work everywhere the app runs.
//
// • Hosted on claude.ai: browser downloads are blocked inside the hosted frame, so the
//   platform's `downloads` capability is used (the viewer confirms the save).
// • Anywhere else (npm run dev, a production build on any web server, the standalone
//   HTML file): a normal Blob/object-URL download.

interface DownloadsNs {
  save(req: { filename: string; data: string | Blob }): Promise<{ status: 'saved' | 'delivered' }>;
}
type ClaudeRuntime = { use?: (name: string) => Promise<unknown> };

let platform: Promise<DownloadsNs | null> | null = null;

function platformDownloads(): Promise<DownloadsNs | null> {
  const c = (window as unknown as { claude?: ClaudeRuntime }).claude;
  if (!c || typeof c.use !== 'function') return Promise.resolve(null);
  if (!platform) platform = (c.use('downloads') as Promise<DownloadsNs | null>).catch(() => null);
  return platform;
}

/** Resolve the platform capability early so a click can use it immediately. */
export function warmDownloads() {
  void platformDownloads();
}

export type SaveOutcome = 'saved' | 'downloaded' | 'declined' | 'busy' | 'failed';

function browserDownload(filename: string, blob: Blob): SaveOutcome {
  try {
    const url = URL.createObjectURL(blob);
    const a = Object.assign(document.createElement('a'), { href: url, download: filename, rel: 'noopener' });
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
    return 'downloaded';
  } catch {
    return 'failed';
  }
}

export async function saveCsv(filename: string, csv: string): Promise<SaveOutcome> {
  const text = '\uFEFF' + csv; // BOM so Excel opens UTF-8 (₹) correctly; the importer ignores it
  const dl = await platformDownloads();
  if (dl) {
    try {
      await dl.save({ filename, data: text });
      return 'saved';
    } catch (e) {
      const code = (e as { code?: string })?.code;
      if (code === 'declined') return 'declined';
      if (code === 'rate_limited') return 'busy';
      // 'unavailable' and lifecycle codes: fall back to a normal browser download
    }
  }
  return browserDownload(filename, new Blob([text], { type: 'text/csv;charset=utf-8' }));
}
