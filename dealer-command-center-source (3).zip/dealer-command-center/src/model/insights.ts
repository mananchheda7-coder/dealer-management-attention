import type { ScoredDealer } from './scoring';

/**
 * The "sales alone is not enough" pair. Uses D003 vs D009 when both exist and still tell
 * that story (synthetic data). For imported data, finds the strongest equivalent pair:
 * a high-sales dealer that needs attention vs a lower-sales dealer that is healthier.
 */
export function pickComparisonPair(scored: ScoredDealer[]): [ScoredDealer, ScoredDealer] | null {
  const a0 = scored.find((d) => d.dealer_id === 'D003');
  const b0 = scored.find((d) => d.dealer_id === 'D009');
  if (a0 && b0 && a0.sales_achievement_pct > b0.sales_achievement_pct && a0.health_score < b0.health_score) return [a0, b0];

  const candidates = scored
    .filter((d) => d.sales_achievement_pct >= 90 && d.priority !== 'P3')
    .sort((x, y) => y.sales_achievement_pct - y.health_score - (x.sales_achievement_pct - x.health_score));
  for (const a of candidates) {
    const b = scored
      .filter((d) => d.sales_achievement_pct < a.sales_achievement_pct && d.health_score > a.health_score && d.priority > a.priority)
      .sort((x, y) => y.health_score - x.health_score)[0];
    if (b) return [a, b];
  }
  return null;
}

/** Dealer the guided tour opens: D008 in synthetic data, else a strong-sales P1 in the top 5, else the top of the queue. */
export function pickFocusDealer(queue: ScoredDealer[]): ScoredDealer | null {
  const top = queue.slice(0, 5);
  return top.find((d) => d.dealer_id === 'D008') ?? top.find((d) => d.priority === 'P1' && d.sales_achievement_pct >= 90) ?? queue[0] ?? null;
}
