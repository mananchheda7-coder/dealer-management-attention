import type { Dealer, Region } from '../data/dealers';

// ───────────────────────────── Health score components ─────────────────────────────
// Each metric is normalised to 0–1 against fixed, business-readable anchors
// ("worst" earns 0 points, "best" earns full points, linear in between, clamped).
// Fixed anchors (rather than min–max of the current data) keep a dealer's score stable
// when other dealers change, and let a manager reason about "what would it take".

export type ComponentKey = 'sales' | 'growth' | 'inventory' | 'payment' | 'service' | 'complaints' | 'market';

export interface ComponentDef {
  key: ComponentKey;
  label: string;
  weight: number;
  worst: number;
  best: number;
  unit: string;
  higherIsBetter: boolean;
  plain: string; // non-technical explanation
}

export const COMPONENTS: ComponentDef[] = [
  { key: 'sales', label: 'Sales vs Target', weight: 25, worst: 50, best: 110, unit: '%', higherIsBetter: true, plain: 'Full points at 110% of target, zero at 50%.' },
  { key: 'growth', label: 'Sales Growth', weight: 15, worst: -20, best: 20, unit: '%', higherIsBetter: true, plain: 'Full points at +20% YoY, zero at −20%.' },
  { key: 'inventory', label: 'Inventory Ageing', weight: 15, worst: 90, best: 30, unit: ' days', higherIsBetter: false, plain: 'Full points at 30 days average stock age, zero at 90.' },
  { key: 'payment', label: 'Payment Delays', weight: 15, worst: 45, best: 0, unit: ' days', higherIsBetter: false, plain: 'Full points when paying on terms, zero at 45 days late.' },
  { key: 'service', label: 'Service Performance', weight: 10, worst: 55, best: 95, unit: '', higherIsBetter: true, plain: 'Full points at a service index of 95, zero at 55.' },
  { key: 'complaints', label: 'Customer Complaints', weight: 10, worst: 8, best: 1, unit: ' /100', higherIsBetter: false, plain: 'Full points at 1 complaint per 100 vehicles, zero at 8.' },
  { key: 'market', label: 'Market Potential', weight: 10, worst: 30, best: 95, unit: '', higherIsBetter: true, plain: 'Full points for a market potential index of 95, zero at 30.' },
];

export type RiskLevel = 'Healthy' | 'Watch' | 'Critical';
export type Priority = 'P1' | 'P2' | 'P3';
export type Severity = 'none' | 'moderate' | 'severe';
export type FlagKey = 'sales_risk' | 'inventory_risk' | 'payment_risk' | 'service_risk' | 'customer_risk' | 'market_opportunity';

export const FLAG_LABEL: Record<FlagKey, string> = {
  sales_risk: 'Sales risk',
  inventory_risk: 'Inventory risk',
  payment_risk: 'Payment risk',
  service_risk: 'Service risk',
  customer_risk: 'Customer risk',
  market_opportunity: 'Untapped market',
};

// Thresholds a regional manager can read and challenge.
export const THRESHOLDS = {
  sales: { moderateAch: 80, severeAch: 70, moderateGrowth: -3, severeGrowth: -12 },
  inventory: { moderate: 55, severe: 70 },
  payment: { moderate: 11, severe: 21 },
  service: { moderate: 78, severe: 68 },
  customer: { moderate: 4.0, severe: 5.5 },
  market: { potential: 75, achBelow: 85 },
  strongSales: 90,
};

export interface ComponentScore extends ComponentDef {
  value: number;
  normalized: number;
  points: number;
  lost: number;
}

export interface Flag {
  key: FlagKey;
  severity: Severity;
  reason: string;
}

export interface Action {
  title: string;
  detail: string;
  owner: string;
  due: string;
}

export interface ScoredDealer extends Dealer {
  sales_achievement_pct: number;
  sales_growth_pct: number;
  complaints_per_100: number;
  stock_cover_months: number;
  overdue_cr: number;
  excess_stock_cr: number;
  capital_at_risk_cr: number;
  components: ComponentScore[];
  health_score: number;
  risk_level: RiskLevel;
  flags: Record<FlagKey, Flag>;
  severe_count: number;
  moderate_count: number;
  priority: Priority;
  priority_reason: string;
  attention_index: number;
  primary_risk: string;
  why_short: string;
  why_flagged: string[];
  interpretation: string;
  headline_action: string;
  actions: Action[];
}

const clamp01 = (n: number) => Math.max(0, Math.min(1, n));
const r1 = (n: number) => Math.round(n * 10) / 10;

export function normalize(value: number, c: Pick<ComponentDef, 'worst' | 'best'>): number {
  return clamp01((value - c.worst) / (c.best - c.worst));
}

export function riskLevelFor(score: number): RiskLevel {
  if (score >= 75) return 'Healthy';
  if (score >= 50) return 'Watch';
  return 'Critical';
}

// Capital at risk (₹ crore): money the manufacturer has exposed at this dealer.
//   overdue = annual sales × payment delay / 365
//   excess stock = value of stock above a normal 1.25-month cover
export const NORMAL_COVER_MONTHS = 1.25;
export function capitalAtRisk(d: Dealer) {
  const ticketCr = d.actual_sales / d.vehicles_sold;
  const overdue = (d.actual_sales * d.payment_delay_days) / 365;
  const normalStock = (d.vehicles_sold / 12) * NORMAL_COVER_MONTHS;
  const excessStock = Math.max(0, d.inventory_units - normalStock) * ticketCr;
  return { overdue_cr: r1(overdue), excess_stock_cr: r1(excessStock), capital_at_risk_cr: r1(overdue + excessStock) };
}

export function derive(d: Dealer) {
  return {
    sales_achievement_pct: r1((d.actual_sales / d.sales_target) * 100),
    sales_growth_pct: r1(((d.actual_sales - d.previous_year_sales) / d.previous_year_sales) * 100),
    complaints_per_100: r1((d.customer_complaints / d.vehicles_sold) * 100),
    stock_cover_months: r1(d.inventory_units / (d.vehicles_sold / 12)),
    ...capitalAtRisk(d),
  };
}

export function scoreComponents(d: Dealer, m: ReturnType<typeof derive>): ComponentScore[] {
  const values: Record<ComponentKey, number> = {
    sales: m.sales_achievement_pct,
    growth: m.sales_growth_pct,
    inventory: d.inventory_age_days,
    payment: d.payment_delay_days,
    service: d.service_performance,
    complaints: m.complaints_per_100,
    market: d.market_potential,
  };
  return COMPONENTS.map((c) => {
    const normalized = normalize(values[c.key], c);
    const points = r1(normalized * c.weight);
    return { ...c, value: values[c.key], normalized, points, lost: r1(c.weight - points) };
  });
}

function sev(value: number, moderate: boolean, severe: boolean): Severity {
  void value;
  return severe ? 'severe' : moderate ? 'moderate' : 'none';
}

export function computeFlags(d: Dealer, m: ReturnType<typeof derive>): Record<FlagKey, Flag> {
  const T = THRESHOLDS;
  const ach = m.sales_achievement_pct;
  const g = m.sales_growth_pct;
  const salesSev = sev(ach, ach < T.sales.moderateAch || g < T.sales.moderateGrowth, ach < T.sales.severeAch || g <= T.sales.severeGrowth);
  const invSev = sev(0, d.inventory_age_days >= T.inventory.moderate, d.inventory_age_days >= T.inventory.severe);
  const paySev = sev(0, d.payment_delay_days >= T.payment.moderate, d.payment_delay_days >= T.payment.severe);
  const svcSev = sev(0, d.service_performance < T.service.moderate, d.service_performance < T.service.severe);
  const custSev = sev(0, m.complaints_per_100 >= T.customer.moderate, m.complaints_per_100 >= T.customer.severe);
  const opp = d.market_potential >= T.market.potential && (ach < T.market.achBelow || g < 0);
  const oppSev: Severity = opp ? (ach < 75 || g <= T.sales.severeGrowth ? 'severe' : 'moderate') : 'none';

  return {
    sales_risk: { key: 'sales_risk', severity: salesSev, reason: `${ach}% of target, ${g > 0 ? '+' : ''}${g}% YoY` },
    inventory_risk: { key: 'inventory_risk', severity: invSev, reason: `${d.inventory_age_days}-day average stock age` },
    payment_risk: { key: 'payment_risk', severity: paySev, reason: `${d.payment_delay_days} days beyond credit terms` },
    service_risk: { key: 'service_risk', severity: svcSev, reason: `service index ${d.service_performance}` },
    customer_risk: { key: 'customer_risk', severity: custSev, reason: `${m.complaints_per_100} complaints per 100 vehicles` },
    market_opportunity: { key: 'market_opportunity', severity: oppSev, reason: `market potential ${d.market_potential}, market +${d.market_growth}%` },
  };
}

const RISK_KEYS: FlagKey[] = ['sales_risk', 'inventory_risk', 'payment_risk', 'service_risk', 'customer_risk'];

// ─────────────────────────────── Management priority ───────────────────────────────
// Priority is NOT the health score re-labelled. A dealer with an acceptable overall
// score can still be P1 if it carries two severe risks — that is the "hidden risk" case.
export function computePriority(score: number, flags: Record<FlagKey, Flag>, growth: number, capitalAtRisk: number) {
  const severe = RISK_KEYS.filter((k) => flags[k].severity === 'severe');
  const moderate = RISK_KEYS.filter((k) => flags[k].severity === 'moderate');
  const opp = flags.market_opportunity.severity;
  const names = (ks: FlagKey[]) => ks.map((k) => FLAG_LABEL[k].toLowerCase()).join(' and ');

  let priority: Priority;
  let reason: string;
  if (score < 50) {
    priority = 'P1';
    reason = `Health score ${score} is in the critical band`;
  } else if (severe.length >= 2) {
    priority = 'P1';
    reason = `Two or more severe risks (${names(severe)}) despite a score of ${score}`;
  } else if (flags.sales_risk.severity === 'severe' && opp !== 'none') {
    priority = 'P1';
    reason = 'Sales are falling sharply in a market where demand is available';
  } else if (severe.length === 1) {
    priority = 'P2';
    reason = `One severe risk (${names(severe)})`;
  } else if (moderate.length >= 2) {
    priority = 'P2';
    reason = `Early warning: ${moderate.length} risks drifting past watch thresholds`;
  } else if (score < 65 || opp !== 'none') {
    priority = 'P2';
    reason = opp !== 'none' ? 'Under-performing against available market demand' : `Score of ${score} sits in the lower watch band`;
  } else {
    priority = 'P3';
    reason = moderate.length ? `One minor risk (${names(moderate)}); routine monitoring` : 'No risk thresholds breached';
  }

  // Attention index orders dealers within a priority band. It combines risk depth
  // (weak score, number and severity of risks, falling sales) with capital at risk
  // (₹ tied up in excess stock + overdue payments). Sales volume itself is never used.
  const attention =
    0.6 * (100 - score) +
    10 * severe.length +
    3 * moderate.length +
    (growth < 0 ? Math.abs(growth) * 0.4 : 0) +
    (opp === 'severe' ? 6 : opp === 'moderate' ? 3 : 0) +
    Math.min(35, 1.25 * capitalAtRisk);

  return { priority, reason, severeCount: severe.length, moderateCount: moderate.length, attention: r1(attention) };
}

// ───────────────────────────────── Explanations ─────────────────────────────────

export interface Benchmarks {
  regionComplaints: Record<Region, number>;
  networkService: number;
  networkInventoryAge: number;
}

const FLAG_COMPONENTS: Record<FlagKey, ComponentKey[]> = {
  sales_risk: ['sales', 'growth'],
  inventory_risk: ['inventory'],
  payment_risk: ['payment'],
  service_risk: ['service'],
  customer_risk: ['complaints'],
  market_opportunity: ['market'],
};

export function primaryRisk(flags: Record<FlagKey, Flag>, comps: ComponentScore[]): string {
  const rank = { severe: 2, moderate: 1, none: 0 } as const;
  const lost = (k: FlagKey) => comps.filter((c) => FLAG_COMPONENTS[k].includes(c.key)).reduce((s, c) => s + c.lost, 0);
  const candidates = RISK_KEYS.filter((k) => flags[k].severity !== 'none').sort(
    (a, b) => rank[flags[b].severity] - rank[flags[a].severity] || lost(b) - lost(a),
  );
  if (candidates.length) return FLAG_LABEL[candidates[0]];
  if (flags.market_opportunity.severity !== 'none') return FLAG_LABEL.market_opportunity;
  return 'None';
}

function whyFlagged(d: Dealer, m: ReturnType<typeof derive>, flags: Record<FlagKey, Flag>, b: Benchmarks): string[] {
  const out: string[] = [];
  const ach = m.sales_achievement_pct;
  const g = m.sales_growth_pct;
  const regAvg = b.regionComplaints[d.region];
  const signed = (n: number) => `${n > 0 ? '+' : ''}${n}%`;

  if (flags.sales_risk.severity !== 'none') {
    out.push(
      `Sales are at ${ach}% of target (₹${d.actual_sales} Cr vs ₹${d.sales_target} Cr) and ${g < 0 ? `${Math.abs(g)}% below` : `only ${signed(g)} on`} last year.`,
    );
  } else if (ach >= THRESHOLDS.strongSales) {
    out.push(`Sales achievement remains strong at ${ach}% of target, with ${signed(g)} growth — on a sales report this dealer looks fine.`);
  } else {
    out.push(`Sales are steady at ${ach}% of target with ${signed(g)} growth.`);
  }

  const inv = flags.inventory_risk.severity;
  if (inv !== 'none')
    out.push(
      `Inventory has aged to ${d.inventory_age_days} days on average (network ${b.networkInventoryAge} days); ${d.inventory_units} units in stock is ${m.stock_cover_months} months of sales.`,
    );
  if (flags.payment_risk.severity !== 'none')
    out.push(`Payments are running ${d.payment_delay_days} days beyond credit terms${flags.payment_risk.severity === 'severe' ? ', raising the manufacturer\u2019s credit exposure' : ''}.`);
  if (flags.customer_risk.severity !== 'none')
    out.push(`Complaint rate is ${m.complaints_per_100} per 100 vehicles against a ${d.region} region average of ${regAvg}.`);
  if (flags.service_risk.severity !== 'none')
    out.push(`Service performance index is ${d.service_performance}, below the network average of ${b.networkService}.`);
  if (flags.market_opportunity.severity !== 'none')
    out.push(`Local market potential remains strong (index ${d.market_potential}, market growing ${d.market_growth}%) — demand is available.`);
  else if (flags.sales_risk.severity !== 'none' && d.market_potential < 50)
    out.push(`Local market potential is limited (index ${d.market_potential}, market growing ${d.market_growth}%), which explains part of the shortfall.`);

  if (out.length === 1) {
    out.push(
      `Inventory age (${d.inventory_age_days} days), payment discipline (${d.payment_delay_days} days late) and complaints (${m.complaints_per_100}/100) are all within thresholds.`,
    );
  }
  return out.slice(0, 5);
}

function interpret(d: Dealer, m: ReturnType<typeof derive>, flags: Record<FlagKey, Flag>, severe: number, moderate: number): string {
  const s = (k: FlagKey) => flags[k].severity;
  const has = (k: FlagKey) => s(k) !== 'none';
  const strong = m.sales_achievement_pct >= THRESHOLDS.strongSales && !has('sales_risk');

  if (severe >= 3)
    return 'Problems in sales, stock, cash and customer experience are reinforcing each other. Incremental fixes will not work here — this dealer needs a structured turnaround plan with clear 30/60/90-day milestones and senior oversight.';
  if (strong && has('inventory_risk') && has('payment_risk'))
    return 'Strong sales are masking emerging inventory and payment stress. Stock is being pushed in faster than it turns into paid-for retail. Management attention should focus on inventory turnover and payment discipline rather than simply increasing sales targets.';
  if (strong && (has('service_risk') || has('customer_risk')))
    return 'Sales are strong, but the after-sales experience is deteriorating. Complaints and weak service are lead indicators: they erode repeat purchase and referrals before they show up in sales. Fix the customer experience while volumes are still healthy.';
  if (strong && has('payment_risk'))
    return 'Commercial performance is sound; the issue is financial discipline. Each additional allocation increases the manufacturer\u2019s exposure, so credit terms should be enforced before stock is increased.';
  if (strong && has('inventory_risk'))
    return 'The dealer sells well but is carrying more, and older, stock than it can turn. Ageing stock leads to forced discounting and margin erosion. Allocation should be matched to the actual retail run-rate.';
  if (has('sales_risk') && has('market_opportunity'))
    return 'The local market is growing, but this dealer is losing ground. This is an execution problem, not a demand problem — the gap is being captured by competitors. Investigate sales process, staffing and local marketing before revising targets.';
  if (has('sales_risk') && d.market_potential < 50)
    return 'The shortfall is largely consistent with a small, slow-growing market. Escalation is unlikely to change the outcome; right-size targets and allocation, and protect operational discipline.';
  if (has('sales_risk') && (has('inventory_risk') || has('payment_risk')))
    return 'Falling sales are starting to feed into stock build-up and cash pressure. Intervene now, before slower sales turn into a payment problem for the manufacturer.';
  if (has('service_risk') || has('customer_risk'))
    return 'Sales are holding, but the customer experience is eroding. Complaint and service trends tend to show up in future sales and loyalty, so this is the time to correct them.';
  if (has('payment_risk'))
    return 'The operational picture is acceptable, but payment discipline is slipping. Tighten credit review before the delay becomes a pattern.';
  if (has('inventory_risk'))
    return 'Stock is building faster than it sells. Rebalance allocation before ageing stock forces discounting.';
  if (has('sales_risk'))
    return 'Sales momentum is weakening without wider operational stress yet. A focused sales review should be enough to correct course.';
  if (has('market_opportunity'))
    return 'The dealer is operationally sound but is not capturing the demand available locally. There is upside here if sales capacity is strengthened.';
  if (moderate === 0 && m.sales_achievement_pct >= 100)
    return 'Performance is sustainable across sales, operations and customers. No intervention needed — this dealer is a useful benchmark for practices to share across the region.';
  return 'Performance is balanced and sustainable. Routine monitoring is sufficient; no intervention is needed.';
}

function recommend(d: Dealer, m: ReturnType<typeof derive>, flags: Record<FlagKey, Flag>, priority: Priority, severeCount: number): { headline: string; actions: Action[] } {
  const s = (k: FlagKey) => flags[k].severity;
  const has = (k: FlagKey) => s(k) !== 'none';
  const actions: Action[] = [];
  let headline = '';
  const strong = m.sales_achievement_pct >= THRESHOLDS.strongSales;

  if (severeCount >= 3) {
    const areas = (['sales_risk', 'inventory_risk', 'payment_risk', 'service_risk', 'customer_risk'] as FlagKey[])
      .filter((k) => s(k) === 'severe')
      .map((k) => ({ sales_risk: 'sales', inventory_risk: 'stock', payment_risk: 'payments', service_risk: 'service', customer_risk: 'customer experience', market_opportunity: '' })[k]);
    headline = `Launch a structured turnaround plan covering ${areas.slice(0, -1).join(', ')} and ${areas[areas.length - 1]}.`;
    actions.push({ title: 'Appoint a turnaround owner', detail: `One accountable regional owner for a 30/60/90-day plan covering all ${severeCount} severe risks below, reviewed fortnightly.`, owner: 'Regional manager', due: '7 days' });
  }
  if (strong && has('inventory_risk') && has('payment_risk')) {
    headline = 'Prioritize inventory reduction and payment recovery before increasing stock allocation.';
    actions.push({ title: 'Freeze incremental allocation', detail: `Hold new stock allocation until average stock age falls below ${THRESHOLDS.inventory.moderate} days and payments are back on terms.`, owner: 'Regional sales planning', due: 'Immediately' });
  }
  if (has('inventory_risk')) {
    actions.push({ title: 'Review inventory allocation', detail: `Re-base allocation on the actual retail run-rate (${Math.round(d.vehicles_sold / 12)} units/month) instead of target.`, owner: 'Regional sales planning', due: '7 days' });
    actions.push({ title: 'Create a stock liquidation plan', detail: `Identify units older than 60 days within the ${d.inventory_units}-unit stock; plan inter-dealer transfers or targeted retail schemes.`, owner: 'Dealer principal + area manager', due: '14 days' });
  }
  if (has('payment_risk')) {
    actions.push({ title: 'Conduct a credit and payment review', detail: `Reconcile overdue amounts (${d.payment_delay_days} days late) and agree a dated recovery plan.`, owner: 'Finance / dealer credit', due: s('payment_risk') === 'severe' ? '7 days' : '30 days' });
    if (s('payment_risk') === 'severe') actions.push({ title: 'Tighten credit terms', detail: 'Move to pay-before-dispatch for new allocations until the recovery plan is met.', owner: 'Finance / dealer credit', due: 'Until recovered' });
  }
  if (has('sales_risk') && has('market_opportunity')) {
    if (!headline) headline = 'Investigate dealer execution because market demand appears available.';
    actions.push({ title: 'Investigate dealer execution', detail: `Market potential index is ${d.market_potential} and the market is growing ${d.market_growth}%. Audit lead conversion, sales staffing and test-drive follow-up.`, owner: 'Area sales manager', due: '14 days' });
  }
  if (has('sales_risk')) {
    if (!headline) headline = 'Review dealer sales funnel, local competition and sales productivity.';
    actions.push({ title: 'Review sales funnel and productivity', detail: `Sales are ${m.sales_growth_pct}% YoY. Compare enquiry-to-booking ratios and sales per consultant against regional peers; map local competitor activity.`, owner: 'Area sales manager', due: '30 days' });
    if (d.market_potential < 50) actions.push({ title: 'Right-size target and allocation', detail: `Market potential index of ${d.market_potential} suggests the target may exceed what the territory can absorb.`, owner: 'Regional sales planning', due: 'Next planning cycle' });
  } else if (has('market_opportunity')) {
    if (!headline) headline = 'Investigate dealer execution because market demand appears available.';
    actions.push({ title: 'Capture available demand', detail: `Market potential index is ${d.market_potential}; agree a capacity plan (sales staff, outlet coverage, local activation).`, owner: 'Area sales manager', due: '30 days' });
  }
  if (has('customer_risk')) {
    if (!headline) headline = 'Conduct a customer experience and service quality review.';
    actions.push({ title: 'Customer experience and service quality review', detail: `Review all complaints behind the ${m.complaints_per_100}/100 rate; categorise by delivery, workshop and sales-process issues.`, owner: 'Customer quality team', due: '14 days' });
  }
  if (has('service_risk')) {
    if (!headline) headline = 'Conduct a service-center performance review and identify recurring complaint categories.';
    actions.push({ title: 'Service-center performance review', detail: `Service index is ${d.service_performance}. Audit workshop turnaround, first-time-fix rate and technician capacity; identify recurring complaint categories.`, owner: 'After-sales manager', due: '30 days' });
  }

  if (priority === 'P1') {
    actions.push({ title: 'Schedule regional manager intervention', detail: 'On-site review with the dealer principal; agree owners and dates for each action above.', owner: 'Regional manager', due: '7 days' });
  } else if (priority === 'P2') {
    actions.push({ title: 'Add to monthly performance review', detail: 'Track the flagged metrics monthly and escalate to P1 if any becomes severe.', owner: 'Area manager', due: 'Monthly' });
  } else if (actions.length === 0) {
    headline = 'No intervention needed — maintain standard monitoring.';
    actions.push({ title: 'Maintain standard monitoring', detail: 'Quarterly review cadence. Document practices worth sharing with weaker dealers in the region.', owner: 'Area manager', due: 'Quarterly' });
  } else {
    actions.push({ title: 'Monitor at quarterly review', detail: 'Minor drift only; confirm it reverses next quarter.', owner: 'Area manager', due: 'Quarterly' });
  }

  if (!headline) headline = actions[0].title + '.';
  // De-duplicate by title while keeping order
  const seen = new Set<string>();
  return { headline, actions: actions.filter((a) => (seen.has(a.title) ? false : (seen.add(a.title), true))) };
}

// ──────────────────────────────────── Pipeline ────────────────────────────────────

export function buildBenchmarks(dealers: Dealer[]): Benchmarks {
  const regionComplaints = {} as Record<Region, number>;
  const byRegion = new Map<string, { c: number; v: number }>();
  for (const d of dealers) {
    const e = byRegion.get(d.region) ?? { c: 0, v: 0 };
    e.c += d.customer_complaints;
    e.v += d.vehicles_sold;
    byRegion.set(d.region, e);
  }
  byRegion.forEach((e, r) => (regionComplaints[r] = r1((e.c / e.v) * 100)));
  const avg = (f: (d: Dealer) => number) => Math.round(dealers.reduce((s, d) => s + f(d), 0) / dealers.length);
  return { regionComplaints, networkService: avg((d) => d.service_performance), networkInventoryAge: avg((d) => d.inventory_age_days) };
}

export function scoreDealer(d: Dealer, b: Benchmarks): ScoredDealer {
  const m = derive(d);
  const components = scoreComponents(d, m);
  const health_score = Math.round(components.reduce((s, c) => s + c.normalized * c.weight, 0));
  const flags = computeFlags(d, m);
  const p = computePriority(health_score, flags, m.sales_growth_pct, m.capital_at_risk_cr);
  const prim = primaryRisk(flags, components);
  const why = whyFlagged(d, m, flags, b);
  const rec = recommend(d, m, flags, p.priority, p.severeCount);
  const active = RISK_KEYS.filter((k) => flags[k].severity !== 'none');
  const whyShort = active.length
    ? active
        .sort((a, b2) => (flags[b2].severity === 'severe' ? 1 : 0) - (flags[a].severity === 'severe' ? 1 : 0))
        .slice(0, 2)
        .map((k) => flags[k].reason)
        .join('; ')
    : flags.market_opportunity.severity !== 'none'
      ? flags.market_opportunity.reason
      : 'No thresholds breached';

  return {
    ...d,
    ...m,
    components,
    health_score,
    risk_level: riskLevelFor(health_score),
    flags,
    severe_count: p.severeCount,
    moderate_count: p.moderateCount,
    priority: p.priority,
    priority_reason: p.reason,
    attention_index: p.attention,
    primary_risk: prim,
    why_short: whyShort,
    why_flagged: why,
    interpretation: interpret(d, m, flags, p.severeCount, p.moderateCount),
    headline_action: rec.headline,
    actions: rec.actions,
  };
}

const PRI_ORDER: Record<Priority, number> = { P1: 0, P2: 1, P3: 2 };

export function byAttention(a: ScoredDealer, b: ScoredDealer) {
  return PRI_ORDER[a.priority] - PRI_ORDER[b.priority] || b.attention_index - a.attention_index;
}

export function scoreAll(dealers: Dealer[]): ScoredDealer[] {
  const b = buildBenchmarks(dealers);
  return dealers.map((d) => scoreDealer(d, b));
}

export { RISK_KEYS, PRI_ORDER };
