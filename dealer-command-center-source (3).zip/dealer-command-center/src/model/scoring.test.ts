import { describe, it, expect } from 'vitest';
import { DEALERS } from '../data/dealers';
import { scoreAll, byAttention, COMPONENTS, normalize, riskLevelFor } from './scoring';

const all = scoreAll(DEALERS);
const get = (id: string) => all.find((d) => d.dealer_id === id)!;

describe('dataset', () => {
  it('has 50 unique dealers covering all 14 archetypes', () => {
    expect(all).toHaveLength(50);
    expect(new Set(all.map((d) => d.dealer_id)).size).toBe(50);
    expect(new Set(DEALERS.map((d) => d.archetype)).size).toBeGreaterThanOrEqual(14);
  });
});

describe('metric formulas', () => {
  it('computes derived metrics from raw fields', () => {
    for (const d of all) {
      expect(d.sales_achievement_pct).toBeCloseTo((d.actual_sales / d.sales_target) * 100, 0);
      expect(d.sales_growth_pct).toBeCloseTo(((d.actual_sales - d.previous_year_sales) / d.previous_year_sales) * 100, 0);
      expect(d.complaints_per_100).toBeCloseTo((d.customer_complaints / d.vehicles_sold) * 100, 0);
    }
  });
  it('weights sum to 100', () => expect(COMPONENTS.reduce((s, c) => s + c.weight, 0)).toBe(100));
  it('normalises risk metrics inversely and clamps', () => {
    const inv = COMPONENTS.find((c) => c.key === 'inventory')!;
    expect(normalize(30, inv)).toBe(1);
    expect(normalize(90, inv)).toBe(0);
    expect(normalize(120, inv)).toBe(0);
    expect(normalize(60, inv)).toBeCloseTo(0.5);
  });
});

describe('health score and bands', () => {
  it('score equals the sum of weighted normalised components', () => {
    for (const d of all) {
      const sum = d.components.reduce((s, c) => s + c.normalized * c.weight, 0);
      expect(d.health_score).toBe(Math.round(sum));
      expect(d.health_score).toBeGreaterThanOrEqual(0);
      expect(d.health_score).toBeLessThanOrEqual(100);
      expect(d.risk_level).toBe(riskLevelFor(d.health_score));
    }
  });
  it('uses the agreed bands', () => {
    expect(riskLevelFor(75)).toBe('Healthy');
    expect(riskLevelFor(74)).toBe('Watch');
    expect(riskLevelFor(50)).toBe('Watch');
    expect(riskLevelFor(49)).toBe('Critical');
  });
});

describe('business story', () => {
  it('D003 sells more than D009 but is less healthy and higher priority', () => {
    const p = get('D003'), r = get('D009');
    expect(p.sales_achievement_pct).toBeGreaterThan(93);
    expect(r.sales_achievement_pct).toBeLessThan(84);
    expect(p.health_score).toBeLessThan(r.health_score);
    expect(p.priority).toBe('P1');
    expect(r.priority).toBe('P3');
  });
  it('D008 has strong sales, two severe risks, is P1 and in the top-5 queue', () => {
    const m = get('D008');
    expect(m.sales_achievement_pct).toBeGreaterThanOrEqual(90);
    expect(m.flags.inventory_risk.severity).toBe('severe');
    expect(m.flags.payment_risk.severity).toBe('severe');
    expect(m.priority).toBe('P1');
    expect([...all].sort(byAttention).slice(0, 5).map((d) => d.dealer_id)).toContain('D008');
  });
  it('a dealer can be Healthy overall yet carry a severe individual risk', () => {
    expect(all.some((d) => d.risk_level === 'Healthy' && d.severe_count > 0)).toBe(true);
  });
  it('every Critical dealer is P1; every P1 has a reason', () => {
    for (const d of all) {
      if (d.risk_level === 'Critical') expect(d.priority).toBe('P1');
      expect(d.priority_reason.length).toBeGreaterThan(5);
    }
  });
});

describe('recommendations follow the risks', () => {
  it('maps each risk to its action', () => {
    for (const d of all) {
      const titles = d.actions.map((a) => a.title).join('|');
      if (d.flags.inventory_risk.severity !== 'none') expect(titles).toMatch(/inventory allocation/);
      if (d.flags.payment_risk.severity !== 'none') expect(titles).toMatch(/payment review/);
      if (d.flags.customer_risk.severity !== 'none') expect(titles).toMatch(/Customer experience/);
      if (d.flags.service_risk.severity !== 'none') expect(titles).toMatch(/Service-center/);
      if (d.flags.sales_risk.severity !== 'none') expect(titles).toMatch(/sales funnel/);
      if (d.priority === 'P1') expect(titles).toMatch(/regional manager intervention/);
      expect(d.why_flagged.length).toBeGreaterThanOrEqual(2);
      expect(d.why_flagged.length).toBeLessThanOrEqual(5);
    }
  });
  it('uses the combined inventory + payment action for D008', () => {
    expect(get('D008').headline_action).toMatch(/inventory reduction and payment recovery/);
  });
});

describe('turnaround cases', () => {
  it('dealers with 3+ severe risks get a turnaround headline and owner', () => {
    for (const d of all.filter((x) => x.severe_count >= 3)) {
      expect(d.headline_action).toMatch(/turnaround plan/);
      expect(d.actions[0].title).toBe('Appoint a turnaround owner');
    }
  });
});
