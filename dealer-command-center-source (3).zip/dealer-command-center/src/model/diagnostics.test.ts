import { describe, it, expect } from 'vitest';
import { DEALERS } from '../data/dealers';
import { buildDiagnosticSample } from '../data/diagnosticSample';
import { analyzeTable, toCsv } from '../data/importDealers';
import { scoreAll } from './scoring';
import { buildDiagnostics, grade } from './diagnostics';

const core = buildDiagnostics(scoreAll(DEALERS));
const sampleDealers = buildDiagnosticSample();
const sample = buildDiagnostics(scoreAll(sampleDealers));
const tree = (dg: typeof core, id: string, key: string) => dg.byDealer.get(id)!.trees.find((t) => t.key === key)!;
const branch = (dg: typeof core, id: string, key: string, bid: string) => tree(dg, id, key).branches.find((b) => b.id === bid)!;
const allHyps = (dg: typeof core) => [...dg.byDealer.values()].flatMap((d) => d.trees.flatMap((t) => t.branches));

describe('language: hypotheses, never confirmed causes', () => {
  const HEDGE = /(possible|potential|pattern suggests|may |requires validation|suggest|appears|could|consistent with|investigate)/i;
  const CERTAIN = /(is causing|caused by|confirmed|definitely|proves|root cause is)/i;
  it('every supported hypothesis is hedged and nothing claims certainty', () => {
    for (const dg of [core, sample]) {
      for (const h of allHyps(dg)) {
        const text = [h.title, h.summary, h.action, ...h.evidence.map((e) => e.text), ...h.investigate].join(' ');
        expect(text).not.toMatch(CERTAIN);
        if (h.status === 'supported') expect(`${h.title} ${h.summary}`).toMatch(HEDGE);
      }
    }
  });
});

describe('no fabricated data', () => {
  it('core synthetic data has no optional fields and diagnostics say what is missing', () => {
    expect(core.available).toEqual([]);
    const ex = branch(core, 'D021', 'sales', 'sales-exec-or-comp');
    expect(ex.status).toBe('supported');
    expect(ex.confidence).toBe('Low');
    expect(ex.dataNeeded).toEqual(expect.arrayContaining(['Conversion rate', 'Competitor market share']));
    expect(branch(core, 'D015', 'complaints', 'cx-product').status).toBe('data_needed');
  });
  it('core-data evidence never quotes an optional field', () => {
    const OPTIONAL = /(damage|transport complaint|conversion|competitor share|competitor price|resolve|lead volume|product complaints)/i;
    for (const h of allHyps(core)) for (const e of h.evidence) if (!/not currently available/.test(e.text)) expect(e.text).not.toMatch(OPTIONAL);
    // …and the absence is stated explicitly instead
    expect(allHyps(core).some((h) => h.evidence.some((e) => /Competitor price, market-share and promotion data is not currently available/.test(e.text)))).toBe(true);
  });
  it('optional fields do not change health scores or priorities', () => {
    const a = scoreAll(DEALERS), b = scoreAll(sampleDealers);
    a.forEach((d, i) => { expect(b[i].health_score).toBe(d.health_score); expect(b[i].priority).toBe(d.priority); });
  });
  it('the sample passes import validation with optional columns preserved', () => {
    const r = analyzeTable(toCsv(sampleDealers).split('\n').map((l) => l.split(',')), 's.csv');
    expect(r.canImport).toBe(true);
    expect(r.optionalFound.filter((f) => f.group === 'diagnostic')).toHaveLength(14);
    expect(r.optionalFound.filter((f) => f.group === 'history')).toHaveLength(4);
    expect(r.dealers[0].product_category).toBeDefined();
  });
});

describe('diagnostic trees separate dealer, regional, product and network causes', () => {
  it('Central transport pattern: regional, high confidence, same products fine elsewhere', () => {
    const h = branch(sample, 'D014', 'complaints', 'cx-transport');
    expect(h.status).toBe('supported');
    expect(h.scope).toBe('Regional');
    expect(h.confidence).toBe('High');
    expect(h.evidence.map((e) => e.text).join(' ')).toMatch(/other regions/);
    expect(sample.patterns.some((p) => p.id === 'Central-damage')).toBe(true);
  });
  it('EV issue is product-specific across regions, not a dealer problem', () => {
    const h = branch(sample, 'D038', 'complaints', 'cx-product');
    expect(h.scope).toBe('Product-specific');
    expect(h.confidence).toBe('High');
    expect(sample.patterns.find((p) => p.id === 'product-EV')!.dealers.length).toBeGreaterThanOrEqual(5);
    expect(sample.byDealer.get('D038')!.wider).toBe(true);
  });
  it('D015: dealer customer service once other causes are ruled out', () => {
    const h = branch(sample, 'D015', 'complaints', 'cx-dealer');
    expect(h.confidence).toBe('High');
    expect(branch(sample, 'D015', 'complaints', 'cx-transport').status).toBe('not_supported');
    expect(branch(sample, 'D015', 'complaints', 'cx-storage').status).toBe('not_supported');
  });
  it('D021: high leads + low conversion -> sales execution gap, not "incompetent"', () => {
    const h = branch(sample, 'D021', 'sales', 'sales-exec');
    expect(h.status).toBe('supported');
    expect(h.title).toBe('Potential sales execution gap');
    expect(h.action).toMatch(/training before changing dealer allocation/);
  });
  it('D030: competitor gaining share -> competitive value gap', () => {
    expect(branch(sample, 'D030', 'sales', 'sales-comp').status).toBe('supported');
    expect(branch(sample, 'D021', 'sales', 'sales-comp').status).toBe('not_supported'); // own competitor data normal
  });
  it('D031: ageing stock but normal complaints -> storage not supported; strong sales -> over-allocation', () => {
    expect(branch(core, 'D031', 'inventory', 'inv-storage').status).toBe('not_supported');
    expect(branch(core, 'D031', 'inventory', 'inv-mix').status).toBe('supported');
  });
  it('same symptom, different action depending on cause', () => {
    const weak = branch(core, 'D017', 'inventory', 'inv-demand'); // weak sales
    const strong = branch(core, 'D008', 'inventory', 'inv-mix'); // strong sales
    expect(weak.status).toBe('supported');
    expect(strong.status).toBe('supported');
    expect(weak.action).not.toBe(strong.action);
  });
  it('payment: strong-sales dealer -> discipline; weak-sales stock-heavy dealer -> working capital', () => {
    expect(branch(core, 'D008', 'payment', 'pay-discipline').status).toBe('supported');
    expect(branch(core, 'D017', 'payment', 'pay-wc').status).toBe('supported');
  });
});

describe('confidence grading', () => {
  it('follows evidence amount, consistency and missing data', () => {
    expect(grade(3, true, 0).confidence).toBe('High');
    expect(grade(3, false, 0).confidence).toBe('Medium');
    expect(grade(4, false, 1).confidence).toBe('Medium'); // capped by missing data
    expect(grade(1, false, 0).confidence).toBe('Low');
    expect(grade(4, true, 0, 'Low').confidence).toBe('Low');
  });
});

describe('ranking: one primary hypothesis per dealer, the rest behind it', () => {
  it('every dealer with symptoms has a primary or is explicitly insufficient', () => {
    for (const dg of [core, sample]) for (const d of dg.byDealer.values()) {
      if (!d.trees.length) { expect(d.primary).toBeUndefined(); continue; }
      expect(Boolean(d.primary) !== d.insufficient).toBe(true);
      if (d.primary) {
        expect(d.primary.validate.length).toBeGreaterThan(20);
        for (const o of d.others) expect(o.rankScore!).toBeLessThanOrEqual(d.primary.rankScore!);
      }
    }
  });
  it('picks the regional transport cause for D014 and the product cause for D038 (sample)', () => {
    expect(sample.byDealer.get('D014')!.primary!.id).toBe('cx-transport');
    expect(sample.byDealer.get('D038')!.primary!.id).toBe('cx-product');
    expect(sample.byDealer.get('D021')!.primary!.id).toBe('sales-exec');
  });
  it('compares with similar market-potential dealers', () => {
    const ev = branch(core, 'D021', 'sales', 'sales-exec-or-comp').evidence.map((e) => e.text).join(' ');
    expect(ev).toMatch(/similar market potential/);
  });
});
