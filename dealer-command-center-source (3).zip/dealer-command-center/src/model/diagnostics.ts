import type { DiagnosticKey } from '../data/dealers';
import type { ScoredDealer } from './scoring';
import { THRESHOLDS } from './scoring';

// ═══════════════════════════════════════════════════════════════════════════════
// ROOT-CAUSE DIAGNOSTICS
//
// SYMPTOM → PATTERN → POSSIBLE CAUSE → EVIDENCE → INVESTIGATION → ACTION
//
// Every output is a HYPOTHESIS for management to validate, never a confirmed cause.
// The layer reads the scoring model's outputs; it never changes scores, flags or
// priorities. It only uses optional fields a dataset actually contains — when a field
// is missing it says which data would be needed instead of assuming a value.
// ═══════════════════════════════════════════════════════════════════════════════

export type Confidence = 'High' | 'Medium' | 'Low';
export type Scope = 'Dealer-specific' | 'Regional' | 'Product-specific' | 'Network-wide';
export type Status = 'supported' | 'not_supported' | 'data_needed';
export type SymptomKey = 'sales' | 'complaints' | 'inventory' | 'payment';

export interface Evidence {
  text: string;
  kind: 'supports' | 'against' | 'context';
}

export interface Hypothesis {
  id: string;
  title: string;
  status: Status;
  scope: Scope;
  confidence?: Confidence;
  confidenceReason?: string;
  summary: string; // hedged, one or two sentences
  evidence: Evidence[];
  investigate: string[];
  action: string;
  dataNeeded: string[];
  relatedDealers?: string[]; // other dealers sharing the pattern
  validate: string; // how management can confirm or rule this out
  symptom?: string; // which symptom tree it belongs to
  rankScore?: number;
}

/** Plain-English meaning of each confidence level, shown wherever confidence appears. */
export const CONF_MEANING: Record<Confidence, string> = {
  High: 'Multiple independent indicators support this hypothesis.',
  Medium: 'A meaningful pattern, but additional data is required to confirm it.',
  Low: 'An initial signal; supporting evidence is insufficient.',
};

const VALIDATE: Record<string, string> = {
  'sales-market': 'Compare this dealer with dealers of similar market potential and re-check how the territory estimate and target were built.',
  'sales-exec-or-comp': 'Collect three months of leads, conversion and lost-sale reasons, and benchmark competitor pricing, financing and promotions in the territory.',
  'sales-exec': 'Compare enquiry-to-booking conversion with regional peers and review a sample of lost leads and follow-up records.',
  'sales-comp': 'Compare on-road price, finance offers and promotions with the main competitors, and review lost-sale reasons.',
  'sales-supply': 'Compare allocation with the order bank and check waiting periods for the best-selling variants.',
  'sales-region': 'Check whether the decline also appears in regional registration data across brands, not just in this network.',
  'cx-storage': 'Compare complaint rates for units older vs newer than 60 days and inspect storage and handling conditions.',
  'cx-product': 'Trace affected units by batch, production date and supplier; check whether the same defects appear across dealers.',
  'cx-transport': 'Compare damage rates by transport provider and delivery route, and review transit damage records.',
  'cx-dealer': 'Review a sample of closed complaints for resolution time and handling, and run customer call-backs or a mystery shop.',
  'cx-network': 'Check for product, process or policy changes common to the whole network in the affected period.',
  'inv-demand': 'Compare monthly allocation with the retail run-rate over the last two quarters.',
  'inv-mix': 'Break ageing stock down by model, variant and colour and compare with what is actually selling.',
  'inv-storage': 'Inspect ageing units and their storage conditions; compare complaint rates by unit age.',
  'inv-region': 'Compare regional allocation and dispatch timing with regional retail demand.',
  'pay-wc': 'Review the dealer\u2019s cash flow and inventory funding; check whether delays track the stock build-up.',
  'pay-discipline': 'Review the collections process and payment history against sales receipts.',
  'pay-region': 'Check regional retail-finance approval rates and collection conditions with finance partners.',
  'pay-dealer': 'Run a credit review: balance sheet, funding lines and the overdue trend.',
};

export interface SymptomTree {
  key: SymptomKey;
  symptom: string; // e.g. "High customer complaints"
  observed: string; // the dealer's numbers
  branches: Hypothesis[];
}

export interface DealerDiagnostics {
  trees: SymptomTree[];
  scopeSummary: string;
  wider: boolean; // part of a regional / product / network pattern
  matchedActions: { title: string; action: string; confidence: Confidence }[];
  /** Ranked view: the single most likely explanation first, alternatives behind it. */
  primary?: Hypothesis;
  primaryReason: string;
  others: Hypothesis[];
  unavailable: { title: string; symptom: string; missing: string[] }[];
  ruledOut: { title: string; symptom: string; reason: string }[];
  insufficient: boolean; // symptoms exist but no hypothesis is supported
  missingData: string[];
}

export interface NetworkPattern {
  id: string;
  title: string;
  scope: Scope;
  confidence: Confidence;
  summary: string;
  evidence: string[];
  investigate: string;
  dealers: string[];
}

// Thresholds for the optional diagnostic fields (illustrative, like the scoring thresholds)
export const DIAG = {
  productComplaints: 1.8, // per 100 vehicles
  damage: 2.0, // % of deliveries
  transportComplaints: 1.2, // per 100 vehicles
  deliveryDelay: 5, // days
  lowConversion: 14, // %
  repWeak: 65, // index
  slowResolution: 6, // days
  competitorGain: 2, // pp share gain
  competitorCheaper: 95, // price index
  competitorPromo: 115, // promotion index
  lowCover: 0.8, // months of stock
  strongMarket: 70,
  weakMarket: 50,
  regionalMinDealers: 3,
  regionalMinShare: 0.4,
  regionalLift: 1.5,
  networkWideShare: 0.5,
};

export const FIELD_LABEL: Record<DiagnosticKey, string> = {
  product_category: 'Product category',
  product_complaint_rate: 'Product complaint rate',
  product_damage_rate: 'Product damage rate',
  transport_complaint_rate: 'Transport complaint rate',
  delivery_delay_days: 'Delivery delay',
  storage_age_days: 'Storage age',
  lead_volume: 'Lead volume',
  conversion_rate: 'Conversion rate',
  competitor_price_index: 'Competitor price index',
  competitor_market_share: 'Competitor market share',
  competitor_share_change: 'Competitor share change',
  competitor_promotion_index: 'Competitor promotion index',
  sales_rep_performance: 'Sales representative performance',
  service_resolution_days: 'Service resolution time',
};

const has = (v: unknown): v is number | string => v !== undefined && v !== null && v !== '';
const r1 = (n: number) => Math.round(n * 10) / 10;
const pct = (n: number) => `${Math.round(n * 100)}%`;
const avg = (xs: number[]) => (xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : NaN);
const times = (a: number, b: number) => (b > 0 ? `${r1(a / b)}×` : '');

/** Confidence comes only from the amount and consistency of evidence, and is capped when validating data is missing. */
export function grade(supports: number, crossDealer: boolean, missing: number, cap?: Confidence): { confidence: Confidence; reason: string } {
  let c: Confidence = (supports >= 3 && crossDealer) || supports >= 4 ? 'High' : supports >= 2 ? 'Medium' : 'Low';
  if (missing > 0 && c === 'High') c = 'Medium';
  if (cap === 'Low' || (cap === 'Medium' && c === 'High')) c = cap;
  const parts = [`${supports} supporting signal${supports === 1 ? '' : 's'}`];
  if (crossDealer) parts.push('consistent across several dealers');
  if (missing > 0) parts.push(`${missing} validating data field${missing === 1 ? '' : 's'} not available`);
  return { confidence: c, reason: parts.join('; ') };
}

// ───────────────────────────── Network context ─────────────────────────────

interface Ctx {
  all: ScoredDealer[];
  byRegion: Map<string, ScoredDealer[]>;
  avail: Set<DiagnosticKey>;
  leadIntensityMedian: number;
}

function buildCtx(all: ScoredDealer[]): Ctx {
  const byRegion = new Map<string, ScoredDealer[]>();
  for (const d of all) byRegion.set(d.region, [...(byRegion.get(d.region) ?? []), d]);
  const avail = new Set<DiagnosticKey>();
  for (const d of all) for (const k of Object.keys(FIELD_LABEL) as DiagnosticKey[]) if (has(d[k])) avail.add(k);
  const intensities = all.filter((d) => has(d.lead_volume)).map((d) => (d.lead_volume as number) / d.sales_target).sort((a, b) => a - b);
  return { all, byRegion, avail, leadIntensityMedian: intensities.length ? intensities[Math.floor(intensities.length / 2)] : NaN };
}

/** Is a symptom concentrated in one region (vs the rest of the network)? */
export function regionalPattern(ctx: Ctx, region: string, test: (d: ScoredDealer) => boolean) {
  const inRegion = ctx.byRegion.get(region) ?? [];
  const rest = ctx.all.filter((d) => d.region !== region);
  const hits = inRegion.filter(test);
  const share = inRegion.length ? hits.length / inRegion.length : 0;
  const restShare = rest.length ? rest.filter(test).length / rest.length : 0;
  const isPattern = hits.length >= DIAG.regionalMinDealers && share >= DIAG.regionalMinShare && share >= Math.max(restShare * DIAG.regionalLift, restShare + 0.15);
  return { hits, total: inRegion.length, share, restShare, isPattern };
}

const conversion = (d: ScoredDealer): number | undefined =>
  has(d.conversion_rate) ? (d.conversion_rate as number) : has(d.lead_volume) && (d.lead_volume as number) > 0 ? r1((d.vehicles_sold / (d.lead_volume as number)) * 100) : undefined;

function categoryStats(ctx: Ctx) {
  // Product complaint rate by category, and how many regions show it elevated
  const cats = new Map<string, ScoredDealer[]>();
  for (const d of ctx.all) if (has(d.product_category) && has(d.product_complaint_rate)) cats.set(String(d.product_category), [...(cats.get(String(d.product_category)) ?? []), d]);
  const out = new Map<string, { avg: number; othersAvg: number; elevated: ScoredDealer[]; regions: Set<string>; n: number; isPattern: boolean }>();
  for (const [cat, ds] of cats) {
    const others = ctx.all.filter((d) => has(d.product_category) && d.product_category !== cat && has(d.product_complaint_rate));
    const elevated = ds.filter((d) => (d.product_complaint_rate as number) >= DIAG.productComplaints);
    const regions = new Set(elevated.map((d) => d.region));
    const a = avg(ds.map((d) => d.product_complaint_rate as number));
    const o = avg(others.map((d) => d.product_complaint_rate as number));
    out.set(cat, { avg: a, othersAvg: o, elevated, regions, n: ds.length, isPattern: elevated.length >= 3 && regions.size >= 2 && a >= o * 1.8 });
  }
  return out;
}

/** Damage rate for the dealer's own product category in OTHER regions — "does the same product travel fine elsewhere?" */
function sameCategoryElsewhere(ctx: Ctx, d: ScoredDealer) {
  if (!has(d.product_category)) return undefined;
  const peers = ctx.all.filter((x) => x.region !== d.region && x.product_category === d.product_category && has(x.product_damage_rate));
  return peers.length ? avg(peers.map((x) => x.product_damage_rate as number)) : undefined;
}

/** Supporting signals minus contradicting ones — contradictions lower confidence. */
export const net = (ev: Evidence[]) => Math.max(0, ev.filter((e) => e.kind === 'supports').length - ev.filter((e) => e.kind === 'against').length);

const missing = (_ctx: Ctx, d: ScoredDealer, keys: DiagnosticKey[]) => keys.filter((k) => !has(d[k])).map((k) => FIELD_LABEL[k]);

const H = (h: Omit<Hypothesis, 'evidence' | 'investigate' | 'dataNeeded' | 'validate'> & Partial<Pick<Hypothesis, 'evidence' | 'investigate' | 'dataNeeded'>>): Hypothesis => ({
  evidence: [],
  investigate: [],
  dataNeeded: [],
  validate: VALIDATE[h.id] ?? '',
  ...h,
});

/** Dealers with similar market potential (±10 index points): "how well does this dealer use its opportunity?" */
function similarPotential(ctx: Ctx, d: ScoredDealer) {
  const peers = ctx.all.filter((x) => x.dealer_id !== d.dealer_id && Math.abs(x.market_potential - d.market_potential) <= 10);
  if (peers.length < 3) return undefined;
  return { n: peers.length, ach: Math.round(avg(peers.map((x) => x.sales_achievement_pct))), lo: d.market_potential - 10, hi: d.market_potential + 10 };
}

// ───────────────────────────── SALES tree ─────────────────────────────

function salesTree(ctx: Ctx, d: ScoredDealer): SymptomTree {
  const weak = `Sales at ${d.sales_achievement_pct}% of target, ${d.sales_growth_pct > 0 ? '+' : ''}${d.sales_growth_pct}% YoY`;
  const b: Hypothesis[] = [];
  const netPotential = Math.round(avg(ctx.all.map((x) => x.market_potential)));

  // 1. Low market potential → market opportunity
  if (d.market_potential < DIAG.weakMarket) {
    const ev: Evidence[] = [
      { kind: 'supports', text: weak },
      { kind: 'supports', text: `Market potential index ${d.market_potential} vs network average ${netPotential}` },
    ];
    if (d.market_growth < 5) ev.push({ kind: 'supports', text: `Local market growing only ${d.market_growth}%` });
    const sp = similarPotential(ctx, d);
    if (sp) ev.push(sp.ach < 85
      ? { kind: 'supports', text: `Dealers with similar market potential (${sp.n}, index ${sp.lo}–${sp.hi}) also average only ${sp.ach}% of target` }
      : { kind: 'against', text: `Dealers with similar market potential (${sp.n}, index ${sp.lo}–${sp.hi}) average ${sp.ach}% of target — the market alone may not explain the gap` });
    const g = grade(net(ev), false, 0);
    b.push(H({ id: 'sales-market', title: 'Limited market opportunity', status: 'supported', scope: 'Dealer-specific', ...g, confidenceReason: g.reason,
      summary: 'Pattern suggests the shortfall may be largely market-driven rather than a dealer execution problem. Requires validation of the territory potential estimate.',
      evidence: ev, investigate: ['How the market potential estimate and sales target were set', 'Whether the target assumes demand the territory does not have'],
      action: 'Validate the territory potential and re-base the target before escalating dealer performance.' }));
  } else {
    b.push(H({ id: 'sales-market', title: 'Limited market opportunity', status: 'not_supported', scope: 'Dealer-specific', summary: '',
      evidence: [{ kind: 'against', text: `Market potential index ${d.market_potential} is not low (network average ${netPotential}) — demand does not explain the gap` }], investigate: [], action: '' }));
  }

  // 2 & 3. Strong market + weak sales → execution and/or competition
  const strong = d.market_potential >= DIAG.strongMarket;
  const conv = conversion(d);
  const hasFunnel = conv !== undefined;
  const hasComp = has(d.competitor_share_change) || has(d.competitor_price_index) || has(d.competitor_promotion_index) || has(d.competitor_market_share);
  const adequateStock = d.stock_cover_months >= DIAG.lowCover;

  if (strong && !hasFunnel && !hasComp) {
    const ev: Evidence[] = [
      { kind: 'supports', text: weak },
      { kind: 'supports', text: `Strong local market: potential index ${d.market_potential}, growing ${d.market_growth}%` },
    ];
    if (adequateStock) ev.push({ kind: 'context', text: `${d.stock_cover_months} months of stock cover — availability does not appear to limit sales` });
    const sp = similarPotential(ctx, d);
    if (sp && d.sales_achievement_pct < sp.ach - 8) ev.push({ kind: 'supports', text: `Dealers with similar market potential (${sp.n}, index ${sp.lo}–${sp.hi}) average ${sp.ach}% of target vs ${d.sales_achievement_pct}% here` });
    ev.push({ kind: 'context', text: 'Competitor price, market-share and promotion data is not currently available, and neither is lead or conversion data' });
    const g = grade(2, false, 2, 'Low');
    b.push(H({ id: 'sales-exec-or-comp', title: 'Potential dealer execution gap or competitive pressure', status: 'supported', scope: 'Dealer-specific', ...g, confidenceReason: `${g.reason}; cannot validate — execution and competition cannot be separated without funnel and competitor data`,
      summary: 'Sales are below expected levels despite strong market potential. The pattern is consistent with either a dealer sales execution gap or competitors winning customers — the current data cannot distinguish the two.',
      evidence: ev,
      investigate: ['Enquiry-to-booking conversion and lead follow-up discipline', 'Competitor pricing, financing and promotions in this territory', 'Sales team capability and product knowledge'],
      action: 'Investigate competitive value propositions and dealer sales execution before reducing market investment.',
      dataNeeded: ['Lead volume', 'Conversion rate', 'Competitor market share', 'Competitor price index'] }));
  } else {
    // Execution branch
    if (hasFunnel && strong) {
      const ev: Evidence[] = [{ kind: 'supports', text: weak }, { kind: 'supports', text: `Strong local market: potential index ${d.market_potential}` }];
      const leadInt = has(d.lead_volume) ? (d.lead_volume as number) / d.sales_target : NaN;
      if (conv! < DIAG.lowConversion) ev.push({ kind: 'supports', text: `Conversion ${conv}% vs a ${DIAG.lowConversion}% watch line${has(d.conversion_rate) ? '' : ' (derived from leads and vehicles sold)'}` });
      else ev.push({ kind: 'against', text: `Conversion ${conv}% is not weak` });
      if (!Number.isNaN(leadInt) && leadInt >= ctx.leadIntensityMedian) ev.push({ kind: 'supports', text: `Lead volume (${d.lead_volume}) is at or above the network norm for a dealer this size — demand is reaching the showroom` });
      if (has(d.sales_rep_performance)) ev.push({ kind: (d.sales_rep_performance as number) < DIAG.repWeak ? 'supports' : 'against', text: `Sales team capability index ${d.sales_rep_performance}` });
      const sp = similarPotential(ctx, d);
      if (sp && d.sales_achievement_pct < sp.ach - 8) ev.push({ kind: 'supports', text: `Dealers with similar market potential (${sp.n}) average ${sp.ach}% of target vs ${d.sales_achievement_pct}% here` });
      ev.push({ kind: adequateStock ? 'supports' : 'against', text: `${d.stock_cover_months} months of stock cover — ${adequateStock ? 'availability is adequate' : 'availability may also limit sales'}` });
      const s = net(ev);
      const convWeak = conv! < DIAG.lowConversion;
      if (convWeak) {
        const g = grade(s, false, missing(ctx, d, ['sales_rep_performance']).length);
        b.push(H({ id: 'sales-exec', title: 'Potential sales execution gap', status: 'supported', scope: 'Dealer-specific', ...g, confidenceReason: g.reason,
          summary: 'Leads are arriving but too few convert, while stock is available and the market is strong. Pattern suggests a sales execution gap — this is a hypothesis about process, not a judgement on individuals.',
          evidence: ev, investigate: ['Lead handling and follow-up discipline', 'Sales consultant product knowledge and training', 'Test-drive and quotation-to-booking process', 'Customer experience in the showroom'],
          action: 'Review sales funnel conversion and conduct a sales-team capability assessment. Consider targeted sales training before changing dealer allocation.',
          dataNeeded: missing(ctx, d, ['sales_rep_performance']) }));
      } else {
        b.push(H({ id: 'sales-exec', title: 'Potential sales execution gap', status: 'not_supported', scope: 'Dealer-specific', summary: '', evidence: ev.filter((e) => e.kind === 'against'), investigate: [], action: '' }));
      }
    } else if (!hasFunnel) {
      b.push(H({ id: 'sales-exec', title: 'Potential sales execution gap', status: 'data_needed', scope: 'Dealer-specific', summary: 'Deeper diagnostic unavailable because lead volume and conversion rate were not provided.', evidence: [], investigate: [], action: '', dataNeeded: ['Lead volume', 'Conversion rate'] }));
    }

    // Competitive branch
    if (hasComp) {
      const ev: Evidence[] = [{ kind: 'supports', text: weak }];
      if (has(d.competitor_share_change)) ev.push({ kind: (d.competitor_share_change as number) >= DIAG.competitorGain ? 'supports' : 'against', text: `Competitor share ${(d.competitor_share_change as number) >= 0 ? '+' : ''}${d.competitor_share_change} pts YoY${has(d.competitor_market_share) ? ` (now ${d.competitor_market_share}%)` : ''}` });
      if (has(d.competitor_price_index)) ev.push({ kind: (d.competitor_price_index as number) <= DIAG.competitorCheaper ? 'supports' : 'against', text: `Competitor price index ${d.competitor_price_index} (100 = parity${(d.competitor_price_index as number) < 100 ? `; competitors about ${100 - (d.competitor_price_index as number)}% cheaper` : ''})` });
      if (has(d.competitor_promotion_index)) ev.push({ kind: (d.competitor_promotion_index as number) >= DIAG.competitorPromo ? 'supports' : 'against', text: `Competitor promotion intensity ${d.competitor_promotion_index} (100 = parity)` });
      const compSupports = ev.filter((e, i) => i > 0 && e.kind === 'supports').length; // the dealer's OWN competitor signals
      const peers = (ctx.byRegion.get(d.region) ?? []).filter((x) => x.dealer_id !== d.dealer_id && has(x.competitor_share_change) && (x.competitor_share_change as number) >= DIAG.competitorGain);
      if (peers.length && compSupports >= 1) ev.push({ kind: 'supports', text: `Competitors also gaining share at ${peers.length} other ${d.region} dealer${peers.length > 1 ? 's' : ''}` });
      if (compSupports >= 1) {
        const g = grade(net(ev), peers.length > 0, missing(ctx, d, ['competitor_share_change', 'competitor_price_index']).length);
        b.push(H({ id: 'sales-comp', title: 'Potential competitive value gap', status: 'supported', scope: peers.length ? 'Regional' : 'Dealer-specific', ...g, confidenceReason: g.reason,
          summary: 'Dealer sales are weakening while competitor indicators strengthen in the same market. Review the competitive offer before attributing the decline solely to dealer execution.',
          evidence: ev, relatedDealers: peers.map((p) => p.dealer_id),
          investigate: ['Competitor pricing and on-road price differences', 'Competitor financing and EMI offers', 'Competitor promotions, warranty and delivery times', 'Customer experience relative to competitors'],
          action: 'Run a competitive benchmarking review (price, financing, promotions, warranty) for this territory before changing targets or dealer allocation.',
          dataNeeded: missing(ctx, d, ['competitor_share_change', 'competitor_price_index', 'competitor_promotion_index']) }));
      } else {
        b.push(H({ id: 'sales-comp', title: 'Potential competitive value gap', status: 'not_supported', scope: 'Dealer-specific', summary: '', evidence: ev.filter((e) => e.kind === 'against'), investigate: [], action: '' }));
      }
    } else {
      b.push(H({ id: 'sales-comp', title: 'Potential competitive value gap', status: 'data_needed', scope: 'Dealer-specific', summary: 'Deeper diagnostic unavailable because competitor price, market-share and promotion data was not provided.', evidence: [], investigate: [], action: '', dataNeeded: ['Competitor market share', 'Competitor share change', 'Competitor price index', 'Competitor promotion index'] }));
    }
  }

  // 4. Low inventory availability → allocation / supply
  if (d.stock_cover_months < DIAG.lowCover) {
    const g = grade(2, false, 0);
    b.push(H({ id: 'sales-supply', title: 'Possible allocation / supply constraint', status: 'supported', scope: 'Dealer-specific', ...g, confidenceReason: g.reason,
      summary: 'Stock cover is thin, so lost sales may partly reflect product availability rather than demand or execution.',
      evidence: [{ kind: 'supports', text: weak }, { kind: 'supports', text: `Only ${d.stock_cover_months} months of stock cover (${d.inventory_units} units)` }],
      investigate: ['Allocation versus order bank', 'Model/variant availability and waiting periods'], action: 'Review allocation and supply against the order bank before treating this as a dealer performance issue.' }));
  } else {
    b.push(H({ id: 'sales-supply', title: 'Possible allocation / supply constraint', status: 'not_supported', scope: 'Dealer-specific', summary: '', evidence: [{ kind: 'against', text: `${d.stock_cover_months} months of stock cover — availability does not explain the gap` }], investigate: [], action: '' }));
  }

  // 5. Multiple dealers declining → regional market issue
  const rp = regionalPattern(ctx, d.region, (x) => x.sales_growth_pct < THRESHOLDS.sales.moderateGrowth);
  if (rp.isPattern) {
    const g = grade(3, true, 0);
    b.push(H({ id: 'sales-region', title: 'Possible regional market issue', status: 'supported', scope: 'Regional', ...g, confidenceReason: g.reason,
      summary: `Multiple dealers in ${d.region} show similar sales decline. This may indicate a regional market, competitive or supply issue rather than isolated dealer underperformance.`,
      evidence: [{ kind: 'supports', text: weak }, { kind: 'supports', text: `${rp.hits.length} of ${rp.total} ${d.region} dealers declining (${pct(rp.share)}) vs ${pct(rp.restShare)} elsewhere` }, { kind: 'supports', text: 'Similar deterioration across dealers points away from a single-dealer cause' }],
      relatedDealers: rp.hits.filter((x) => x.dealer_id !== d.dealer_id).map((x) => x.dealer_id),
      investigate: ['Regional demand trends and competitor launches', 'Regional pricing, schemes and supply'], action: 'Commission a regional market analysis before intervening dealer by dealer.' }));
  } else {
    b.push(H({ id: 'sales-region', title: 'Possible regional market issue', status: 'not_supported', scope: 'Regional', summary: '', evidence: [{ kind: 'against', text: `${rp.hits.length} of ${rp.total} ${d.region} dealers declining (${pct(rp.share)}) vs ${pct(rp.restShare)} elsewhere — no regional concentration` }], investigate: [], action: '' }));
  }

  return { key: 'sales', symptom: d.flags.sales_risk.severity !== 'none' ? 'Weak or declining sales' : 'Sales below available market demand', observed: `${weak}; market potential ${d.market_potential}`, branches: b };
}

// ───────────────────────────── COMPLAINTS tree ─────────────────────────────

function complaintsTree(ctx: Ctx, d: ScoredDealer): SymptomTree {
  const b: Hypothesis[] = [];
  const peers = ctx.byRegion.get(d.region) ?? [];
  const regAvg = r1((peers.reduce((s, x) => s + x.customer_complaints, 0) / peers.reduce((s, x) => s + x.vehicles_sold, 0)) * 100);
  const netAvg = r1((ctx.all.reduce((s, x) => s + x.customer_complaints, 0) / ctx.all.reduce((s, x) => s + x.vehicles_sold, 0)) * 100);
  const compl = `${d.complaints_per_100} complaints per 100 vehicles (region ${regAvg}, network ${netAvg})`;
  const agedStock = d.inventory_age_days >= THRESHOLDS.inventory.moderate;
  const pcr = d.product_complaint_rate;
  const complaintsHigh = d.flags.customer_risk.severity !== 'none';
  const notElevated = (id: string, title: string, scope: Scope) =>
    H({ id, title, status: 'not_supported', scope, summary: '', evidence: [{ kind: 'against', text: `Complaints are not elevated (${d.complaints_per_100} per 100) — the weakness is in service performance` }], investigate: [], action: '' });

  // 1. Storage / handling
  let storageSupported = false;
  if (!complaintsHigh) b.push(notElevated('cx-storage', 'Storage / inventory-ageing deterioration', 'Dealer-specific'));
  else if (agedStock) {
    const ev: Evidence[] = [{ kind: 'supports', text: compl }, { kind: 'supports', text: `Inventory age ${d.inventory_age_days} days (watch line ${THRESHOLDS.inventory.moderate})` }];
    if (has(d.storage_age_days)) ev.push({ kind: 'context', text: `Units spend ${d.storage_age_days} days in storage before delivery` });
    let contradicted = false;
    if (has(pcr)) {
      if ((pcr as number) >= DIAG.productComplaints) ev.push({ kind: 'supports', text: `Product-related complaints ${pcr} per 100 (watch line ${DIAG.productComplaints})` });
      else { ev.push({ kind: 'against', text: `Product-related complaints are normal at ${pcr} per 100 — complaints are not product-condition related` }); contradicted = true; }
    }
    if (!contradicted) {
      storageSupported = true;
      const s = net(ev);
      const miss = missing(ctx, d, ['product_complaint_rate', 'storage_age_days']);
      const g = grade(s, false, miss.length);
      b.push(H({ id: 'cx-storage', title: 'Storage / inventory-ageing deterioration', status: 'supported', scope: 'Dealer-specific', ...g, confidenceReason: g.reason,
        summary: 'Customer complaints are elevated while inventory ageing is also high. Prolonged storage or handling is a possible contributing factor to product-condition issues. Requires validation against complaint records by unit age.',
        evidence: ev,
        investigate: ['Storage and yard conditions (moisture, dust, temperature exposure)', 'How long complaint-affected units sat in stock', 'Handling and pre-delivery inspection practices', 'Whether older units have disproportionately more complaints'],
        action: 'Inspect storage and handling conditions and compare complaint rates for units older vs newer than 60 days.',
        dataNeeded: miss }));
    } else {
      b.push(H({ id: 'cx-storage', title: 'Storage / inventory-ageing deterioration', status: 'not_supported', scope: 'Dealer-specific', summary: '', evidence: ev.filter((e) => e.kind === 'against'), investigate: [], action: '' }));
    }
  } else {
    b.push(H({ id: 'cx-storage', title: 'Storage / inventory-ageing deterioration', status: 'not_supported', scope: 'Dealer-specific', summary: '', evidence: [{ kind: 'against', text: `Inventory age ${d.inventory_age_days} days is within the normal range` }], investigate: [], action: '' }));
  }

  // 2. Product-specific across regions
  let productSupported = false;
  if (!complaintsHigh) b.push(notElevated('cx-product', 'Product / quality issue', 'Product-specific'));
  else if (has(d.product_category) && has(pcr)) {
    const cs = categoryStats(ctx).get(String(d.product_category));
    if (cs?.isPattern && (pcr as number) >= DIAG.productComplaints) {
      productSupported = true;
      const g = grade(3, true, 0);
      b.push(H({ id: 'cx-product', title: `Product / quality issue — ${d.product_category}`, status: 'supported', scope: 'Product-specific', ...g, confidenceReason: g.reason,
        summary: `${d.product_category} shows elevated product complaints across multiple dealers and regions. Pattern suggests a product, batch or supplier issue rather than this dealer's performance.`,
        evidence: [
          { kind: 'supports', text: `This dealer: ${pcr} product complaints per 100 (${d.product_category})` },
          { kind: 'supports', text: `${d.product_category} average ${r1(cs.avg)} per 100 vs ${r1(cs.othersAvg)} for other categories (${times(cs.avg, cs.othersAvg)})` },
          { kind: 'supports', text: `Elevated at ${cs.elevated.length} dealers across ${cs.regions.size} regions: ${[...cs.regions].join(', ')}` },
        ],
        relatedDealers: cs.elevated.filter((x) => x.dealer_id !== d.dealer_id).map((x) => x.dealer_id),
        investigate: ['Batch / lot and production-date analysis of affected units', 'Supplier quality for the components involved', 'Packaging and design-related failure modes'],
        action: `Escalate to product quality for a ${d.product_category} batch-level review rather than treating this as a dealer performance issue.` }));
    } else {
      b.push(H({ id: 'cx-product', title: 'Product / quality issue', status: 'not_supported', scope: 'Product-specific', summary: '',
        evidence: [{ kind: 'against', text: cs ? `${d.product_category} complaints are not elevated across dealers and regions (${r1(cs.avg)} vs ${r1(cs.othersAvg)} for other categories)` : 'No category-level pattern' }], investigate: [], action: '' }));
    }
  } else {
    b.push(H({ id: 'cx-product', title: 'Product / quality issue', status: 'data_needed', scope: 'Product-specific', summary: 'Product-level complaint data is required to separate product issues from dealer issues.', evidence: [], investigate: [], action: '', dataNeeded: missing(ctx, d, ['product_category', 'product_complaint_rate']) }));
  }

  // 3. Region-specific → transport / logistics
  let transportSupported = false;
  const rpCx = regionalPattern(ctx, d.region, (x) => x.flags.customer_risk.severity !== 'none');
  if (!complaintsHigh) b.push(notElevated('cx-transport', 'Regional logistics / transport issue', 'Regional'));
  else if (has(d.product_damage_rate) || has(d.transport_complaint_rate) || has(d.delivery_delay_days)) {
    const ev: Evidence[] = [];
    const regDamage = regionalPattern(ctx, d.region, (x) => has(x.product_damage_rate) && (x.product_damage_rate as number) >= DIAG.damage);
    const otherRegDamage = avg(ctx.all.filter((x) => x.region !== d.region && has(x.product_damage_rate)).map((x) => x.product_damage_rate as number));
    if (has(d.product_damage_rate)) ev.push({ kind: (d.product_damage_rate as number) >= DIAG.damage ? 'supports' : 'against', text: `Product damage ${d.product_damage_rate}% of deliveries vs ${r1(otherRegDamage)}% in other regions${(d.product_damage_rate as number) >= DIAG.damage ? ` (${times(d.product_damage_rate as number, otherRegDamage)})` : ''}` });
    if (regDamage.isPattern) ev.push({ kind: 'supports', text: `${regDamage.hits.length} of ${regDamage.total} ${d.region} dealers show elevated damage` });
    if (has(d.transport_complaint_rate)) ev.push({ kind: (d.transport_complaint_rate as number) >= DIAG.transportComplaints ? 'supports' : 'against', text: `Transport-related complaints ${d.transport_complaint_rate} per 100` });
    if (has(d.delivery_delay_days)) ev.push({ kind: (d.delivery_delay_days as number) >= DIAG.deliveryDelay ? 'supports' : 'against', text: `Deliveries ${d.delivery_delay_days} days late on average` });
    const elsewhere = sameCategoryElsewhere(ctx, d);
    if (elsewhere !== undefined && has(d.product_damage_rate) && (d.product_damage_rate as number) >= DIAG.damage && elsewhere < DIAG.damage)
      ev.push({ kind: 'supports', text: `Same product line (${d.product_category}) has ${r1(elsewhere)}% damage in other regions — the product itself travels normally elsewhere` });
    if (!agedStock) ev.push({ kind: 'context', text: `Inventory age ${d.inventory_age_days} days is normal, so storage is a less likely explanation` });
    const s = ev.filter((e) => e.kind === 'supports').length;
    if (s >= 2) {
      transportSupported = true;
      const g = grade(net(ev), regDamage.isPattern, 0);
      b.push(H({ id: 'cx-transport', title: 'Regional logistics / transport issue', status: 'supported', scope: regDamage.isPattern ? 'Regional' : 'Dealer-specific', ...g, confidenceReason: g.reason,
        summary: `Product-damage and transport indicators are elevated${regDamage.isPattern ? ` across ${d.region}` : ''} while the same products perform better elsewhere. Pattern suggests a regional transport or handling issue — requires validation with transit records.`,
        evidence: ev, relatedDealers: regDamage.hits.filter((x) => x.dealer_id !== d.dealer_id).map((x) => x.dealer_id),
        investigate: ['Regional transport / logistics service provider', 'Handling during loading, transit and unloading', 'Delivery routes and transit times', 'Transit damage records and whether affected dealers share a carrier', 'Packaging adequacy for the route'],
        action: 'Review the regional transport provider, handling process and transit damage records before treating complaints as a dealer service issue.' }));
    } else {
      b.push(H({ id: 'cx-transport', title: 'Regional logistics / transport issue', status: 'not_supported', scope: 'Regional', summary: '', evidence: ev.filter((e) => e.kind === 'against'), investigate: [], action: '' }));
    }
  } else if (rpCx.isPattern) {
    const g = grade(2, true, 3, 'Low');
    transportSupported = true;
    b.push(H({ id: 'cx-transport', title: 'Possible regional logistics / supply-chain issue', status: 'supported', scope: 'Regional', ...g, confidenceReason: g.reason,
      summary: `Complaints are elevated at several ${d.region} dealers. This may indicate a regional logistics or supply-chain factor; transport data is required to test it.`,
      evidence: [{ kind: 'supports', text: compl }, { kind: 'supports', text: `${rpCx.hits.length} of ${rpCx.total} ${d.region} dealers have elevated complaints vs ${pct(rpCx.restShare)} elsewhere` }],
      relatedDealers: rpCx.hits.filter((x) => x.dealer_id !== d.dealer_id).map((x) => x.dealer_id),
      investigate: ['Transit damage records for the region', 'Regional logistics provider performance'], action: 'Collect transit damage and delivery-delay data for the region to test this hypothesis.',
      dataNeeded: ['Product damage rate', 'Transport complaint rate', 'Delivery delay'] }));
  } else {
    b.push(H({ id: 'cx-transport', title: 'Regional logistics / transport issue', status: 'data_needed', scope: 'Regional', summary: `Complaints are not concentrated in ${d.region} (${rpCx.hits.length} of ${rpCx.total} dealers). Transport data would confirm or rule this out.`, evidence: [], investigate: [], action: '', dataNeeded: ['Product damage rate', 'Transport complaint rate', 'Delivery delay'] }));
  }

  // 4. Dealer-specific customer experience
  {
    const ev: Evidence[] = [{ kind: complaintsHigh ? 'supports' : 'context', text: `${d.complaints_per_100} complaints per 100 vs ${d.region} average ${regAvg}` }];
    if (d.service_performance < THRESHOLDS.service.moderate) ev.push({ kind: 'supports', text: `Service performance index ${d.service_performance} (watch line ${THRESHOLDS.service.moderate})` });
    if (has(d.service_resolution_days)) ev.push({ kind: (d.service_resolution_days as number) >= DIAG.slowResolution ? 'supports' : 'against', text: `Complaints take ${d.service_resolution_days} days to resolve` });
    // Ruling out other explanations is weaker than direct evidence: together they count as one signal
    const elims: Evidence[] = [];
    if (!agedStock) elims.push({ kind: 'supports', text: `Ruled out: inventory age is normal (${d.inventory_age_days} days)` });
    if (has(d.product_damage_rate) && (d.product_damage_rate as number) < DIAG.damage) elims.push({ kind: 'supports', text: `Ruled out: transport damage is normal (${d.product_damage_rate}%)` });
    if (has(pcr) && (pcr as number) < DIAG.productComplaints) elims.push({ kind: 'supports', text: `Ruled out: product-related complaints are normal (${pcr} per 100)` });
    if (!rpCx.isPattern) elims.push({ kind: 'supports', text: `Ruled out: peers in ${d.region} do not share the problem (${rpCx.hits.length} of ${rpCx.total} elevated)` });
    const otherExplains = storageSupported || productSupported || transportSupported;
    const s = Math.max(0, net(ev) + (elims.length ? 1 : 0));
    ev.push(...elims);
    const miss = missing(ctx, d, ['service_resolution_days', 'product_complaint_rate', 'product_damage_rate']);
    if (!otherExplains || d.service_performance < THRESHOLDS.service.moderate) {
      const g = grade(s, false, miss.length, otherExplains ? 'Low' : undefined);
      b.push(H({ id: 'cx-dealer', title: 'Dealer customer-service / experience gap', status: 'supported', scope: 'Dealer-specific', ...g, confidenceReason: otherExplains ? `${g.reason}; other factors above may also explain the complaints` : g.reason,
        summary: otherExplains
          ? 'Weak service indicators suggest dealer customer-service execution may also contribute alongside the factors above.'
          : 'Complaints are elevated without a corresponding inventory, logistics or product pattern. Pattern suggests a dealer-level customer service or complaint-resolution gap.',
        evidence: ev,
        investigate: ['Sales and delivery experience', 'After-sales service quality and turnaround', 'Complaint resolution time and communication', 'Service staff capability'],
        action: 'Conduct a dealer customer-experience and complaint-resolution review, including a sample of closed complaints.', dataNeeded: miss }));
    } else {
      b.push(H({ id: 'cx-dealer', title: 'Dealer customer-service / experience gap', status: 'not_supported', scope: 'Dealer-specific', summary: '', evidence: [{ kind: 'against', text: 'Complaints are better explained by the storage, product or logistics pattern above, and service performance is not weak' }], investigate: [], action: '' }));
    }
  }

  // 5. Network-wide
  if (!complaintsHigh) return { key: 'complaints', symptom: 'Weak service performance', observed: `Service index ${d.service_performance}; ${compl}`, branches: b };
  const share = ctx.all.filter((x) => x.flags.customer_risk.severity !== 'none').length / ctx.all.length;
  if (share >= DIAG.networkWideShare) {
    const g = grade(2, true, 0);
    b.push(H({ id: 'cx-network', title: 'Network-wide product or process issue', status: 'supported', scope: 'Network-wide', ...g, confidenceReason: g.reason,
      summary: `Elevated complaints at ${pct(share)} of dealers suggest a company-level product or process issue.`, evidence: [{ kind: 'supports', text: `${pct(share)} of all dealers above the complaint watch line` }],
      investigate: ['Common product, process or policy changes across the network'], action: 'Escalate to a network-level quality review.' }));
  } else {
    b.push(H({ id: 'cx-network', title: 'Network-wide product or process issue', status: 'not_supported', scope: 'Network-wide', summary: '', evidence: [{ kind: 'against', text: `Only ${pct(share)} of dealers have elevated complaints — not network-wide` }], investigate: [], action: '' }));
  }

  return { key: 'complaints', symptom: d.flags.customer_risk.severity !== 'none' ? 'High customer complaints' : 'Weak service performance', observed: `${compl}; service index ${d.service_performance}`, branches: b };
}

// ───────────────────────────── INVENTORY tree ─────────────────────────────

function inventoryTree(ctx: Ctx, d: ScoredDealer): SymptomTree {
  const b: Hypothesis[] = [];
  const age = `Inventory age ${d.inventory_age_days} days, ${d.stock_cover_months} months of cover (₹${d.excess_stock_cr} Cr above normal)`;
  const weakSales = d.flags.sales_risk.severity !== 'none';
  const strongSales = d.sales_achievement_pct >= THRESHOLDS.strongSales;

  if (weakSales) {
    const g = grade(3, false, 0);
    b.push(H({ id: 'inv-demand', title: 'Allocation exceeding local demand', status: 'supported', scope: 'Dealer-specific', ...g, confidenceReason: g.reason,
      summary: 'Stock is building while sales weaken. Pattern suggests allocation has not adjusted to lower demand.',
      evidence: [{ kind: 'supports', text: age }, { kind: 'supports', text: `Sales at ${d.sales_achievement_pct}% of target, ${d.sales_growth_pct}% YoY` }, { kind: 'supports', text: `Retail run-rate ${Math.round(d.vehicles_sold / 12)} units/month vs ${d.inventory_units} units in stock` }],
      investigate: ['Allocation versus retail run-rate', 'Ageing units by model and variant'], action: 'Review inventory allocation and create a stock liquidation plan.' }));
  } else {
    b.push(H({ id: 'inv-demand', title: 'Allocation exceeding local demand', status: 'not_supported', scope: 'Dealer-specific', summary: '', evidence: [{ kind: 'against', text: `Sales are not weak (${d.sales_achievement_pct}% of target)` }], investigate: [], action: '' }));
  }
  if (strongSales) {
    const g = grade(2, false, 1);
    b.push(H({ id: 'inv-mix', title: 'Possible over-allocation or product-mix mismatch', status: 'supported', scope: 'Dealer-specific', ...g, confidenceReason: g.reason,
      summary: 'The dealer sells well yet stock is ageing. This may indicate stock pushed beyond the retail run-rate, or a mismatch between the models allocated and the models customers buy.',
      evidence: [{ kind: 'supports', text: age }, { kind: 'supports', text: `Strong sales: ${d.sales_achievement_pct}% of target` }],
      investigate: ['Whether allocation was pushed to meet wholesale targets', 'Ageing stock by model, variant and colour versus what is selling'],
      action: 'Investigate over-allocation and product mix; rebalance ageing variants through inter-dealer transfers.', dataNeeded: ['Stock by model / variant (not in current schema)'] }));
  } else {
    b.push(H({ id: 'inv-mix', title: 'Possible over-allocation or product-mix mismatch', status: 'not_supported', scope: 'Dealer-specific', summary: '', evidence: [{ kind: 'against', text: 'Sales are not strong enough to suggest over-allocation of a selling dealer' }], investigate: [], action: '' }));
  }
  if (d.flags.customer_risk.severity !== 'none') {
    const g = grade(2, false, missing(ctx, d, ['product_complaint_rate']).length);
    b.push(H({ id: 'inv-storage', title: 'Possible storage / handling deterioration', status: 'supported', scope: 'Dealer-specific', ...g, confidenceReason: g.reason,
      summary: 'Ageing stock coincides with elevated complaints. Storage conditions are a possible contributing factor — see the complaints investigation.',
      evidence: [{ kind: 'supports', text: age }, { kind: 'supports', text: `${d.complaints_per_100} complaints per 100 vehicles` }],
      investigate: ['Storage and yard conditions', 'Pre-delivery inspection of older units'], action: 'Inspect storage and handling conditions for ageing units.', dataNeeded: missing(ctx, d, ['product_complaint_rate']) }));
  } else {
    b.push(H({ id: 'inv-storage', title: 'Possible storage / handling deterioration', status: 'not_supported', scope: 'Dealer-specific', summary: '', evidence: [{ kind: 'against', text: `Complaints are not elevated (${d.complaints_per_100} per 100)` }], investigate: [], action: '' }));
  }
  const rp = regionalPattern(ctx, d.region, (x) => x.flags.inventory_risk.severity !== 'none');
  if (rp.isPattern) {
    const g = grade(3, true, 0);
    b.push(H({ id: 'inv-region', title: 'Possible regional demand or logistics issue', status: 'supported', scope: 'Regional', ...g, confidenceReason: g.reason,
      summary: `Ageing stock is concentrated in ${d.region}. This may reflect regional demand softness or a logistics/allocation issue rather than one dealer.`,
      evidence: [{ kind: 'supports', text: age }, { kind: 'supports', text: `${rp.hits.length} of ${rp.total} ${d.region} dealers carry ageing stock vs ${pct(rp.restShare)} elsewhere` }, { kind: 'supports', text: 'Similar build-up across dealers' }],
      relatedDealers: rp.hits.filter((x) => x.dealer_id !== d.dealer_id).map((x) => x.dealer_id),
      investigate: ['Regional demand trend', 'Regional allocation rules and dispatch timing'], action: 'Review regional allocation and demand before acting dealer by dealer.' }));
  } else {
    b.push(H({ id: 'inv-region', title: 'Possible regional demand or logistics issue', status: 'not_supported', scope: 'Regional', summary: '', evidence: [{ kind: 'against', text: `${rp.hits.length} of ${rp.total} ${d.region} dealers carry ageing stock — not concentrated in the region` }], investigate: [], action: '' }));
  }
  return { key: 'inventory', symptom: 'Ageing inventory', observed: age, branches: b };
}

// ───────────────────────────── PAYMENT tree ─────────────────────────────

function paymentTree(ctx: Ctx, d: ScoredDealer): SymptomTree {
  const b: Hypothesis[] = [];
  const peers = ctx.byRegion.get(d.region) ?? [];
  const regDelay = Math.round(avg(peers.filter((x) => x.dealer_id !== d.dealer_id).map((x) => x.payment_delay_days)));
  const pay = `Payments ${d.payment_delay_days} days beyond terms (₹${d.overdue_cr} Cr overdue); ${d.region} peers average ${regDelay} days`;
  const stockHeavy = d.flags.inventory_risk.severity !== 'none';
  const weakSales = d.flags.sales_risk.severity !== 'none';

  if (stockHeavy && (weakSales || d.sales_achievement_pct < 85)) {
    const g = grade(3, false, 0);
    b.push(H({ id: 'pay-wc', title: 'Working-capital pressure', status: 'supported', scope: 'Dealer-specific', ...g, confidenceReason: g.reason,
      summary: 'Cash appears tied up in slow-moving stock while sales are weak. Pattern suggests payment delays may be driven by working-capital pressure.',
      evidence: [{ kind: 'supports', text: pay }, { kind: 'supports', text: `₹${d.excess_stock_cr} Cr of stock above normal cover` }, { kind: 'supports', text: `Sales at ${d.sales_achievement_pct}% of target` }],
      investigate: ['Dealer cash-flow and inventory funding lines', 'Ageing stock that can be liquidated'], action: 'Pair a payment recovery plan with stock liquidation; release cash before enforcing stricter terms.' }));
  } else {
    b.push(H({ id: 'pay-wc', title: 'Working-capital pressure', status: 'not_supported', scope: 'Dealer-specific', summary: '', evidence: [{ kind: 'against', text: stockHeavy ? 'Sales are not weak enough to explain a cash squeeze' : 'Stock is not building up, so cash is not tied up in inventory' }], investigate: [], action: '' }));
  }
  if (d.sales_achievement_pct >= THRESHOLDS.strongSales) {
    const g = grade(2, false, 0);
    b.push(H({ id: 'pay-discipline', title: 'Credit / payment discipline', status: 'supported', scope: 'Dealer-specific', ...g, confidenceReason: g.reason,
      summary: 'Sales are strong yet payments run late. Pattern suggests a payment-discipline or credit-management issue rather than lack of demand.',
      evidence: [{ kind: 'supports', text: pay }, { kind: 'supports', text: `Strong sales: ${d.sales_achievement_pct}% of target` }],
      investigate: ['Collections process and use of manufacturer credit', 'Whether cash is diverted to other businesses or expansion'], action: 'Conduct a credit and payment-discipline review; tighten terms before increasing allocation.' }));
  } else {
    b.push(H({ id: 'pay-discipline', title: 'Credit / payment discipline', status: 'not_supported', scope: 'Dealer-specific', summary: '', evidence: [{ kind: 'against', text: `Sales are not strong (${d.sales_achievement_pct}% of target), so delays may reflect pressure rather than discipline` }], investigate: [], action: '' }));
  }
  const rp = regionalPattern(ctx, d.region, (x) => x.flags.payment_risk.severity !== 'none');
  if (rp.isPattern) {
    const g = grade(3, true, 0);
    b.push(H({ id: 'pay-region', title: 'Possible regional market / financing issue', status: 'supported', scope: 'Regional', ...g, confidenceReason: g.reason,
      summary: `Payment delays are widespread in ${d.region}. This may indicate a regional market or financing condition rather than one dealer's discipline.`,
      evidence: [{ kind: 'supports', text: pay }, { kind: 'supports', text: `${rp.hits.length} of ${rp.total} ${d.region} dealers delayed vs ${pct(rp.restShare)} elsewhere` }, { kind: 'supports', text: 'Similar deterioration across dealers' }],
      relatedDealers: rp.hits.filter((x) => x.dealer_id !== d.dealer_id).map((x) => x.dealer_id),
      investigate: ['Regional retail-finance availability', 'Regional demand and collections conditions'], action: 'Review regional financing conditions with finance partners before dealer-level enforcement.' }));
  } else {
    b.push(H({ id: 'pay-region', title: 'Possible regional market / financing issue', status: 'not_supported', scope: 'Regional', summary: '', evidence: [{ kind: 'against', text: `${rp.hits.length} of ${rp.total} ${d.region} dealers delayed — not a regional pattern` }], investigate: [], action: '' }));
  }
  if (!rp.isPattern && !b.some((h) => h.status === 'supported')) {
    const g = grade(2, false, 0);
    b.push(H({ id: 'pay-dealer', title: 'Possible dealer financial stress', status: 'supported', scope: 'Dealer-specific', ...g, confidenceReason: g.reason,
      summary: 'The delay is specific to this dealer — regional peers pay closer to terms. Pattern suggests possible dealer-level financial stress; requires validation through a credit review.',
      evidence: [{ kind: 'supports', text: pay }, { kind: 'supports', text: `Regional peers are not similarly delayed` }],
      investigate: ['Dealer balance sheet and funding lines', 'Overdue history and trend'], action: 'Run a dealer credit review and agree a dated recovery plan.' }));
  }
  return { key: 'payment', symptom: 'Payment delays', observed: pay, branches: b };
}

// ───────────────────────────── Assembly ─────────────────────────────

const ORDER: Record<Status, number> = { supported: 0, data_needed: 1, not_supported: 2 };
const CONF: Record<Confidence, number> = { High: 0, Medium: 1, Low: 2 };
const sortBranches = (bs: Hypothesis[]) => [...bs].sort((a, b) => ORDER[a.status] - ORDER[b.status] || CONF[a.confidence ?? 'Low'] - CONF[b.confidence ?? 'Low']);

export function diagnoseDealer(ctx: Ctx, d: ScoredDealer): DealerDiagnostics {
  const trees: SymptomTree[] = [];
  if (d.flags.sales_risk.severity !== 'none' || d.flags.market_opportunity.severity !== 'none') trees.push(salesTree(ctx, d));
  if (d.flags.customer_risk.severity !== 'none' || d.flags.service_risk.severity !== 'none') trees.push(complaintsTree(ctx, d));
  if (d.flags.inventory_risk.severity !== 'none') trees.push(inventoryTree(ctx, d));
  if (d.flags.payment_risk.severity !== 'none') trees.push(paymentTree(ctx, d));
  for (const t of trees) t.branches = sortBranches(t.branches);

  // ── Rank: confidence first, then the severity of the symptom it explains, then net evidence.
  //    Wider-scope causes get a small lift because they change who should act.
  const SEV = { severe: 2, moderate: 1, none: 0 } as const;
  const sev = (k: SymptomKey) =>
    k === 'sales' ? Math.max(SEV[d.flags.sales_risk.severity], SEV[d.flags.market_opportunity.severity])
    : k === 'complaints' ? Math.max(SEV[d.flags.customer_risk.severity], SEV[d.flags.service_risk.severity])
    : k === 'inventory' ? SEV[d.flags.inventory_risk.severity] : SEV[d.flags.payment_risk.severity];
  for (const t of trees)
    for (const b of t.branches) {
      b.symptom = t.symptom;
      if (b.status === 'supported')
        b.rankScore = (3 - CONF[b.confidence ?? 'Low']) * 10 + sev(t.key) * 4 + net(b.evidence) + (b.scope !== 'Dealer-specific' ? 2 : 0);
    }
  // The same cause can be reached from two symptoms (e.g. storage via ageing stock and via complaints): list it once
  const FAMILY: Record<string, string> = { 'cx-storage': 'storage', 'inv-storage': 'storage' };
  const seenFamily = new Set<string>();
  const supported = trees
    .flatMap((t) => t.branches.filter((b) => b.status === 'supported'))
    .sort((a, b) => (b.rankScore ?? 0) - (a.rankScore ?? 0))
    .filter((h) => {
      const f = FAMILY[h.id] ?? h.id + h.symptom;
      return seenFamily.has(f) ? false : (seenFamily.add(f), true);
    });
  const primary = supported[0];
  const symOf = (h: Hypothesis) => trees.find((t) => t.branches.includes(h))!;
  const primaryReason = primary
    ? `Ranked first: ${primary.confidence?.toLowerCase()} confidence, explaining ${symOf(primary).symptom.toLowerCase()} (${['', 'moderate', 'severe'][sev(symOf(primary).key)] || 'flagged'} risk)${supported.length > 1 ? `, ahead of ${supported.length - 1} other possible cause${supported.length > 2 ? 's' : ''}` : ''}.`
    : '';
  const unavailable = trees.flatMap((t) => t.branches.filter((b) => b.status === 'data_needed').map((b) => ({ title: b.title, symptom: t.symptom, missing: b.dataNeeded })));
  const ruledOut = trees.flatMap((t) => t.branches.filter((b) => b.status === 'not_supported').map((b) => ({ title: b.title, symptom: t.symptom, reason: b.evidence.map((e) => e.text).join('; ') || 'not indicated by the data' })));
  const missingData = [...new Set([...unavailable.flatMap((u) => u.missing), ...supported.flatMap((h) => h.dataNeeded)])];
  const widerHits = supported.filter((h) => h.scope !== 'Dealer-specific' && h.confidence !== 'Low');
  const scopeSummary = !trees.length
    ? 'No risk thresholds are breached, so there is nothing to investigate.'
    : widerHits.length
      ? `Part of a wider pattern: ${[...new Set(widerHits.map((h) => h.scope.toLowerCase()))].join(' and ')}. Avoid treating this solely as dealer underperformance.`
      : 'The evidence points mainly to dealer-specific factors; peers in the region do not share the same pattern.';
  const seen = new Set<string>();
  const matchedActions = supported
    .filter((h) => h.confidence !== 'Low')
    .sort((a, b) => CONF[a.confidence!] - CONF[b.confidence!])
    .filter((h) => (seen.has(h.action) ? false : (seen.add(h.action), true)))
    .slice(0, 3)
    .map((h) => ({ title: h.title, action: h.action, confidence: h.confidence! }));
  return {
    trees, scopeSummary, wider: widerHits.length > 0, matchedActions,
    primary, primaryReason, others: supported.slice(1), unavailable, ruledOut,
    insufficient: trees.length > 0 && !primary, missingData,
  };
}

/** Cross-dealer patterns for the Insights page. */
export function networkPatterns(ctx: Ctx): NetworkPattern[] {
  const out: NetworkPattern[] = [];
  const checks: { key: string; label: string; test: (x: ScoredDealer) => boolean; investigate: string; needs?: DiagnosticKey }[] = [
    { key: 'decline', label: 'sales decline', test: (x) => x.sales_growth_pct < THRESHOLDS.sales.moderateGrowth, investigate: 'Regional market analysis: demand, competitor activity and supply.' },
    { key: 'complaints', label: 'elevated complaints', test: (x) => x.flags.customer_risk.severity !== 'none', investigate: 'Regional logistics, product and service processes.' },
    { key: 'inventory', label: 'ageing stock', test: (x) => x.flags.inventory_risk.severity !== 'none', investigate: 'Regional demand and allocation rules.' },
    { key: 'payment', label: 'payment delays', test: (x) => x.flags.payment_risk.severity !== 'none', investigate: 'Regional financing and collections conditions.' },
    { key: 'damage', label: 'elevated product damage', test: (x) => has(x.product_damage_rate) && (x.product_damage_rate as number) >= DIAG.damage, investigate: 'Regional transport provider, handling and transit damage records.', needs: 'product_damage_rate' },
    { key: 'competitor', label: 'competitor share gains', test: (x) => has(x.competitor_share_change) && (x.competitor_share_change as number) >= DIAG.competitorGain, investigate: 'Competitive benchmarking across the region.', needs: 'competitor_share_change' },
  ];
  for (const region of ctx.byRegion.keys()) {
    for (const c of checks) {
      if (c.needs && !ctx.avail.has(c.needs)) continue;
      const rp = regionalPattern(ctx, region, c.test);
      if (!rp.isPattern) continue;
      const g = grade(rp.hits.length >= 5 ? 4 : 3, true, 0);
      out.push({
        id: `${region}-${c.key}`,
        title: `${region}: ${c.label} across ${rp.hits.length} dealers`,
        scope: 'Regional',
        confidence: g.confidence,
        summary: `Multiple dealers in ${region} show ${c.label}. This may indicate a regional issue rather than isolated dealer underperformance.`,
        evidence: [`${rp.hits.length} of ${rp.total} ${region} dealers (${pct(rp.share)}) vs ${pct(rp.restShare)} in other regions`],
        investigate: c.investigate,
        dealers: rp.hits.map((x) => x.dealer_id),
      });
    }
  }
  for (const [cat, cs] of categoryStats(ctx)) {
    if (!cs.isPattern) continue;
    out.push({
      id: `product-${cat}`,
      title: `${cat}: elevated product complaints across ${cs.regions.size} regions`,
      scope: 'Product-specific',
      confidence: 'High',
      summary: `${cat} complaints are elevated across dealers and regions. Investigate product, batch or supplier quality rather than individual dealer performance.`,
      evidence: [`${cat} average ${r1(cs.avg)} per 100 vs ${r1(cs.othersAvg)} for other categories (${times(cs.avg, cs.othersAvg)})`, `Elevated at ${cs.elevated.length} of ${cs.n} ${cat} dealers in ${[...cs.regions].join(', ')}`],
      investigate: 'Batch / lot, supplier and design review.',
      dealers: cs.elevated.map((x) => x.dealer_id),
    });
  }
  const cxShare = ctx.all.filter((x) => x.flags.customer_risk.severity !== 'none').length / ctx.all.length;
  if (cxShare >= DIAG.networkWideShare)
    out.push({ id: 'network-cx', title: 'Network-wide complaint increase', scope: 'Network-wide', confidence: 'Medium', summary: 'Complaints are elevated at most dealers, suggesting a company-level product or process issue.', evidence: [`${pct(cxShare)} of dealers above the complaint watch line`], investigate: 'Network-level quality review.', dealers: [] });
  const order: Record<Scope, number> = { 'Product-specific': 0, Regional: 1, 'Network-wide': 2, 'Dealer-specific': 3 };
  return out.sort((a, b) => order[a.scope] - order[b.scope] || CONF[a.confidence] - CONF[b.confidence] || b.dealers.length - a.dealers.length);
}

export function buildDiagnostics(scored: ScoredDealer[]) {
  const ctx = buildCtx(scored);
  const byDealer = new Map(scored.map((d) => [d.dealer_id, diagnoseDealer(ctx, d)]));
  return { byDealer, patterns: networkPatterns(ctx), available: [...ctx.avail] as DiagnosticKey[] };
}
