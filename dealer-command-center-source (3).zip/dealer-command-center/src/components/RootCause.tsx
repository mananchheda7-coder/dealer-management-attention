import type { Confidence, DealerDiagnostics, Hypothesis, Scope } from '../model/diagnostics';
import { CONF_MEANING } from '../model/diagnostics';

const CONF_STYLE: Record<Confidence, string> = {
  High: 'bg-cab text-white',
  Medium: 'border border-info/50 bg-info/10 text-info',
  Low: 'border border-steel-200 bg-steel-50 text-steel-500',
};

export function ConfidenceChip({ c }: { c: Confidence }) {
  return (
    <span title={CONF_MEANING[c]} className={`whitespace-nowrap rounded px-1.5 py-0.5 text-[11px] font-semibold ${CONF_STYLE[c]}`}>
      {c} confidence
    </span>
  );
}

export function ScopeChip({ s }: { s: Scope }) {
  return <span className="whitespace-nowrap rounded border border-steel-200 bg-white px-1.5 py-0.5 text-[11px] text-steel-700">{s}</span>;
}

const MARK = { supports: ['✓', 'text-ok'], against: ['✕', 'text-crit'], context: ['•', 'text-steel-400'] } as const;

interface LinkProps { nameOf: (id: string) => string; onOpen: (id: string) => void; onGoData: () => void }

/** Possible cause → Why we think this → Evidence → How to validate → Recommended action */
function ReasoningSteps({ h, nameOf, onOpen, onGoData, compact = false }: { h: Hypothesis; compact?: boolean } & LinkProps) {
  const label = 'pt-0.5 text-[11px] font-semibold tracking-wide text-steel-500';
  const Row = ({ title, children, id }: { title: string; children: React.ReactNode; id?: string }) => (
    <div className={`grid gap-1 border-l-2 border-steel-200 py-2 pl-4 sm:grid-cols-[9.5rem_1fr] sm:gap-4 ${compact ? '' : ''}`} data-step={id}>
      <div className={label}>{title}</div>
      <div className="text-[13px] leading-relaxed">{children}</div>
    </div>
  );
  return (
    <div>
      <Row title="WHY WE THINK THIS" id="why">
        <span className="text-ink">{h.summary}</span>
      </Row>
      <Row title="EVIDENCE" id="evidence">
        <ul className="space-y-0.5">
          {h.evidence.map((e, i) => (
            <li key={i} className="flex gap-2">
              <span className={`w-3 flex-none font-semibold ${MARK[e.kind][1]}`}>{MARK[e.kind][0]}</span>
              <span className="text-steel-700">{e.text}</span>
            </li>
          ))}
        </ul>
        {h.relatedDealers && h.relatedDealers.length > 0 && (
          <div className="mt-1.5 text-xs text-steel-500">
            Same pattern at:{' '}
            {h.relatedDealers.slice(0, 6).map((id, i) => (
              <span key={id}>{i > 0 && ', '}<button onClick={() => onOpen(id)} className="font-medium text-info hover:underline">{nameOf(id)}</button></span>
            ))}
            {h.relatedDealers.length > 6 && ` and ${h.relatedDealers.length - 6} more`}
          </div>
        )}
        <div className="mt-1.5 text-xs text-steel-500">
          <span className="font-semibold text-ink">{h.confidence} confidence</span> — {h.confidence && CONF_MEANING[h.confidence]} ({h.confidenceReason}.)
        </div>
      </Row>
      <Row title="HOW TO VALIDATE" id="validate">
        <p className="font-medium text-ink">{h.validate}</p>
        {!compact && h.investigate.length > 0 && <p className="mt-1 text-steel-700">Check: {h.investigate.join('; ')}.</p>}
        {h.dataNeeded.length > 0 && (
          <p className="mt-1 text-xs text-steel-500">
            Data that would strengthen or rule out this hypothesis: <span className="text-ink">{h.dataNeeded.join(', ')}</span>.{' '}
            {h.dataNeeded.some((x) => !x.includes('not in current schema')) && (
              <button onClick={onGoData} className="font-medium text-info hover:underline">Data page</button>
            )}
          </p>
        )}
      </Row>
      <Row title="RECOMMENDED ACTION" id="action">
        <p className="font-semibold text-ink">{h.action}</p>
        <p className="mt-0.5 text-xs text-steel-500">Act once the hypothesis is validated.</p>
      </Row>
    </div>
  );
}

export default function RootCause({ diag, ...links }: { diag: DealerDiagnostics } & LinkProps) {
  if (!diag.trees.length) return null;
  const p = diag.primary;
  const extraCount = diag.unavailable.length + diag.ruledOut.length;
  return (
    <section id="detail-rootcause" className="rounded-lg border border-steel-200 bg-white p-5">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="text-[15px] font-semibold text-ink">ROOT-CAUSE INVESTIGATION</h3>
        <span className="text-xs text-steel-500">Investigated: {diag.trees.map((t) => t.symptom.toLowerCase()).join(' · ')}</span>
      </div>
      <p className="mt-1 text-[13px] text-steel-500">What might be behind the flags. These are hypotheses that require validation — not confirmed causes.</p>
      <p className={`mt-3 rounded-md px-3 py-2 text-[13px] ${diag.wider ? 'border border-info/30 bg-info/10 text-ink' : 'bg-steel-50 text-steel-700'}`} data-testid="scope-summary">
        {diag.scopeSummary}
      </p>

      {diag.insufficient && (
        <div className="mt-4 rounded-md border border-dashed border-steel-200 p-4" data-testid="insufficient">
          <div className="font-semibold text-ink">Insufficient evidence — additional data required</div>
          <p className="mt-1 text-[13px] text-steel-700">
            None of the standard explanations is supported by the current data.
            {diag.missingData.length > 0 && <> Deeper diagnostic unavailable because {diag.missingData.join(', ')} {diag.missingData.length > 1 ? 'were' : 'was'} not provided.</>}
          </p>
          <button onClick={links.onGoData} className="mt-2 text-[13px] font-medium text-info hover:underline">See optional diagnostic columns on the Data page</button>
        </div>
      )}

      {p && (
        <div className="mt-4 rounded-lg border-2 border-cab" data-testid="primary-hypothesis">
          <div className="border-b border-steel-100 px-4 py-3">
            <div className="text-[11px] font-semibold tracking-wide text-info">MOST LIKELY — PRIMARY HYPOTHESIS</div>
            <div className="mt-1 text-[11px] font-semibold tracking-wide text-steel-500">POSSIBLE CAUSE</div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-lg font-semibold text-ink">{p.title}</span>
              <ScopeChip s={p.scope} />
              {p.confidence && <ConfidenceChip c={p.confidence} />}
            </div>
            <div className="mt-0.5 text-xs text-steel-500">{diag.primaryReason}</div>
          </div>
          <div className="px-4 py-2">
            <ReasoningSteps h={p} {...links} />
          </div>
        </div>
      )}

      {diag.others.length > 0 && (
        <details className="group mt-3 rounded-md border border-steel-200" data-testid="other-causes">
          <summary className="flex cursor-pointer list-none items-center gap-2 px-4 py-2.5 text-sm font-semibold text-ink [&::-webkit-details-marker]:hidden">
            <span className="text-steel-400 transition-transform group-open:rotate-90" aria-hidden>▸</span>
            OTHER POSSIBLE CAUSES ({diag.others.length})
            <span className="ml-auto flex flex-wrap justify-end gap-1">
              {diag.others.slice(0, 4).map((o) => o.confidence && <ConfidenceChip key={o.id + o.symptom} c={o.confidence} />)}
            </span>
          </summary>
          <div className="space-y-2 border-t border-steel-100 p-3">
            {diag.others.map((o) => (
              <details key={o.id + o.symptom} className="group/o rounded-md border border-steel-200 bg-white" data-testid="hypothesis">
                <summary className="flex cursor-pointer list-none flex-wrap items-center gap-2 px-3 py-2 [&::-webkit-details-marker]:hidden">
                  <span className="text-steel-400 transition-transform group-open/o:rotate-90" aria-hidden>▸</span>
                  <span className="text-[11px] text-steel-500">Possible cause</span>
                  <span className="flex-1 font-medium text-ink">{o.title}</span>
                  <span className="text-[11px] text-steel-500">{o.symptom?.toLowerCase()}</span>
                  <ScopeChip s={o.scope} />
                  {o.confidence && <ConfidenceChip c={o.confidence} />}
                </summary>
                <div className="border-t border-steel-100 px-3 py-1">
                  <ReasoningSteps h={o} compact {...links} />
                </div>
              </details>
            ))}
          </div>
        </details>
      )}

      {extraCount > 0 && (
        <details className="mt-3 text-[13px]" data-testid="not-assessed">
          <summary className="cursor-pointer text-steel-500 hover:text-ink">Not assessed or ruled out ({extraCount})</summary>
          <ul className="mt-2 space-y-1.5 pl-4">
            {diag.unavailable.map((u) => (
              <li key={'u' + u.title + u.symptom} className="text-steel-700">
                <span className="font-medium">Deeper diagnostic unavailable — {u.title}:</span>{' '}
                <span className="text-steel-500">{u.missing.join(', ')} {u.missing.length > 1 ? 'were' : 'was'} not provided.</span>
              </li>
            ))}
            {diag.ruledOut.map((r) => (
              <li key={'r' + r.title + r.symptom} className="text-steel-700">
                <span className="font-medium">Ruled out — {r.title}:</span> <span className="text-steel-500">{r.reason}</span>
              </li>
            ))}
          </ul>
        </details>
      )}
    </section>
  );
}
