import type { NetworkPattern } from '../model/diagnostics';
import { ConfidenceChip, ScopeChip } from './RootCause';
import { Panel } from './ui';

interface Props {
  patterns: NetworkPattern[];
  hasOptional: boolean;
  nameOf: (id: string) => string;
  onOpen: (id: string) => void;
  onGoData: () => void;
}

export default function Patterns({ patterns, hasOptional, nameOf, onOpen, onGoData }: Props) {
  return (
    <Panel
      id="patterns"
      title="Cross-dealer patterns"
      subtitle="Problems shared by several dealers point to a regional, product or network cause rather than individual dealer performance. Possible causes — require validation."
    >
      {patterns.length === 0 ? (
        <p className="text-sm text-steel-700">No regional, product or network-wide concentration detected. Issues in the current data appear dealer-specific.</p>
      ) : (
        <ul className="grid gap-3 lg:grid-cols-2">
          {patterns.map((p) => (
            <li key={p.id} className="rounded-md border border-steel-200 p-4" data-testid="pattern">
              <div className="flex flex-wrap items-center gap-2">
                <span className="flex-1 font-semibold text-ink">{p.title}</span>
                <ScopeChip s={p.scope} />
                <ConfidenceChip c={p.confidence} />
              </div>
              <p className="mt-1.5 text-[13px] text-steel-700">{p.summary}</p>
              <ul className="mt-1.5 space-y-0.5 text-[13px] text-steel-700">{p.evidence.map((e) => <li key={e}><span className="text-ok">✓</span> {e}</li>)}</ul>
              <p className="mt-1.5 text-[13px]"><span className="font-medium text-ink">Investigate:</span> <span className="text-steel-700">{p.investigate}</span></p>
              {p.dealers.length > 0 && (
                <p className="mt-1.5 text-xs text-steel-500">
                  Dealers:{' '}
                  {p.dealers.map((id, i) => (
                    <span key={id}>{i > 0 && ', '}<button onClick={() => onOpen(id)} className="text-info hover:underline">{nameOf(id)}</button></span>
                  ))}
                </p>
              )}
            </li>
          ))}
        </ul>
      )}
      {!hasOptional && (
        <p className="mt-4 rounded-md bg-steel-50 px-3 py-2 text-[13px] text-steel-700">
          The current data has core metrics only, so transport, product-quality, sales-funnel and competitor patterns cannot be tested. Import a file with optional diagnostic columns to unlock them.{' '}
          <button onClick={onGoData} className="font-medium text-info hover:underline">Go to Data</button>
        </p>
      )}
    </Panel>
  );
}
