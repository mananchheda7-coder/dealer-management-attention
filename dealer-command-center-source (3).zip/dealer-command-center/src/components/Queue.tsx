import { useState } from 'react';
import type { ScoredDealer } from '../model/scoring';
import { PriorityBadge, RISK_COLOR, RiskBadge, ScoreNumber } from './ui';

interface Props {
  queue: ScoredDealer[]; // already sorted by priority + attention index
  p1Count: number;
  onOpen: (id: string) => void;
}

export default function Queue({ queue, p1Count, onOpen }: Props) {
  const [expanded, setExpanded] = useState(false);
  // Expanding only makes sense when more than five dealers are P1 (otherwise all P1s are already in the top 5)
  const canExpand = p1Count > 5;
  const rows = expanded && canExpand ? queue.filter((d) => d.priority === 'P1') : queue.slice(0, 5);

  return (
    <section id="queue" className="overflow-hidden rounded-lg border-2 border-cab bg-white">
      <header className="flex flex-wrap items-end justify-between gap-3 bg-cab px-5 py-3 text-white">
        <div>
          <h2 className="font-cond text-xl font-semibold tracking-wide">MANAGEMENT ATTENTION QUEUE</h2>
          <p className="mt-0.5 text-sm text-steel-200">Dealers requiring the most immediate management focus</p>
        </div>
        <p className="max-w-md text-right text-xs leading-relaxed text-steel-200">
          Ranked by priority, then by risk depth and capital at risk. Sales volume is not used for ranking.
        </p>
      </header>

      <div className="hidden grid-cols-[2.25rem_minmax(0,1.5fr)_5rem_4.5rem_minmax(0,1fr)_minmax(0,1.6fr)_minmax(0,1.9fr)] gap-4 border-b border-steel-100 bg-steel-50 px-5 py-2 text-xs font-medium text-steel-500 lg:grid">
        <span>#</span>
        <span>Dealer</span>
        <span>Health</span>
        <span>Priority</span>
        <span>Primary risk</span>
        <span>Why flagged</span>
        <span>Recommended action</span>
      </div>

      <ol>
        {rows.map((d, i) => {
          const hidden = d.sales_achievement_pct >= 90 && d.priority === 'P1';
          return (
            <li key={d.dealer_id} id={`queue-row-${d.dealer_id}`}>
              <button
                onClick={() => onOpen(d.dealer_id)}
                className="group grid w-full grid-cols-[2.25rem_minmax(0,1fr)] gap-x-4 gap-y-2 border-b border-steel-100 px-5 py-3 text-left transition-colors hover:bg-steel-50 lg:grid-cols-[2.25rem_minmax(0,1.5fr)_5rem_4.5rem_minmax(0,1fr)_minmax(0,1.6fr)_minmax(0,1.9fr)] lg:items-center"
                style={{ boxShadow: `inset 4px 0 0 ${RISK_COLOR[d.risk_level]}` }}
              >
                <span className="font-cond text-xl font-semibold text-steel-400 tnum lg:row-auto">{i + 1}</span>
                <span className="min-w-0">
                  <span className="block truncate font-semibold text-ink group-hover:text-info">{d.dealer_name}</span>
                  <span className="text-xs text-steel-500">
                    {d.city}, {d.region} · {d.dealer_id} · {d.sales_achievement_pct}% of target
                  </span>
                  {hidden && (
                    <span className="mt-1 block w-fit rounded bg-info/10 px-1.5 py-0.5 text-[11px] font-medium text-info">
                      Strong sales, hidden risk
                    </span>
                  )}
                </span>
                <span className="col-start-2 flex items-center gap-3 lg:col-start-auto lg:block">
                  <span className="text-xl leading-none">
                    <ScoreNumber score={d.health_score} level={d.risk_level} />
                    <span className="text-xs text-steel-400">/100</span>
                  </span>
                  <span className="lg:mt-1 lg:block">
                    <RiskBadge level={d.risk_level} />
                  </span>
                </span>
                <span className="col-start-2 lg:col-start-auto">
                  <PriorityBadge p={d.priority} />
                </span>
                <span className="col-start-2 text-sm font-medium text-ink lg:col-start-auto">
                  {d.primary_risk}
                  <span className="block text-xs font-normal text-steel-500">₹{d.capital_at_risk_cr} Cr capital at risk</span>
                </span>
                <span className="col-start-2 text-[13px] leading-snug text-steel-700 lg:col-start-auto">{d.why_short}</span>
                <span className="col-start-2 text-[13px] font-medium leading-snug text-ink lg:col-start-auto">{d.headline_action}</span>
              </button>
            </li>
          );
        })}
      </ol>

      <footer className="flex items-center justify-between bg-steel-50 px-5 py-2.5 text-sm">
        <span className="text-steel-500">
          {p1Count === 1 ? '1 dealer is' : `${p1Count} dealers are`} P1 in total. Select a dealer to see the score breakdown and action plan.
        </span>
        {canExpand && (
          <button onClick={() => setExpanded((e) => !e)} className="font-medium text-info hover:underline">
            {expanded ? 'Show top 5 only' : `Show all ${p1Count} P1 dealers`}
          </button>
        )}
      </footer>
    </section>
  );
}
