import type { ScoredDealer } from '../model/scoring';
import { COMPONENTS, THRESHOLDS } from '../model/scoring';
import { PriorityBadge, RiskBadge } from './ui';

const FLOW = [
  ['Data', 'Dealer metrics, synthetic or imported'],
  ['Health', 'Weighted 0–100 score'],
  ['Risk', 'Six separate risk flags'],
  ['Priority', 'P1 / P2 / P3 urgency'],
  ['Why', 'Reasons in the dealer\u2019s numbers'],
  ['Action', 'Matched to the risk'],
];

const TREES: [string, [string, string][]][] = [
  ['Sales problem', [
    ['Low market potential', 'Market opportunity issue'],
    ['Strong market + low conversion', 'Dealer sales execution'],
    ['Competitor gaining share', 'Competitive value proposition'],
    ['Low stock availability', 'Allocation / supply issue'],
    ['Multiple dealers declining', 'Regional / market issue'],
  ]],
  ['Customer complaints', [
    ['High inventory ageing', 'Storage / handling'],
    ['Product-specific across regions', 'Product / quality / batch'],
    ['Region-specific damage', 'Transport / logistics'],
    ['Dealer-specific', 'Dealer customer service'],
    ['Network-wide', 'Company-level product / process'],
  ]],
  ['Ageing inventory', [
    ['Weak sales', 'Allocation exceeds demand'],
    ['Strong sales', 'Over-allocation / product mix'],
    ['Complaints also high', 'Storage / handling'],
    ['Concentrated in a region', 'Regional demand / logistics'],
  ]],
  ['Payment delays', [
    ['High stock + weak sales', 'Working-capital pressure'],
    ['Strong sales', 'Credit / payment discipline'],
    ['Region-wide', 'Regional market / financing'],
    ['Dealer-specific', 'Dealer financial stress'],
  ]],
];

const RULES = [
  ['Inventory risk', 'Review inventory allocation; create a stock liquidation plan'],
  ['Payment risk', 'Credit and payment review with a dated recovery plan; pay-before-dispatch if severe'],
  ['Strong sales + inventory + payment risk', 'Prioritise inventory reduction and payment recovery before increasing stock allocation'],
  ['Sales risk', 'Review the sales funnel, local competition and sales productivity'],
  ['Sales risk + untapped market', 'Investigate dealer execution — demand appears available'],
  ['Sales risk + small market', 'Right-size target and allocation'],
  ['Customer risk', 'Customer experience and service quality review'],
  ['Service risk', 'Service-center performance review; identify recurring complaint categories'],
  ['3+ severe risks', 'Structured turnaround plan with one accountable owner'],
  ['P1 / P2 / P3', 'Regional manager visit in 7 days / monthly review / quarterly monitoring'],
];

export default function Method({ example }: { example: ScoredDealer | null }) {
  const T = THRESHOLDS;
  const flags = [
    ['Sales risk', `Achievement below ${T.sales.moderateAch}% or growth below ${T.sales.moderateGrowth}%`, `Below ${T.sales.severeAch}% or growth ${T.sales.severeGrowth}% or worse`],
    ['Inventory risk', `Stock age ${T.inventory.moderate}+ days`, `${T.inventory.severe}+ days`],
    ['Payment risk', `${T.payment.moderate}+ days beyond terms`, `${T.payment.severe}+ days`],
    ['Service risk', `Service index below ${T.service.moderate}`, `Below ${T.service.severe}`],
    ['Customer risk', `${T.customer.moderate}+ complaints per 100 vehicles`, `${T.customer.severe}+`],
    ['Untapped market', `Market potential ${T.market.potential}+ while sales below ${T.market.achBelow}% or shrinking`, 'Same, with achievement below 75% or sharp decline'],
  ];

  return (
    <div className="space-y-6">
    <section aria-label="Decision flow" className="rounded-lg border border-steel-200 bg-white p-5">
      <h2 className="text-[15px] font-semibold text-ink">From data to action</h2>
      <ol className="mt-3 grid grid-cols-2 gap-px overflow-hidden rounded-md border border-steel-200 bg-steel-200 sm:grid-cols-3 lg:grid-cols-6">
        {FLOW.map(([step, desc], i) => (
          <li key={step} className="bg-white px-4 py-3">
            <span className="font-cond text-xs font-semibold text-steel-400">{i + 1}</span>
            <span className="ml-2 font-semibold text-ink">{step}</span>
            <span className="block text-xs text-steel-500">{desc}</span>
          </li>
        ))}
      </ol>
    </section>

    <section id="health-vs-priority" className="grid gap-px overflow-hidden rounded-lg border-2 border-cab bg-steel-200 md:grid-cols-[1fr_1fr_1.2fr]">
      <div className="bg-white p-5">
        <div className="font-cond text-2xl font-semibold tracking-wide text-ink">HEALTH</div>
        <p className="mt-1 text-sm font-medium text-ink">= overall dealer condition</p>
        <p className="mt-2 text-[13px] leading-relaxed text-steel-700">A weighted 0–100 score across sales, growth, stock, payments, service, complaints and market. Healthy, Watch or Critical.</p>
      </div>
      <div className="bg-white p-5">
        <div className="font-cond text-2xl font-semibold tracking-wide text-ink">PRIORITY</div>
        <p className="mt-1 text-sm font-medium text-ink">= urgency of management intervention</p>
        <p className="mt-2 text-[13px] leading-relaxed text-steel-700">Driven by the severity and number of individual risks. One weak area can be urgent even when the average looks acceptable.</p>
      </div>
      <div className="bg-cab p-5 text-white">
        <div className="text-sm font-semibold">So a dealer can be Watch and P1 — by design.</div>
        {example ? (
          <div className="mt-3 rounded-md bg-white p-3 text-ink">
            <div className="font-semibold">{example.dealer_name} <span className="text-xs font-normal text-steel-500">{example.dealer_id}</span></div>
            <div className="mt-1.5 flex flex-wrap items-center gap-2"><RiskBadge level={example.risk_level} /><span className="text-sm">score {example.health_score}</span><PriorityBadge p={example.priority} withLabel /></div>
            <div className="mt-1.5 text-xs text-steel-700">{example.priority_reason}.</div>
          </div>
        ) : (
          <p className="mt-2 text-[13px] text-steel-200">No dealer in the current dataset combines a non-critical score with P1.</p>
        )}
        <p className="mt-3 text-[13px] leading-relaxed text-steel-200">An average hides a severe problem; priority surfaces it.</p>
      </div>
    </section>

    <section id="method" className="grid gap-5 lg:grid-cols-12">
      <div className="rounded-lg border border-steel-200 bg-white p-5 lg:col-span-7">
        <h2 className="text-[15px] font-semibold text-ink">How the model works</h2>
        <p className="mt-1 text-[13px] text-steel-500">Every number on this page is calculated from the dealer data with the rules below. Nothing is hand-scored.</p>

        <h3 className="mt-5 text-sm font-semibold text-ink">1. Health score (0–100)</h3>
        <table className="mt-2 w-full text-[13px]">
          <thead><tr className="border-b border-steel-200 text-left text-xs text-steel-500"><th className="py-1.5 font-medium">Component</th><th className="font-medium">Weight</th><th className="font-medium">Full points</th><th className="font-medium">Zero points</th></tr></thead>
          <tbody>
            {COMPONENTS.map((c) => (
              <tr key={c.key} className="border-b border-steel-100">
                <td className="py-1.5 text-ink">{c.label}</td>
                <td className="font-semibold tnum">{c.weight}%</td>
                <td className="tnum text-steel-700">{c.key === 'growth' && c.best > 0 ? '+' : ''}{c.best}{c.unit}</td>
                <td className="tnum text-steel-700">{c.worst}{c.unit}</td>
              </tr>
            ))}
          </tbody>
        </table>
        <p className="mt-2 text-[13px] text-steel-700">Points scale linearly between the anchors. Healthy is 75–100, Watch 50–74, Critical 0–49.</p>
        <p className="mt-2 rounded bg-steel-50 px-3 py-2 text-[13px] text-steel-700" data-testid="market-potential-note">
          <span className="font-semibold text-ink">Market potential (10%) is contextual, not a dealer-performance metric.</span> It is included as a
          sustainability factor: a territory with more available demand gives a dealer more headroom to recover and grow. It helps answer how well a
          dealer is performing relative to the opportunity available. With a 10% weight it cannot make a dealer unhealthy on its own, and a
          dealer in a smaller market can still score Healthy — sales are judged against target, which should already reflect the territory. The
          diagnostics also compare each dealer with dealers of similar market potential.
        </p>

        <h3 className="mt-5 text-sm font-semibold text-ink">2. Individual risk flags</h3>
        <table className="mt-2 w-full text-[13px]">
          <thead><tr className="border-b border-steel-200 text-left text-xs text-steel-500"><th className="py-1.5 font-medium">Flag</th><th className="font-medium text-warn">Moderate</th><th className="font-medium text-crit">Severe</th></tr></thead>
          <tbody>{flags.map(([a, b, c]) => <tr key={a} className="border-b border-steel-100"><td className="py-1.5 text-ink">{a}</td><td className="text-steel-700">{b}</td><td className="text-steel-700">{c}</td></tr>)}</tbody>
        </table>
        <p className="mt-2 text-[13px] text-steel-700">Flags are evaluated separately from the score, so a dealer with a reasonable overall score can still carry a severe risk.</p>

        <h3 className="mt-5 text-sm font-semibold text-ink">3. Management priority</h3>
        <ul className="mt-2 space-y-1 text-[13px] text-steel-700">
          <li><span className="font-semibold text-crit">P1</span> — score below 50, or two or more severe risks, or sharply falling sales in a market where demand is available.</li>
          <li><span className="font-semibold text-warn">P2</span> — one severe risk, two or more moderate risks, a score below 65, or untapped market demand.</li>
          <li><span className="font-semibold text-steel-700">P3</span> — everything else.</li>
        </ul>
        <p className="mt-2 text-[13px] text-steel-700">
          Within a priority band, dealers are ordered by an attention index: risk depth (score gap, severe and moderate risks, sales decline)
          plus capital at risk — the value of stock above a normal 1.25-month cover plus overdue payments. Sales volume is never used for ranking.
        </p>

        <h3 className="mt-5 text-sm font-semibold text-ink">4. Recommendations</h3>
        <p className="mt-1 text-[13px] text-steel-700">Rule-based: each action is triggered by a specific risk, and its wording uses the dealer's own figures.</p>
        <table className="mt-2 w-full text-[13px]">
          <thead><tr className="border-b border-steel-200 text-left text-xs text-steel-500"><th className="py-1.5 font-medium">When the dealer has</th><th className="font-medium">Recommended action</th></tr></thead>
          <tbody>{RULES.map(([a, b]) => <tr key={a} className="border-b border-steel-100"><td className="py-1.5 pr-3 text-ink">{a}</td><td className="text-steel-700">{b}</td></tr>)}</tbody>
        </table>
      </div>

      <div className="flex flex-col gap-5 lg:col-span-5">
        <div id="business-value" className="rounded-lg border border-steel-200 bg-white p-5">
          <h2 className="font-cond text-lg font-semibold tracking-wide text-ink">BUSINESS VALUE</h2>
          <p className="mt-1 text-[13px] text-steel-500">The system helps regional managers:</p>
          <ul className="mt-3 space-y-2 text-sm text-ink">
            {[
              'Focus limited management time on high-risk dealers',
              'Detect emerging problems earlier',
              'Understand why a dealer is flagged',
              'Prioritize interventions',
              'Match actions to the underlying problem',
              'Avoid relying only on sales performance',
            ].map((t) => (
              <li key={t} className="flex gap-2.5"><span className="mt-[7px] h-1.5 w-1.5 flex-none rounded-full bg-ok" />{t}</li>
            ))}
          </ul>
        </div>
        <div id="limitation" className="rounded-lg border border-warn/40 bg-warn-soft p-5">
          <h2 className="font-cond text-lg font-semibold tracking-wide text-warn">KEY LIMITATION</h2>
          <p className="mt-2 text-sm leading-relaxed text-ink">
            The scoring weights and thresholds are illustrative and have not been statistically validated against historical dealer outcomes.
            Production deployment would require calibration using actual dealer performance and recovery/failure outcomes.
          </p>
          <p className="mt-3 text-[13px] leading-relaxed text-steel-700">
            Other gaps a production version would close: point-in-time data rather than monthly trends, no seasonality adjustment, and no
            link to the dealer's own action history.
          </p>
        </div>
      </div>
    </section>

    <section id="diagnostics-method" className="rounded-lg border border-steel-200 bg-white p-5">
      <h2 className="text-[15px] font-semibold text-ink">5. Root-cause diagnostics</h2>
      <p className="mt-1 max-w-4xl text-[13px] leading-relaxed text-steel-700">
        Flags show that a dealer has a problem. The diagnostic layer asks what might be behind it, by testing each symptom against the dealer's
        other metrics, its regional peers and the wider network. Its outputs are hypotheses for management to validate — never confirmed causes —
        and it never changes health scores, flags or priorities.
      </p>
      <ol className="mt-3 flex flex-wrap gap-x-1 gap-y-1 text-[13px]">
        {['Symptom', 'Pattern', 'Possible cause', 'Evidence', 'Investigation', 'Action'].map((x, i) => (
          <li key={x} className="flex items-center gap-1">
            {i > 0 && <span className="text-steel-400">→</span>}
            <span className="rounded bg-steel-50 px-2 py-0.5 font-medium text-ink">{x}</span>
          </li>
        ))}
      </ol>
      <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
        {TREES.map(([symptom, branches]) => (
          <div key={symptom} className="rounded-md border border-steel-200 p-3">
            <div className="font-semibold text-ink">{symptom}</div>
            <ul className="mt-2 space-y-1.5 border-l border-steel-200 pl-3 text-[13px]">
              {branches.map(([cond, cause]) => (
                <li key={cond}><span className="text-steel-700">{cond}</span><span className="block text-steel-500">→ {cause}</span></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="mt-4 grid gap-4 md:grid-cols-3 text-[13px]">
        <div>
          <h3 className="font-semibold text-ink">Confidence</h3>
          <ul className="mt-1 space-y-0.5 text-steel-700">
            <li><b>High</b> — multiple independent indicators support the hypothesis.</li>
            <li><b>Medium</b> — a meaningful pattern, but additional data is required.</li>
            <li><b>Low</b> — an initial signal; supporting evidence is insufficient.</li>
          </ul>
          <p className="mt-1 text-steel-700">If nothing is supported, the dealer shows “Insufficient evidence — additional data required”. Rules:
            <b>High</b>: three or more supporting signals that are consistent across several dealers, or four or more for one dealer, with no key data missing.
            <b> Medium</b>: two or more signals. <b>Low</b>: one signal, or the data cannot separate competing explanations. Contradicting evidence lowers
            confidence; ruling out other causes counts as one signal; missing validation data caps confidence at Medium.
          </p>
        </div>
        <div>
          <h3 className="font-semibold text-ink">Dealer, region, product or network?</h3>
          <p className="mt-1 text-steel-700">
            A symptom counts as regional when at least 3 dealers and 40% of a region share it, at 1.5× the rate elsewhere. A product issue needs elevated
            complaints at 3+ dealers in 2+ regions. Network-wide means half of all dealers. Shared patterns are flagged so management does not treat a
            regional or product issue as several separate dealer failures.
          </p>
        </div>
        <div>
          <h3 className="font-semibold text-ink">Ranking</h3>
          <p className="mt-1 text-steel-700">
            Possible causes are ranked by confidence, then by how severe the symptom they explain is, then by net evidence. The top one is shown as
            the primary hypothesis with cause → why → evidence → how to validate → action; the others stay collapsed.
          </p>
          <h3 className="mt-3 font-semibold text-ink">No fabricated data</h3>
          <p className="mt-1 text-steel-700">
            Transport, product, funnel, competitor and service hypotheses need optional data columns. When a column is absent the app says which data
            would validate the hypothesis instead of assuming a value. The default synthetic data has core metrics only and is a single snapshot,
            so “What changed?” appears only when a file supplies previous-period values.
          </p>
        </div>
      </div>
    </section>
    </div>
  );
}
