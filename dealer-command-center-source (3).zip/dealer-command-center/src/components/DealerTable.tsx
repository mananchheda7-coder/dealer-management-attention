import { useMemo, useState } from 'react';
import type { FlagKey, Priority, RiskLevel, ScoredDealer } from '../model/scoring';
import { byAttention, FLAG_LABEL, THRESHOLDS } from '../model/scoring';
import { Panel, PriorityBadge, RiskBadge, ScoreNumber, signed } from './ui';

type SortKey = 'priority' | 'score_asc' | 'score_desc' | 'sales_desc' | 'growth_asc' | 'inventory_desc' | 'payment_desc' | 'complaints_desc' | 'capital_desc';

const SORT_LABEL: Record<SortKey, string> = {
  priority: 'Priority (most urgent first)',
  score_asc: 'Health score (lowest first)',
  score_desc: 'Health score (highest first)',
  sales_desc: 'Sales achievement (highest first)',
  growth_asc: 'Sales growth (lowest first)',
  inventory_desc: 'Inventory age (oldest first)',
  payment_desc: 'Payment delay (longest first)',
  complaints_desc: 'Complaints / 100 (highest first)',
  capital_desc: 'Capital at risk (highest first)',
};

export default function DealerTable({ dealers, onOpen }: { dealers: ScoredDealer[]; onOpen: (id: string) => void }) {
  const [q, setQ] = useState('');
  const [region, setRegion] = useState('All');
  const [risk, setRisk] = useState<'All' | RiskLevel>('All');
  const [pri, setPri] = useState<'All' | Priority>('All');
  const [sort, setSort] = useState<SortKey>('priority');
  const [flag, setFlag] = useState<'All' | FlagKey>('All');

  const regions = useMemo(() => ['All', ...[...new Set(dealers.map((d) => d.region))].sort()], [dealers]);

  const rows = useMemo(() => {
    const term = q.trim().toLowerCase();
    const filtered = dealers.filter(
      (d) =>
        (!term || `${d.dealer_name} ${d.dealer_id} ${d.city}`.toLowerCase().includes(term)) &&
        (region === 'All' || d.region === region) &&
        (risk === 'All' || d.risk_level === risk) &&
        (pri === 'All' || d.priority === pri) &&
        (flag === 'All' || d.flags[flag].severity !== 'none'),
    );
    const cmp: Record<SortKey, (a: ScoredDealer, b: ScoredDealer) => number> = {
      priority: byAttention,
      score_asc: (a, b) => a.health_score - b.health_score,
      score_desc: (a, b) => b.health_score - a.health_score,
      sales_desc: (a, b) => b.sales_achievement_pct - a.sales_achievement_pct,
      growth_asc: (a, b) => a.sales_growth_pct - b.sales_growth_pct,
      inventory_desc: (a, b) => b.inventory_age_days - a.inventory_age_days,
      payment_desc: (a, b) => b.payment_delay_days - a.payment_delay_days,
      complaints_desc: (a, b) => b.complaints_per_100 - a.complaints_per_100,
      capital_desc: (a, b) => b.capital_at_risk_cr - a.capital_at_risk_cr,
    };
    return [...filtered].sort(cmp[sort]);
  }, [dealers, q, region, risk, pri, sort, flag]);

  const dirty = q || region !== 'All' || risk !== 'All' || pri !== 'All' || flag !== 'All' || sort !== 'priority';
  const reset = () => { setQ(''); setRegion('All'); setRisk('All'); setPri('All'); setFlag('All'); setSort('priority'); };

  const sel = 'rounded border border-steel-200 bg-white px-2.5 py-1.5 text-sm text-ink';
  const tone = (bad: boolean, warn: boolean) => (bad ? 'text-crit font-semibold' : warn ? 'text-warn font-medium' : 'text-steel-700');
  const th = 'px-3 py-2 text-left text-xs font-medium text-steel-500 whitespace-nowrap';

  const headerSort = (key: 'score' | 'priority') => (
    <button
      className="inline-flex items-center gap-1 hover:text-info"
      onClick={() => setSort(key === 'priority' ? 'priority' : sort === 'score_asc' ? 'score_desc' : 'score_asc')}
      aria-label={`Sort by ${key}`}
    >
      {key === 'score' ? 'Health score' : 'Priority'}
      <span className="text-[10px]">
        {key === 'priority' && sort === 'priority' ? '▲' : key === 'score' && sort === 'score_asc' ? '▲' : key === 'score' && sort === 'score_desc' ? '▼' : '↕'}
      </span>
    </button>
  );

  return (
    <Panel id="table" title="Dealer directory" subtitle="Search, filter and sort the full network. Select a row to open the dealer's detail.">
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search dealer, ID or city"
          aria-label="Search dealers"
          className="w-64 rounded border border-steel-200 px-3 py-1.5 text-sm placeholder:text-steel-400"
        />
        <select aria-label="Region filter" className={sel} value={region} onChange={(e) => setRegion(e.target.value)}>
          {regions.map((r) => <option key={r} value={r}>{r === 'All' ? 'All regions' : r}</option>)}
        </select>
        <select aria-label="Health status filter" className={sel} value={risk} onChange={(e) => setRisk(e.target.value as typeof risk)}>
          <option value="All">All health statuses</option>
          <option>Critical</option><option>Watch</option><option>Healthy</option>
        </select>
        <select aria-label="Priority filter" className={sel} value={pri} onChange={(e) => setPri(e.target.value as typeof pri)}>
          <option value="All">All priorities</option>
          <option value="P1">P1 · Immediate</option><option value="P2">P2 · Near-term</option><option value="P3">P3 · Monitor</option>
        </select>
        <select aria-label="Risk flag filter" className={sel} value={flag} onChange={(e) => setFlag(e.target.value as typeof flag)}>
          <option value="All">Any risk flag</option>
          {(Object.keys(FLAG_LABEL) as FlagKey[]).map((k) => <option key={k} value={k}>{FLAG_LABEL[k]}</option>)}
        </select>
        <select aria-label="Sort order" className={sel} value={sort} onChange={(e) => setSort(e.target.value as SortKey)}>
          {(Object.keys(SORT_LABEL) as SortKey[]).map((k) => <option key={k} value={k}>Sort: {SORT_LABEL[k]}</option>)}
        </select>
        <button onClick={reset} disabled={!dirty} className="rounded px-3 py-1.5 text-sm font-medium text-info hover:bg-info/10 disabled:text-steel-400 disabled:hover:bg-transparent">
          Reset filters
        </button>
        <span className="ml-auto text-sm text-steel-500" data-testid="row-count">{rows.length} of {dealers.length} dealers</span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full min-w-[960px] text-sm">
          <thead className="border-b border-steel-200 bg-steel-50">
            <tr>
              <th className={th}>Dealer</th><th className={th}>Region</th><th className={th}>City</th>
              <th className={`${th} text-right`}>Sales ach.</th><th className={`${th} text-right`}>Growth</th>
              <th className={`${th} text-right`}>Inventory age</th><th className={`${th} text-right`}>Payment delay</th>
              <th className={`${th} text-right`}>Complaints /100</th>
              <th className={`${th} text-right`}>{headerSort('score')}</th>
              <th className={th}>Health status</th>
              <th className={th}>{headerSort('priority')}</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((d) => (
              <tr
                key={d.dealer_id}
                onClick={() => onOpen(d.dealer_id)}
                onKeyDown={(e) => e.key === 'Enter' && onOpen(d.dealer_id)}
                tabIndex={0}
                className="cursor-pointer border-b border-steel-100 hover:bg-steel-50 focus:bg-steel-50"
              >
                <td className="px-3 py-2"><span className="font-medium text-ink">{d.dealer_name}</span> <span className="text-xs text-steel-400">{d.dealer_id}</span></td>
                <td className="px-3 py-2 text-steel-700">{d.region}</td>
                <td className="px-3 py-2 text-steel-700">{d.city}</td>
                <td className={`px-3 py-2 text-right tnum ${tone(d.sales_achievement_pct < THRESHOLDS.sales.severeAch, d.sales_achievement_pct < THRESHOLDS.sales.moderateAch)}`}>{d.sales_achievement_pct}%</td>
                <td className={`px-3 py-2 text-right tnum ${tone(d.sales_growth_pct <= THRESHOLDS.sales.severeGrowth, d.sales_growth_pct < THRESHOLDS.sales.moderateGrowth)}`}>{signed(d.sales_growth_pct)}</td>
                <td className={`px-3 py-2 text-right tnum ${tone(d.flags.inventory_risk.severity === 'severe', d.flags.inventory_risk.severity === 'moderate')}`}>{d.inventory_age_days} d</td>
                <td className={`px-3 py-2 text-right tnum ${tone(d.flags.payment_risk.severity === 'severe', d.flags.payment_risk.severity === 'moderate')}`}>{d.payment_delay_days} d</td>
                <td className={`px-3 py-2 text-right tnum ${tone(d.flags.customer_risk.severity === 'severe', d.flags.customer_risk.severity === 'moderate')}`}>{d.complaints_per_100}</td>
                <td className="px-3 py-2 text-right text-base"><ScoreNumber score={d.health_score} level={d.risk_level} /></td>
                <td className="px-3 py-2"><RiskBadge level={d.risk_level} /></td>
                <td className="px-3 py-2"><PriorityBadge p={d.priority} /></td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={11} className="px-3 py-10 text-center text-steel-500">No dealers match these filters. <button onClick={reset} className="font-medium text-info hover:underline">Reset filters</button> to see the full network.</td></tr>
            )}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-xs text-steel-500">Red values breach a severe threshold; amber values breach a watch threshold.</p>
    </Panel>
  );
}
