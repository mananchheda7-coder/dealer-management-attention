import type { ScoredDealer } from '../model/scoring';
import { PriorityBadge, RISK_COLOR, RiskBadge, signed } from './ui';

interface Props {
  a: ScoredDealer; // looks strong on sales (D003)
  b: ScoredDealer; // healthier operational profile (D009)
  onOpen: (id: string) => void;
}

type Row = { label: string; va: string; vb: string; better: 'a' | 'b' | null; group: 'sales' | 'ops' };

export default function Comparison({ a, b, onOpen }: Props) {
  const rows: Row[] = [
    { label: 'Sales achievement', va: `${a.sales_achievement_pct}%`, vb: `${b.sales_achievement_pct}%`, better: a.sales_achievement_pct > b.sales_achievement_pct ? 'a' : 'b', group: 'sales' },
    { label: 'Sales growth', va: signed(a.sales_growth_pct), vb: signed(b.sales_growth_pct), better: a.sales_growth_pct > b.sales_growth_pct ? 'a' : a.sales_growth_pct < b.sales_growth_pct ? 'b' : null, group: 'sales' },
    { label: 'Inventory age', va: `${a.inventory_age_days} days`, vb: `${b.inventory_age_days} days`, better: a.inventory_age_days < b.inventory_age_days ? 'a' : 'b', group: 'ops' },
    { label: 'Payment delay', va: `${a.payment_delay_days} days`, vb: `${b.payment_delay_days} days`, better: a.payment_delay_days < b.payment_delay_days ? 'a' : 'b', group: 'ops' },
    { label: 'Complaints / 100', va: `${a.complaints_per_100}`, vb: `${b.complaints_per_100}`, better: a.complaints_per_100 < b.complaints_per_100 ? 'a' : 'b', group: 'ops' },
    { label: 'Capital at risk', va: `₹${a.capital_at_risk_cr} Cr`, vb: `₹${b.capital_at_risk_cr} Cr`, better: a.capital_at_risk_cr < b.capital_at_risk_cr ? 'a' : 'b', group: 'ops' },
  ];

  const Head = ({ d, tone }: { d: ScoredDealer; tone: string }) => (
    <button onClick={() => onOpen(d.dealer_id)} className="w-full text-left hover:opacity-80">
      <span className="block text-xs text-steel-500">{tone}</span>
      <span className="block font-semibold text-ink">{d.dealer_name.toUpperCase()} ({d.dealer_id})</span>
      <span className="text-xs text-steel-500">{d.city}, {d.region}</span>
    </button>
  );

  const cell = (v: string, win: boolean) => (
    <td className={`px-4 py-2.5 text-right font-cond text-base tnum ${win ? 'font-semibold text-ink' : 'text-steel-500'}`}>
      {v}
      {win && <span className="ml-1.5 inline-block h-1.5 w-1.5 -translate-y-0.5 rounded-full bg-info align-middle" aria-label="better" />}
    </td>
  );

  return (
    <section id="comparison" className="rounded-lg border border-steel-200 bg-white">
      <div className="grid gap-0 lg:grid-cols-[minmax(0,1.15fr)_minmax(0,1fr)]">
        <div className="border-b border-steel-100 p-6 lg:border-b-0 lg:border-r">
          <h2 className="font-cond text-2xl font-semibold leading-tight tracking-wide text-ink">WHY SALES ALONE IS NOT ENOUGH</h2>
          <p className="mt-1 text-[15px] font-medium text-ink">Sales performance and sustainable dealer health can tell different stories.</p>
          <p className="mt-2 max-w-prose text-sm leading-relaxed text-steel-700">
            Ranked on sales, {a.dealer_name} beats {b.dealer_name} by {Math.round(a.sales_achievement_pct - b.sales_achievement_pct)} points of target
            achievement. Ranked on sustainable health, the order flips.
          </p>

          <table className="mt-5 w-full text-sm">
            <thead>
              <tr className="border-b border-steel-200 align-bottom">
                <th className="py-2 pr-2 text-left text-xs font-medium text-steel-500">Metric</th>
                <th className="w-[38%] px-4 py-2"><Head d={a} tone="Looks stronger on sales" /></th>
                <th className="w-[38%] px-4 py-2"><Head d={b} tone="Healthier operations" /></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={r.label} className={`border-b border-steel-100 ${i === 2 ? 'border-t-2 border-t-steel-200' : ''}`}>
                  <td className="py-2.5 pr-2 text-steel-700">
                    {r.label}
                    {i === 0 && <span className="block text-[11px] text-steel-400">what a sales report shows</span>}
                    {i === 2 && <span className="block text-[11px] text-steel-400">what it hides</span>}
                  </td>
                  {cell(r.va, r.better === 'a')}
                  {cell(r.vb, r.better === 'b')}
                </tr>
              ))}
              <tr className="border-t-2 border-steel-200">
                <td className="py-3 pr-2 font-semibold text-ink">Health score</td>
                {[a, b].map((d) => (
                  <td key={d.dealer_id} className="px-4 py-3 text-right">
                    <span className="font-cond text-3xl font-semibold tnum" style={{ color: RISK_COLOR[d.risk_level] }}>{d.health_score}</span>
                    <span className="text-xs text-steel-400">/100</span>
                    <span className="ml-2"><RiskBadge level={d.risk_level} /></span>
                  </td>
                ))}
              </tr>
              <tr>
                <td className="py-2 pr-2 font-semibold text-ink">Priority</td>
                {[a, b].map((d) => (
                  <td key={d.dealer_id} className="px-4 py-2 text-right"><PriorityBadge p={d.priority} withLabel /></td>
                ))}
              </tr>
            </tbody>
          </table>
        </div>

        <div className="flex flex-col gap-6 bg-steel-50 p-6">
          <div>
            <h3 className="text-sm font-semibold text-ink">What this means for a regional manager</h3>
            <p className="mt-2 text-sm leading-relaxed text-steel-700">
              {a.dealer_name} hits {a.sales_achievement_pct}% of target, but stock has aged to {a.inventory_age_days} days and payments run{' '}
              {a.payment_delay_days} days late — about ₹{a.capital_at_risk_cr} Cr of the manufacturer's capital is tied up there. Pushing more
              volume into this dealer would deepen the problem.
            </p>
            <p className="mt-3 text-sm leading-relaxed text-steel-700">
              {b.dealer_name} sells less ({b.sales_achievement_pct}% of target) but turns stock in {b.inventory_age_days} days, pays within{' '}
              {b.payment_delay_days} days of terms and has {b.complaints_per_100} complaints per 100 vehicles. Its growth is sustainable; it needs
              routine monitoring, not intervention.
            </p>
          </div>
          <div className="rounded-md border border-info/30 bg-white p-4">
            <p className="text-sm font-semibold text-ink">A dealer can look successful on sales and still carry significant operational and financial risk.</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button onClick={() => onOpen(a.dealer_id)} className="rounded border border-steel-200 bg-white px-3 py-1.5 text-sm font-medium text-ink hover:border-info hover:text-info">
                Open {a.dealer_name}
              </button>
              <button onClick={() => onOpen(b.dealer_id)} className="rounded border border-steel-200 bg-white px-3 py-1.5 text-sm font-medium text-ink hover:border-info hover:text-info">
                Open {b.dealer_name}
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
