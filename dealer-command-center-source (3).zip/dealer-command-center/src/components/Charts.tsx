import {
  Bar, BarChart, CartesianGrid, Cell, Label, Legend, Pie, PieChart, ReferenceArea, ReferenceLine,
  ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis,
} from 'recharts';
import type { RiskLevel, ScoredDealer } from '../model/scoring';
import { FLAG_LABEL, RISK_KEYS, THRESHOLDS } from '../model/scoring';
import { Panel, RISK_COLOR } from './ui';

const AXIS = { fontSize: 11, fill: '#5F6C7D' };
const GRID = '#E4E8EE';
const LEVELS: RiskLevel[] = ['Healthy', 'Watch', 'Critical'];

interface Props {
  dealers: ScoredDealer[];
  onOpen: (id: string) => void;
}

function DealerTip({ active, payload }: { active?: boolean; payload?: { payload: ScoredDealer }[] }) {
  if (!active || !payload?.length) return null;
  const d = payload[0].payload;
  return (
    <div className="rounded border border-steel-200 bg-white px-3 py-2 text-xs shadow-sm">
      <div className="font-semibold text-ink">{d.dealer_name} <span className="font-normal text-steel-500">{d.dealer_id}</span></div>
      <div className="text-steel-700">Health {d.health_score}/100 · {d.risk_level} · {d.priority}</div>
      <div className="text-steel-700">Sales {d.sales_achievement_pct}% of target · stock age {d.inventory_age_days} days</div>
      <div className="mt-1 text-info">Select to open</div>
    </div>
  );
}

export default function Charts({ dealers, onOpen }: Props) {
  const dist = LEVELS.map((l) => ({ name: l, value: dealers.filter((d) => d.risk_level === l).length }));
  const byScore = [...dealers].sort((a, b) => a.health_score - b.health_score);
  const drivers = RISK_KEYS.map((k) => ({
    name: FLAG_LABEL[k].replace(' risk', ''),
    Severe: dealers.filter((d) => d.flags[k].severity === 'severe').length,
    Moderate: dealers.filter((d) => d.flags[k].severity === 'moderate').length,
  }));
  const regions = [...new Set(dealers.map((d) => d.region))]
    .map((r) => {
      const ds = dealers.filter((d) => d.region === r);
      return {
        region: r,
        score: Math.round(ds.reduce((s, d) => s + d.health_score, 0) / ds.length),
        dealers: ds.length,
        p1: ds.filter((d) => d.priority === 'P1').length,
      };
    })
    .sort((a, b) => a.score - b.score);
  const avg = Math.round(dealers.reduce((s, d) => s + d.health_score, 0) / dealers.length);
  const xMin = Math.min(55, Math.floor(Math.min(...dealers.map((d) => d.sales_achievement_pct)) / 5) * 5 - 5);
  const xMax = Math.max(115, Math.ceil(Math.max(...dealers.map((d) => d.sales_achievement_pct)) / 5) * 5 + 5);
  const yMin = Math.min(20, Math.floor(Math.min(...dealers.map((d) => d.inventory_age_days)) / 10) * 10);
  const yMax = Math.max(90, Math.ceil(Math.max(...dealers.map((d) => d.inventory_age_days)) / 10) * 10);
  const hidden = dealers.filter((d) => d.sales_achievement_pct >= THRESHOLDS.strongSales && d.inventory_age_days >= THRESHOLDS.inventory.severe);

  return (
    <div id="analytics" className="grid gap-5 lg:grid-cols-12">
      {/* Sales vs inventory — the key insight, given the widest slot */}
      <Panel
        id="scatter"
        className="lg:col-span-8"
        title="Sales vs inventory age"
        subtitle="Each dot is a dealer. The shaded zone holds dealers that hit their sales numbers while stock goes stale."
      >
        <div className="h-[340px]">
          <ResponsiveContainer>
            <ScatterChart margin={{ top: 10, right: 20, bottom: 28, left: 4 }}>
              <CartesianGrid stroke={GRID} />
              <ReferenceArea x1={THRESHOLDS.strongSales} x2={xMax} y1={THRESHOLDS.inventory.severe} y2={yMax} fill="#C2362B" fillOpacity={0.07} stroke="#C2362B" strokeOpacity={0.3} strokeDasharray="4 3">
                <Label value="Strong sales, ageing stock" position="insideTopRight" fill="#C2362B" fontSize={11} fontWeight={600} />
              </ReferenceArea>
              <ReferenceLine x={THRESHOLDS.strongSales} stroke="#8592A3" strokeDasharray="3 3" />
              <ReferenceLine y={THRESHOLDS.inventory.severe} stroke="#8592A3" strokeDasharray="3 3">
                <Label value="70-day stock-age limit" position="insideBottomLeft" fill="#5F6C7D" fontSize={10} />
              </ReferenceLine>
              <XAxis type="number" dataKey="sales_achievement_pct" domain={[xMin, xMax]} tick={AXIS} name="Sales achievement" unit="%">
                <Label value="Sales achievement (% of target)" position="bottom" offset={10} style={AXIS} />
              </XAxis>
              <YAxis type="number" dataKey="inventory_age_days" domain={[yMin, yMax]} tick={AXIS} name="Inventory age" width={44}>
                <Label value="Inventory age (days)" angle={-90} position="insideLeft" style={{ ...AXIS, textAnchor: 'middle' }} />
              </YAxis>
              <ZAxis range={[70, 70]} />
              <Tooltip content={<DealerTip />} cursor={{ strokeDasharray: '3 3' }} />
              {LEVELS.map((l) => (
                <Scatter
                  key={l}
                  name={l}
                  data={dealers.filter((d) => d.risk_level === l)}
                  fill={RISK_COLOR[l]}
                  fillOpacity={l === 'Healthy' ? 0.55 : 0.85}
                  stroke="#fff"
                  onClick={(p: unknown) => onOpen((p as { payload: ScoredDealer }).payload.dealer_id)}
                  className="cursor-pointer"
                />
              ))}
              <Scatter
                data={hidden}
                fill="none"
                shape={(props: unknown) => {
                  const { cx, cy, payload } = props as { cx: number; cy: number; payload: ScoredDealer };
                  return (
                    <g>
                      <circle cx={cx} cy={cy} r={9} fill="none" stroke="#18222F" strokeWidth={1.5} />
                      <text x={cx - 12} y={cy + 4} textAnchor="end" fontSize={11} fontWeight={600} fill="#18222F">{payload.dealer_name}</text>
                    </g>
                  );
                }}
                legendType="none"
              />
              <Legend verticalAlign="top" align="left" iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12, paddingBottom: 6 }} />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
        <p className="mt-2 text-[13px] text-steel-700">
          {hidden.length} dealers sell at {THRESHOLDS.strongSales}%+ of target with stock older than {THRESHOLDS.inventory.severe} days. A sales-only
          review would rank them among the best in the network.
        </p>
      </Panel>

      <Panel id="risk-distribution" className="lg:col-span-4" title="Risk distribution" subtitle="Dealers by health band">
        <div className="relative h-[250px]">
          <ResponsiveContainer>
            <PieChart>
              <Pie data={dist} dataKey="value" nameKey="name" innerRadius={68} outerRadius={100} paddingAngle={2} stroke="none" isAnimationActive={false}>
                {dist.map((d) => <Cell key={d.name} fill={RISK_COLOR[d.name as RiskLevel]} />)}
              </Pie>
              <Tooltip formatter={(v: number, n: string) => [`${v} dealers`, n]} />
            </PieChart>
          </ResponsiveContainer>
          <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
            <span className="font-cond text-3xl font-semibold text-ink tnum">{avg}</span>
            <span className="text-xs text-steel-500">avg health</span>
          </div>
        </div>
        <ul className="mt-2 space-y-1.5 text-sm">
          {dist.map((d) => (
            <li key={d.name} className="flex items-center justify-between">
              <span className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-sm" style={{ background: RISK_COLOR[d.name as RiskLevel] }} />
                {d.name}
                <span className="text-xs text-steel-400">{d.name === 'Healthy' ? '75–100' : d.name === 'Watch' ? '50–74' : '0–49'}</span>
              </span>
              <span className="font-cond font-semibold tnum">{d.value}</span>
            </li>
          ))}
        </ul>
      </Panel>

      <Panel id="risk-drivers" className="lg:col-span-5" title="Risk drivers" subtitle="Dealers breaching each risk threshold">
        <div className="h-[260px]">
          <ResponsiveContainer>
            <BarChart data={drivers} margin={{ top: 4, right: 8, bottom: 0, left: -18 }}>
              <CartesianGrid stroke={GRID} vertical={false} />
              <XAxis dataKey="name" tick={AXIS} />
              <YAxis allowDecimals={false} tick={AXIS} />
              <Tooltip cursor={{ fill: '#F2F4F7' }} />
              <Legend iconType="square" iconSize={9} wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="Severe" stackId="a" fill="#C2362B" isAnimationActive={false} />
              <Bar dataKey="Moderate" stackId="a" fill="#E0B14A" radius={[3, 3, 0, 0]} isAnimationActive={false} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Panel>

      <Panel id="regional" className="lg:col-span-3" title="Regional health" subtitle="Average health score">
        <div className="h-[260px]">
          <ResponsiveContainer>
            <BarChart data={regions} layout="vertical" margin={{ top: 4, right: 28, bottom: 0, left: 0 }}>
              <CartesianGrid stroke={GRID} horizontal={false} />
              <XAxis type="number" domain={[0, 100]} tick={AXIS} />
              <YAxis type="category" dataKey="region" tick={AXIS} width={72} />
              <ReferenceLine x={75} stroke="#1D8556" strokeDasharray="3 3" />
              <ReferenceLine x={50} stroke="#C2362B" strokeDasharray="3 3" />
              <Tooltip formatter={(v: number) => [`${v}/100`, 'Avg health']} labelFormatter={(r) => `${r} region`} cursor={{ fill: '#F2F4F7' }} />
              <Bar dataKey="score" radius={[0, 3, 3, 0]} isAnimationActive={false} label={{ position: 'right', fontSize: 11, fill: '#36414F' }}>
                {regions.map((r) => <Cell key={r.region} fill={r.score >= 75 ? '#1D8556' : r.score >= 50 ? '#B87A0A' : '#C2362B'} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Panel>

      <Panel id="health-bars" className="lg:col-span-4" title="Dealer health scores" subtitle={`All ${dealers.length} dealers, weakest first. Select a bar to open.`}>
        <div className="h-[260px] overflow-y-auto pr-1">
          <div style={{ height: byScore.length * 20 + 20 }}>
            <ResponsiveContainer>
              <BarChart data={byScore} layout="vertical" margin={{ top: 0, right: 26, bottom: 0, left: 0 }} barCategoryGap={3}>
                <XAxis type="number" domain={[0, 100]} hide />
                <YAxis type="category" dataKey="dealer_name" tick={{ fontSize: 10, fill: '#36414F' }} width={128} interval={0} />
                <ReferenceLine x={75} stroke="#1D8556" strokeDasharray="3 3" />
                <ReferenceLine x={50} stroke="#C2362B" strokeDasharray="3 3" />
                <Tooltip content={<DealerTip />} cursor={{ fill: '#F2F4F7' }} />
                <Bar
                  dataKey="health_score"
                  isAnimationActive={false}
                  className="cursor-pointer"
                  onClick={(p: unknown) => onOpen((p as ScoredDealer).dealer_id)}
                  label={{ position: 'right', fontSize: 10, fill: '#5F6C7D' }}
                >
                  {byScore.map((d) => <Cell key={d.dealer_id} fill={RISK_COLOR[d.risk_level]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </Panel>
    </div>
  );
}
