import type { ReactNode } from 'react';
import type { Priority, RiskLevel, Severity } from '../model/scoring';

export const RISK_COLOR: Record<RiskLevel, string> = { Healthy: '#1D8556', Watch: '#B87A0A', Critical: '#C2362B' };
export const RISK_SOFT: Record<RiskLevel, string> = { Healthy: '#E3F3EA', Watch: '#FBF0D9', Critical: '#FBE5E2' };
export const SEV_COLOR: Record<Severity, string> = { none: '#1D8556', moderate: '#B87A0A', severe: '#C2362B' };
export const PRIORITY_LABEL: Record<Priority, string> = {
  P1: 'Immediate attention',
  P2: 'Near-term attention',
  P3: 'Monitor',
};

export function RiskBadge({ level, size = 'sm' }: { level: RiskLevel; size?: 'sm' | 'md' }) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full font-semibold ${size === 'md' ? 'px-3 py-1 text-sm' : 'px-2 py-0.5 text-xs'}`}
      style={{ background: RISK_SOFT[level], color: RISK_COLOR[level] }}
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: RISK_COLOR[level] }} />
      {level}
    </span>
  );
}

export function PriorityBadge({ p, withLabel = false }: { p: Priority; withLabel?: boolean }) {
  const styles: Record<Priority, string> = {
    P1: 'bg-crit text-white',
    P2: 'bg-warn-soft text-warn border border-warn/40',
    P3: 'bg-steel-100 text-steel-700',
  };
  return (
    <span className={`inline-flex items-center gap-1.5 rounded px-2 py-0.5 font-cond text-xs font-semibold tracking-wide ${styles[p]}`}>
      {p}
      {withLabel && <span className="font-sans font-medium">{PRIORITY_LABEL[p]}</span>}
    </span>
  );
}

export function SeverityChip({ label, severity }: { label: string; severity: Severity }) {
  const cls =
    severity === 'severe'
      ? 'bg-crit-soft text-crit border-crit/30'
      : severity === 'moderate'
        ? 'bg-warn-soft text-warn border-warn/30'
        : 'bg-white text-steel-400 border-steel-200';
  return (
    <span className={`inline-flex items-center gap-1 rounded border px-2 py-0.5 text-xs font-medium ${cls}`}>
      {severity !== 'none' && <span className="h-1.5 w-1.5 rounded-full" style={{ background: SEV_COLOR[severity] }} />}
      {label}
      {severity !== 'none' && <span className="opacity-70">· {severity}</span>}
    </span>
  );
}

export function ScoreNumber({ score, level, className = '' }: { score: number; level: RiskLevel; className?: string }) {
  return (
    <span className={`font-cond font-semibold tnum ${className}`} style={{ color: RISK_COLOR[level] }}>
      {score}
    </span>
  );
}

export function Panel({ id, title, subtitle, children, className = '', right }: { id?: string; title: string; subtitle?: string; children: ReactNode; className?: string; right?: ReactNode }) {
  return (
    <section id={id} className={`rounded-lg border border-steel-200 bg-white ${className}`}>
      <header className="flex flex-wrap items-end justify-between gap-2 border-b border-steel-100 px-5 py-3.5">
        <div>
          <h2 className="text-[15px] font-semibold text-ink">{title}</h2>
          {subtitle && <p className="mt-0.5 text-[13px] text-steel-500">{subtitle}</p>}
        </div>
        {right}
      </header>
      <div className="p-5">{children}</div>
    </section>
  );
}

export const signed = (n: number, unit = '%') => `${n > 0 ? '+' : ''}${n}${unit}`;
