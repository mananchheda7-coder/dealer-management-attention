import { useEffect, useRef, useState } from 'react';
import type { ScoredDealer } from '../model/scoring';
import type { DealerDiagnostics } from '../model/diagnostics';

export type Page = 'dashboard' | 'dealers' | 'insights' | 'data' | 'methodology';

export interface DemoStep {
  page: Page;
  target: string;
  title: string;
  text: string;
  ms: number;
  dealer: string | null;
}

export function buildSteps(queue: ScoredDealer[], focus: ScoredDealer | null, pair: [ScoredDealer, ScoredDealer] | null, diag?: DealerDiagnostics): DemoStep[] {
  const p1 = queue.filter((d) => d.priority === 'P1').length;
  const crit = queue.filter((d) => d.risk_level === 'Critical').length;
  const steps: DemoStep[] = [
    { page: 'dashboard', target: 'kpis', dealer: null, ms: 6500, title: 'The network at a glance', text: `${queue.length} dealers. ${crit} are Critical on health, but ${p1} need immediate management attention — priority looks beyond the score.` },
    { page: 'dashboard', target: 'queue', dealer: null, ms: 7000, title: 'Where to spend attention today', text: 'The queue ranks dealers by priority, risk depth and capital at risk. Sales volume plays no part in the ranking.' },
  ];
  if (focus) {
    const gaps = [...focus.components].sort((x, y) => y.lost - x.lost).slice(0, 2);
    const rank = queue.indexOf(focus) + 1;
    const top = diag?.primary;
    steps.push(
      { page: 'dashboard', target: `queue-row-${focus.dealer_id}`, dealer: null, ms: 6000, title: `${focus.dealer_name} is #${rank}`, text: focus.sales_achievement_pct >= 90 ? `It delivers ${focus.sales_achievement_pct}% of target — a sales report would call it a top performer. So why is it here?` : `It delivers ${focus.sales_achievement_pct}% of target. Here is why it leads the queue.` },
      { page: 'dashboard', target: 'detail-score', dealer: focus.dealer_id, ms: 7000, title: `Health ${focus.health_score} (${focus.risk_level}) — priority ${focus.priority}`, text: `Health is the overall condition; priority is urgency. ${focus.priority_reason}.` },
      { page: 'dashboard', target: 'detail-why', dealer: focus.dealer_id, ms: 7000, title: 'Why it is flagged', text: 'Every reason is generated from the dealer\u2019s own numbers and compared with network and regional benchmarks.' },
    );
    if (top) steps.push({ page: 'dashboard', target: 'detail-rootcause', dealer: focus.dealer_id, ms: 8000, title: 'What might be causing it?', text: `Primary hypothesis: ${top.title.toLowerCase()} (${top.confidence} confidence) — with the evidence, how to validate it, and the action. Other possible causes stay collapsed.` });
    steps.push(
      { page: 'dashboard', target: 'detail-actions', dealer: focus.dealer_id, ms: 7000, title: 'What management should do', text: focus.headline_action },
      { page: 'dashboard', target: 'detail-breakdown', dealer: focus.dealer_id, ms: 7000, title: 'Every point is traceable', text: `It loses ${gaps.map((g) => `${g.lost} points on ${g.label.toLowerCase()}`).join(' and ')}. The full score breakdown sits below the decision flow.` },
    );
  }
  if (pair) {
    const [a, b] = pair;
    steps.push({ page: 'insights', target: 'comparison', dealer: null, ms: 7000, title: 'Why sales alone is not enough', text: `${a.dealer_name} out-sells ${b.dealer_name} (${a.sales_achievement_pct}% vs ${b.sales_achievement_pct}%) but scores ${a.health_score} vs ${b.health_score} on health.` });
  }
  return steps;
}

interface Props {
  steps: DemoStep[];
  onSetPage: (p: Page) => void;
  onSetDealer: (id: string | null) => void;
  onExit: () => void;
}

export default function Demo({ steps, onSetPage, onSetDealer, onExit }: Props) {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const step = steps[i];

  // Open/close the dealer for this step, then spotlight its target section.
  useEffect(() => {
    onSetPage(step.page);
    onSetDealer(step.dealer);
    let el: HTMLElement | null = null;
    const t = window.setTimeout(() => {
      el = document.getElementById(step.target);
      if (!el) return;
      const tall = el.offsetHeight > window.innerHeight * 0.6;
      el.scrollIntoView({ behavior: 'smooth', block: tall ? 'start' : 'center' });
      el.classList.add('demo-focus');
    }, 380);
    return () => {
      window.clearTimeout(t);
      el?.classList.remove('demo-focus');
    };
  }, [i, step, onSetDealer, onSetPage]);

  // Auto-advance; pause keeps the remaining time for this step
  const remaining = useRef(step.ms);
  const lastStep = useRef(-1);
  useEffect(() => {
    if (lastStep.current !== i) { lastStep.current = i; remaining.current = step.ms; }
    if (paused) return;
    const started = Date.now();
    const t = window.setTimeout(() => (i < steps.length - 1 ? setI(i + 1) : onExit()), remaining.current);
    return () => { window.clearTimeout(t); remaining.current -= Date.now() - started; };
  }, [i, paused, step.ms, steps.length, onExit]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') setI((n) => Math.min(steps.length - 1, n + 1));
      if (e.key === 'ArrowLeft') setI((n) => Math.max(0, n - 1));
      if (e.key === ' ') { e.preventDefault(); setPaused((p) => !p); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [steps.length]);

  const btn = 'rounded px-2.5 py-1 text-sm font-medium text-steel-200 hover:bg-white/10 hover:text-white disabled:opacity-40';
  return (
    <div className={`fixed inset-x-0 bottom-0 z-[60] flex px-4 ${step.dealer ? 'justify-start' : 'justify-center'}`} style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 16px)' }}>
      <div
        role="status"
        aria-live="polite"
        className={`w-full overflow-hidden rounded-lg bg-cab text-white shadow-2xl ring-1 ring-white/10 ${step.dealer ? 'max-w-[min(42rem,calc(100vw-900px))] min-w-[20rem]' : 'max-w-2xl'}`}
      >
        <div className="h-1 bg-white/10">
          <div key={i} className="h-full bg-info" style={{ animation: `demo-progress ${step.ms}ms linear forwards`, animationPlayState: paused ? 'paused' : 'running' }} />
        </div>
        <div className="flex items-start gap-4 px-5 py-3.5">
          <span className="mt-0.5 font-cond text-sm font-semibold text-steel-400 tnum">{i + 1}/{steps.length}</span>
          <div className="min-w-0 flex-1">
            <div className="font-semibold">{step.title}</div>
            <div className="mt-0.5 text-sm leading-snug text-steel-200">{step.text}</div>
          </div>
        </div>
        <div className="flex items-center justify-between border-t border-white/10 px-3 py-1.5">
          <span className="pl-2 text-[11px] text-steel-400">← → to step · space to pause</span>
          <div className="flex gap-1">
            <button className={btn} disabled={i === 0} onClick={() => setI(i - 1)}>Back</button>
            <button className={btn} onClick={() => setPaused((p) => !p)}>{paused ? 'Resume' : 'Pause'}</button>
            <button className={btn} onClick={() => (i < steps.length - 1 ? setI(i + 1) : onExit())}>{i < steps.length - 1 ? 'Next' : 'Finish'}</button>
            <button className={`${btn} text-white`} onClick={onExit}>Exit demo</button>
          </div>
        </div>
      </div>
      <style>{`@keyframes demo-progress { from { width: 0% } to { width: 100% } }`}</style>
    </div>
  );
}
