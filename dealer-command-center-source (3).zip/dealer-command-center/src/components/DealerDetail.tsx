import { useEffect, useRef } from 'react';
import type { ScoredDealer, Severity } from '../model/scoring';
import { FLAG_LABEL, THRESHOLDS } from '../model/scoring';
import type { DealerDiagnostics } from '../model/diagnostics';
import RootCause, { ConfidenceChip } from './RootCause';
import { PriorityBadge, RISK_COLOR, RISK_SOFT, RiskBadge, SEV_COLOR, SeverityChip, signed } from './ui';

interface Props {
  dealer: ScoredDealer | null;
  onClose: () => void;
  networkAvg: number;
  dataLabel: string;
  diag?: DealerDiagnostics;
  nameOf: (id: string) => string;
  onOpen: (id: string) => void;
  onGoData: () => void;
}

function MetricCard({ label, value, note, severity, info }: { label: string; value: string; note: string; severity: Severity; info?: boolean }) {
  const color = info ? '#2E66A8' : severity === 'none' ? '#1D8556' : SEV_COLOR[severity];
  return (
    <div className="rounded-md border border-steel-200 bg-white p-3" style={{ boxShadow: `inset 0 3px 0 ${color}` }}>
      <div className="text-xs text-steel-500">{label}</div>
      <div className="mt-1 font-cond text-2xl font-semibold tnum text-ink">{value}</div>
      <div className="mt-0.5 text-[11px] leading-snug" style={{ color: severity === 'none' && !info ? '#5F6C7D' : color }}>{note}</div>
    </div>
  );
}

const CHANGES: { label: string; prev: keyof ScoredDealer; cur: keyof ScoredDealer; unit: string; worseIfUp: boolean; material: number }[] = [
  { label: 'Inventory age', prev: 'prev_inventory_age_days', cur: 'inventory_age_days', unit: ' days', worseIfUp: true, material: 10 },
  { label: 'Payment delay', prev: 'prev_payment_delay_days', cur: 'payment_delay_days', unit: ' days', worseIfUp: true, material: 5 },
  { label: 'Complaints / 100', prev: 'prev_complaints_per_100', cur: 'complaints_per_100', unit: '', worseIfUp: true, material: 1 },
  { label: 'Service performance', prev: 'prev_service_performance', cur: 'service_performance', unit: '', worseIfUp: false, material: 5 },
];

/** Shown only when the data actually contains previous-period values — trends are never estimated. */
function WhatChanged({ d }: { d: ScoredDealer }) {
  const rows = CHANGES.filter((c) => d[c.prev] !== undefined);
  if (!rows.length) return null;
  const items = rows.map((c) => {
    const a = d[c.prev] as number, b = d[c.cur] as number;
    const delta = Math.round((b - a) * 10) / 10;
    const worse = c.worseIfUp ? delta >= c.material : -delta >= c.material;
    return { ...c, a, b, delta, worse };
  });
  const worsened = items.filter((x) => x.worse).length;
  return (
    <section id="detail-changes" className="rounded-lg border border-steel-200 bg-white p-5" data-testid="what-changed">
      <div className="flex flex-wrap items-center gap-2">
        <h3 className="text-[15px] font-semibold text-ink">What changed?</h3>
        <span className="text-xs text-steel-500">vs the previous period supplied in the data</span>
        {worsened >= 2 && <span className="rounded bg-warn-soft px-2 py-0.5 text-xs font-semibold text-warn">Emerging deterioration</span>}
      </div>
      <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-5">
        <div className="text-[13px]"><div className="text-xs text-steel-500">Sales vs last year</div><div className="font-cond text-lg text-ink">₹{d.previous_year_sales} → ₹{d.actual_sales} Cr</div><div className={d.sales_growth_pct < 0 ? 'text-xs text-crit' : 'text-xs text-steel-500'}>{d.sales_growth_pct > 0 ? '+' : ''}{d.sales_growth_pct}%</div></div>
        {items.map((x) => (
          <div key={x.label} className="text-[13px]">
            <div className="text-xs text-steel-500">{x.label}</div>
            <div className="font-cond text-lg text-ink">{x.a} → {x.b}{x.unit}</div>
            <div className={`text-xs ${x.worse ? 'font-semibold text-crit' : 'text-steel-500'}`}>{x.delta > 0 ? '+' : ''}{x.delta}{x.worse ? ' · worsened' : ''}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default function DealerDetail({ dealer: d, onClose, networkAvg, dataLabel, diag, nameOf, onOpen, onGoData }: Props) {
  const scroller = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!d) return;
    scroller.current?.scrollTo({ top: 0 });
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [d, onClose]);

  if (!d) return null;
  const f = d.flags;
  const sevNote = (s: Severity, ok: string, mod: string, sev: string) => (s === 'severe' ? sev : s === 'moderate' ? mod : ok);
  // Health and priority answer different questions; explain when they point different ways
  const severeNames = (Object.keys(d.flags) as (keyof typeof d.flags)[])
    .filter((k) => k !== 'market_opportunity' && d.flags[k].severity === 'severe')
    .map((k) => FLAG_LABEL[k].replace(' risk', '').toLowerCase());
  const urgentText = severeNames.length
    ? `Severe ${severeNames.length > 1 ? severeNames.slice(0, -1).join(', ') + ' and ' + severeNames[severeNames.length - 1] : severeNames[0]} risk${severeNames.length > 1 ? 's' : ''}`
    : d.flags.market_opportunity.severity !== 'none' ? 'Weak sales in a market where demand is available' : 'Multiple emerging risks';
  const urgentPlural = severeNames.length > 1 || (!severeNames.length && d.flags.market_opportunity.severity === 'none');
  const divergent = (d.priority === 'P1' && d.risk_level !== 'Critical') || (d.priority === 'P2' && d.risk_level === 'Healthy');
  const biggestGaps = [...d.components].sort((a, b) => b.lost - a.lost).filter((c) => c.lost >= 3).slice(0, 2);

  return (
    <div className="fixed inset-0 z-50 flex justify-end" role="dialog" aria-modal="true" aria-label={`${d.dealer_name} detail`}>
      <button className="absolute inset-0 bg-ink/40" onClick={onClose} aria-label="Close dealer detail" />
      <div ref={scroller} id="detail-scroller" className="relative h-full w-full max-w-[860px] overflow-y-auto bg-steel-50 shadow-2xl" style={{ paddingTop: 'env(safe-area-inset-top, 0px)', scrollPaddingTop: 96 }}>
        {/* Header */}
        <header className="sticky top-0 z-10 flex items-start justify-between gap-4 border-b border-steel-200 bg-white px-6 py-4">
          <div>
            <div className="text-xs text-steel-500">{d.dealer_id} · {d.city} · {d.region} region</div>
            <h2 className="mt-0.5 text-2xl font-semibold text-ink">{d.dealer_name}</h2>
          </div>
          <button onClick={onClose} className="rounded border border-steel-200 px-3 py-1.5 text-sm font-medium text-steel-700 hover:border-info hover:text-info">
            Close
          </button>
        </header>

        <div className="space-y-5 p-6">
          {/* Score block */}
          <section id="detail-score" className="grid gap-4 rounded-lg border border-steel-200 bg-white p-5 sm:grid-cols-[auto_1fr]">
            <div className="flex flex-col items-start justify-center rounded-md px-5 py-3" style={{ background: RISK_SOFT[d.risk_level] }}>
              <span className="text-[11px] font-semibold tracking-wide" style={{ color: RISK_COLOR[d.risk_level] }}>HEALTH · overall condition</span>
              <span className="font-cond text-6xl font-semibold leading-none tnum" style={{ color: RISK_COLOR[d.risk_level] }}>
                {d.health_score}<span className="text-2xl">/100</span>
              </span>
              <span className="mt-2"><RiskBadge level={d.risk_level} size="md" /></span>
            </div>
            <div className="flex flex-col justify-center gap-3">
              <div>
                <div className="text-[11px] font-semibold tracking-wide text-steel-500">MANAGEMENT PRIORITY · urgency of intervention</div>
                <div className="mt-1 flex flex-wrap items-center gap-2">
                  <PriorityBadge p={d.priority} withLabel />
                  <span className="text-sm text-steel-700">{d.priority_reason}.</span>
                </div>
                {divergent && (
                  <p className="mt-2 rounded border border-info/30 bg-info/10 px-3 py-1.5 text-[13px] text-ink" data-testid="health-vs-priority">
                    <span className="font-semibold">Why {d.priority} while health is {d.risk_level}?</span>{' '}
                    Health averages seven metrics; priority reacts to individual risks. {urgentText} {d.priority === 'P1' ? 'require' : 'warrant'}{urgentPlural ? '' : 's'} intervention even though the overall score ({d.health_score}) sits in the {d.risk_level} band.
                  </p>
                )}
              </div>
              <div className="grid grid-cols-3 gap-3 text-sm">
                <div><div className="text-xs text-steel-500">Primary risk</div><div className="font-semibold text-ink">{d.primary_risk}</div></div>
                <div><div className="text-xs text-steel-500">Capital at risk</div><div className="font-semibold text-ink">₹{d.capital_at_risk_cr} Cr</div><div className="text-[11px] text-steel-500">₹{d.excess_stock_cr} Cr excess stock + ₹{d.overdue_cr} Cr overdue</div></div>
                <div><div className="text-xs text-steel-500">Network average</div><div className="font-semibold text-ink">{networkAvg}/100</div></div>
              </div>
              <div id="detail-flags" className="flex flex-wrap gap-1.5">
                {(Object.keys(f) as (keyof typeof f)[]).map((k) => <SeverityChip key={k} label={FLAG_LABEL[k]} severity={f[k].severity} />)}
              </div>
            </div>
          </section>

          {/* What changed — only when the data has previous-period values */}
          <WhatChanged d={d} />

          {/* Why flagged */}
          <section id="detail-why" className="rounded-lg border border-steel-200 bg-white p-5">
            <h3 className="text-[15px] font-semibold text-ink">WHY IS {d.dealer_name.toUpperCase()} {d.priority === 'P3' && d.severe_count === 0 && d.moderate_count === 0 ? 'NOT FLAGGED' : 'FLAGGED'}?</h3>
            <ul className="mt-3 space-y-2">
              {d.why_flagged.map((w, i) => (
                <li key={i} className="flex gap-3 text-sm leading-relaxed text-ink">
                  <span className="mt-2 h-1.5 w-1.5 flex-none rounded-full bg-steel-400" />
                  {w}
                </li>
              ))}
            </ul>
          </section>

          {diag && <RootCause diag={diag} nameOf={nameOf} onOpen={onOpen} onGoData={onGoData} />}

          {/* Interpretation */}
          <section id="detail-interpretation" className="rounded-lg border-l-4 border-info bg-white p-5">
            <h3 className="text-xs font-semibold tracking-wide text-info">MANAGEMENT INTERPRETATION</h3>
            <p className="mt-2 text-[15px] leading-relaxed text-ink">{d.interpretation}</p>
          </section>

          {/* Actions */}
          <section id="detail-actions" className="rounded-lg border-2 border-cab bg-white">
            <div className="bg-cab px-5 py-3 text-white">
              <h3 className="text-xs font-semibold tracking-wide text-steel-200">RECOMMENDED MANAGEMENT ACTION</h3>
              <p className="mt-1 text-base font-semibold">{d.headline_action}</p>
            </div>
            <ol className="divide-y divide-steel-100">
              {d.actions.map((a, i) => (
                <li key={a.title} className="grid grid-cols-[2rem_1fr_auto] gap-3 px-5 py-3">
                  <span className="font-cond text-lg font-semibold text-steel-400 tnum">{i + 1}.</span>
                  <div>
                    <div className="font-semibold text-ink">{a.title}</div>
                    <div className="text-[13px] leading-snug text-steel-700">{a.detail}</div>
                  </div>
                  <div className="text-right text-xs">
                    <div className="font-medium text-ink">{a.due}</div>
                    <div className="text-steel-500">{a.owner}</div>
                  </div>
                </li>
              ))}
            </ol>
            {diag && diag.matchedActions.length > 0 && (
              <div className="border-t-2 border-steel-100 bg-steel-50 px-5 py-3" data-testid="matched-actions">
                <div className="text-xs font-semibold text-steel-500">Matched to the likely cause — validate the hypothesis first</div>
                <ul className="mt-2 space-y-1.5">
                  {diag.matchedActions.map((m) => (
                    <li key={m.title} className="text-[13px]">
                      <span className="font-medium text-ink">{m.title}</span> <ConfidenceChip c={m.confidence} />
                      <span className="block text-steel-700">{m.action}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </section>

          {/* Detailed metrics (moved below the decision flow) */}
          <h3 className="pt-2 text-sm font-semibold text-steel-500">Detailed metrics and score breakdown</h3>
          {/* Metric cards */}
          <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <MetricCard label="Sales achievement" value={`${d.sales_achievement_pct}%`} severity={d.sales_achievement_pct < THRESHOLDS.sales.severeAch ? 'severe' : d.sales_achievement_pct < THRESHOLDS.sales.moderateAch ? 'moderate' : 'none'} note={`₹${d.actual_sales} Cr of ₹${d.sales_target} Cr target`} />
            <MetricCard label="Sales growth" value={signed(d.sales_growth_pct)} severity={d.sales_growth_pct <= THRESHOLDS.sales.severeGrowth ? 'severe' : d.sales_growth_pct < THRESHOLDS.sales.moderateGrowth ? 'moderate' : 'none'} note={`vs ₹${d.previous_year_sales} Cr last year`} />
            <MetricCard label="Inventory age" value={`${d.inventory_age_days} d`} severity={f.inventory_risk.severity} note={sevNote(f.inventory_risk.severity, `${d.inventory_units} units, ${d.stock_cover_months} mo cover`, `Watch above ${THRESHOLDS.inventory.moderate} days`, `Above ${THRESHOLDS.inventory.severe}-day limit · ${d.inventory_units} units`)} />
            <MetricCard label="Payment delay" value={`${d.payment_delay_days} d`} severity={f.payment_risk.severity} note={sevNote(f.payment_risk.severity, 'Within credit terms', `Watch from ${THRESHOLDS.payment.moderate} days`, `Severe from ${THRESHOLDS.payment.severe} days · ₹${d.overdue_cr} Cr overdue`)} />
            <MetricCard label="Service performance" value={`${d.service_performance}`} severity={f.service_risk.severity} note={sevNote(f.service_risk.severity, 'Index 0–100, above watch line', `Below watch line of ${THRESHOLDS.service.moderate}`, `Below severe line of ${THRESHOLDS.service.severe}`)} />
            <MetricCard label="Complaints / 100 vehicles" value={`${d.complaints_per_100}`} severity={f.customer_risk.severity} note={`${d.customer_complaints} complaints on ${d.vehicles_sold} vehicles`} />
            <MetricCard label="Market potential" value={`${d.market_potential}`} severity="none" info={f.market_opportunity.severity !== 'none'} note={f.market_opportunity.severity !== 'none' ? `Demand available · market +${d.market_growth}%` : `Index 0–100 · market +${d.market_growth}%`} />
            <MetricCard label="Vehicles sold" value={`${d.vehicles_sold}`} severity="none" note={`${Math.round(d.vehicles_sold / 12)} per month retail run-rate`} />
          </section>

          {/* Score breakdown */}
          <section id="detail-breakdown" className="rounded-lg border border-steel-200 bg-white p-5">
            <div className="flex flex-wrap items-end justify-between gap-2">
              <div>
                <h3 className="text-[15px] font-semibold text-ink">Score breakdown</h3>
                <p className="text-[13px] text-steel-500">How the {d.health_score} points were earned. Each metric earns up to its weight.</p>
              </div>
              {biggestGaps.length > 0 && (
                <p className="text-[13px] text-steel-700">Most points lost: {biggestGaps.map((c) => `${c.label} (−${c.lost})`).join(', ')}</p>
              )}
            </div>
            <table className="mt-4 w-full text-sm">
              <tbody>
                {d.components.map((c) => {
                  const pct = c.normalized;
                  const col = pct >= 0.66 ? '#1D8556' : pct >= 0.4 ? '#B87A0A' : '#C2362B';
                  const shown = c.key === 'complaints' ? `${c.value}/100` : `${c.key === 'growth' && c.value > 0 ? '+' : ''}${c.value}${c.unit}`;
                  return (
                    <tr key={c.key} className="border-b border-steel-100 last:border-0">
                      <td className="w-[34%] py-2 pr-3 align-top">
                        <div className="font-medium text-ink">{c.label} <span className="font-normal text-steel-400">— {c.weight}%</span></div>
                        <div className="text-[11px] text-steel-500">{c.plain}</div>
                      </td>
                      <td className="w-[16%] py-2 pr-3 text-right align-top text-steel-700 tnum">{shown}</td>
                      <td className="py-2 pr-3 align-middle">
                        <div className="relative h-3 rounded-sm bg-steel-100" style={{ width: `${(c.weight / 25) * 100}%` }}>
                          <div className="absolute inset-y-0 left-0 rounded-sm" style={{ width: `${pct * 100}%`, background: col }} />
                        </div>
                      </td>
                      <td className="w-[14%] py-2 text-right align-middle font-cond text-base tnum">
                        <span className="font-semibold text-ink">{c.points.toFixed(1)}</span><span className="text-steel-400"> / {c.weight}</span>
                      </td>
                    </tr>
                  );
                })}
                <tr className="border-t-2 border-steel-200">
                  <td className="pt-3 font-semibold text-ink" colSpan={3}>Total health score</td>
                  <td className="pt-3 text-right font-cond text-xl font-semibold tnum" style={{ color: RISK_COLOR[d.risk_level] }}>{d.health_score} / 100</td>
                </tr>
              </tbody>
            </table>
            <p className="mt-2 text-[11px] text-steel-500">Bar length reflects each metric's weight; the filled share is the points earned. Component points are shown to one decimal and the total is rounded.</p>
          </section>

          <p className="pb-4 text-center text-xs text-steel-400">{dataLabel}</p>
        </div>
      </div>
    </div>
  );
}
