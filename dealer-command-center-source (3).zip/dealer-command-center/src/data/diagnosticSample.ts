import type { Dealer } from './dealers';
import { DEALERS } from './dealers';

// SYNTHETIC DIAGNOSTIC SAMPLE — illustrative only.
//
// The default synthetic dataset deliberately has NO optional diagnostic fields, so the
// app demonstrates what it can (and cannot) conclude from core data alone. This sample
// is a separate, opt-in file: the same 50 dealers with designed diagnostic fields added,
// to show what deeper data unlocks. It goes through the normal import validation.
//
// Designed patterns (everything else is set to normal, low-variation values):
//   • Central region: transport/handling problem — high damage, transport complaints and
//     delivery delays at 6 of 8 dealers, while the same product lines are fine elsewhere.
//   • EV product line: elevated product complaints at 7 dealers across 4 regions.
//   • D013, D021, D041: plenty of leads, weak conversion, weak sales-team index.
//   • D017, D024, D030, D050: competitors gaining share with cheaper prices / promotions.
//   • D003, D008, D010, D026: ageing stock with elevated product-condition complaints;
//     D031 has ageing stock but normal product complaints (storage hypothesis rejected).
//   • Previous-period values: most dealers roughly stable; D018, D029, D032, D044 (designed
//     "early warning" dealers) deteriorate — so "What changed?" has real (synthetic) data.
//   • D015: high complaints with normal stock age, damage and product complaints but slow
//     complaint resolution — points to dealer customer service.

const EV = new Set(['D006', 'D019', 'D023', 'D033', 'D038', 'D044', 'D047']);
const CENTRAL_TRANSPORT = new Set(['D012', 'D014', 'D018', 'D027', 'D035', 'D040']);
const EXECUTION = new Set(['D013', 'D021', 'D041']);
const COMPETITION: Record<string, [number, number, number]> = { D017: [4.6, 91, 128], D030: [3.9, 93, 121], D050: [3.1, 94, 116], D024: [2.4, 96, 112] };
const STORAGE: Record<string, number> = { D003: 2.2, D008: 2.6, D010: 1.9, D026: 2.0 };
const SLOW_RESOLUTION: Record<string, number> = { D015: 9.2, D047: 7.1, D014: 8.0, D017: 7.5, D030: 6.8, D024: 6.2, D050: 6.5 };
const CATS = ['Hatchback', 'Sedan', 'SUV'];
// Previous-period deltas for the early-warning dealers: [inventory age, payment delay, complaints/100, service]
const DETERIORATING: Record<string, [number, number, number, number]> = {
  D044: [-19, -10, -1.6, 6], D018: [-16, -8, -1.3, 4], D029: [-17, -11, -1.4, 5], D032: [-12, -9, -1.5, 7],
};

// Small deterministic spread so "normal" values aren't identical
const spread = (i: number, lo: number, hi: number, dp = 1) => {
  const f = ((i * 37) % 11) / 10;
  const m = 10 ** dp;
  return Math.round((lo + f * (hi - lo)) * m) / m;
};

function prevPeriod(d: Dealer, i: number) {
  const cur = Math.round((d.customer_complaints / d.vehicles_sold) * 1000) / 10;
  const dd = DETERIORATING[d.dealer_id];
  const wobble = spread(i, -3, 3, 0);
  return {
    prev_inventory_age_days: Math.max(20, d.inventory_age_days + (dd ? dd[0] : wobble)),
    prev_payment_delay_days: Math.max(0, d.payment_delay_days + (dd ? dd[1] : Math.round(wobble / 2))),
    prev_complaints_per_100: Math.max(0.5, Math.round((cur + (dd ? dd[2] : wobble / 10)) * 10) / 10),
    prev_service_performance: Math.min(100, d.service_performance + (dd ? dd[3] : -Math.round(wobble / 2))),
  };
}

export function buildDiagnosticSample(): Dealer[] {
  return DEALERS.map((d, i) => {
    const id = d.dealer_id;
    const transport = CENTRAL_TRANSPORT.has(id);
    const conv = EXECUTION.has(id) ? spread(i, 9.5, 11.5) : spread(i, 18, 24);
    const comp = COMPETITION[id];
    const productRate = EV.has(id) ? spread(i, 2.6, 3.4) : STORAGE[id] ?? (transport ? spread(i, 1.3, 1.6) : spread(i, 0.6, 1.3));
    const { archetype, ...core } = d;
    void archetype;
    return {
      ...core,
      product_category: EV.has(id) ? 'EV' : CATS[i % 3],
      product_complaint_rate: productRate,
      product_damage_rate: transport ? spread(i, 2.8, 4.0) : spread(i, 0.5, 1.2),
      transport_complaint_rate: transport ? spread(i, 1.6, 2.4) : spread(i, 0.3, 0.7),
      delivery_delay_days: transport ? spread(i, 6, 9, 0) : spread(i, 1, 3, 0),
      storage_age_days: d.inventory_age_days + 4,
      lead_volume: Math.round(d.vehicles_sold / (conv / 100)),
      conversion_rate: conv,
      competitor_price_index: comp ? comp[1] : spread(i, 98, 103, 0),
      competitor_market_share: spread(i, 22, 32, 0),
      competitor_share_change: comp ? comp[0] : spread(i, -1, 1),
      competitor_promotion_index: comp ? comp[2] : spread(i, 95, 108, 0),
      sales_rep_performance: EXECUTION.has(id) ? spread(i, 55, 61, 0) : spread(i, 72, 86, 0),
      service_resolution_days: SLOW_RESOLUTION[id] ?? spread(i, 2.5, 4.5),
      ...prevPeriod(d, i),
    };
  });
}

export const DIAGNOSTIC_SAMPLE_NAME = 'synthetic-diagnostic-sample.csv';
