import { describe, it, expect } from 'vitest';
import { DEALERS } from './dealers';
import { analyzeTable, normalizeHeader, parseNumber, toCsv } from './importDealers';
import { scoreAll } from '../model/scoring';

const csvTable = (csv: string) => csv.split('\n').map((l) => l.split(','));
const fullTable = csvTable(toCsv(DEALERS));

describe('header + value parsing', () => {
  it('normalises friendly headers', () => {
    expect(normalizeHeader('Inventory Ageing (days)')).toBe('inventory_ageing');
    expect(normalizeHeader('Sales Growth %')).toBe('sales_growth_pct');
    expect(normalizeHeader(' Dealer ID ')).toBe('dealer_id');
  });
  it('parses numbers with currency, commas and percent', () => {
    expect(parseNumber('₹1,250.5')).toBe(1250.5);
    expect(parseNumber('12%')).toBe(12);
    expect(parseNumber('')).toBeNull();
    expect(parseNumber('abc')).toBeNaN();
  });
});

describe('round trip', () => {
  it('re-importing the synthetic CSV reproduces identical scores', () => {
    const r = analyzeTable(fullTable, 'x.csv');
    expect(r.canImport).toBe(true);
    expect(r.validCount).toBe(50);
    const a = scoreAll(DEALERS), b = scoreAll(r.dealers);
    a.forEach((d, i) => {
      expect(b[i].health_score).toBe(d.health_score);
      expect(b[i].priority).toBe(d.priority);
      expect(b[i].attention_index).toBe(d.attention_index);
    });
  });
});

describe('validation blocks bad data', () => {
  it('reports missing columns and imports nothing', () => {
    const t = fullTable.map((r) => r.filter((_, i) => i !== 9)); // drop payment_delay_days
    const r = analyzeTable(t, 'x.csv');
    expect(r.canImport).toBe(false);
    expect(r.missingColumns.map((f) => f.key)).toEqual(['payment_delay_days']);
    expect(r.dealers).toHaveLength(0);
  });
  it('flags missing, non-numeric, negative, out-of-range and duplicate values', () => {
    const t = fullTable.map((r) => [...r]);
    t[1][9] = '';        // missing payment delay
    t[2][8] = 'n/a?';    // non-numeric inventory age
    t[3][9] = '-4';      // negative payment delay
    t[4][10] = '140';    // service > 100
    t[5][0] = t[6][0];   // duplicate id
    const r = analyzeTable(t, 'x.csv');
    expect(r.canImport).toBe(false);
    expect(r.invalidCount).toBe(5);
    expect(r.validCount).toBe(45);
    const s = r.summary.map((x) => x.text).join(' | ');
    expect(s).toMatch(/missing payment delay/);
    expect(s).toMatch(/non-numeric inventory age/);
    expect(s).toMatch(/Dealer ID already used/);
  });
  it('accepts friendly headers and sales growth % instead of previous year sales', () => {
    const header = ['Dealer ID','Dealer Name','Region','City','Sales Target (₹ Cr)','Actual Sales','Sales Growth %','Inventory Units','Inventory Ageing (days)','Payment Delay (days)','Service Score','Complaints','Vehicles Sold','Market Potential','Market Growth'];
    const r = analyzeTable([header, ['X1','Test Motors','West','Pune','100','95','10%','200','40','5','88','20','1000','70','6']], 'x.csv');
    expect(r.canImport).toBe(true);
    expect(r.growthFromPct).toBe(true);
    const d = scoreAll(r.dealers)[0];
    expect(d.sales_growth_pct).toBeCloseTo(10, 0);
    expect(d.sales_achievement_pct).toBe(95);
  });
  it('rejects an empty file', () => {
    expect(analyzeTable([], 'x.csv').canImport).toBe(false);
  });
});

import { buildTemplateCsv, OPTIONAL_FIELDS, FIELDS } from './importDealers';
const parseCsv = (csv: string) => csv.split('\n').map((l) => { const out: string[] = []; let cur = '', q = false; for (const ch of l) { if (ch === '"') q = !q; else if (ch === ',' && !q) { out.push(cur); cur = ''; } else cur += ch; } out.push(cur); return out; });

describe('data template', () => {
  const t = parseCsv(buildTemplateCsv());
  it('uses the exact internal field names, core then optional, every row the same width', () => {
    expect(t[0]).toEqual([...FIELDS, ...OPTIONAL_FIELDS].map((f) => f.key));
    for (const r of t) expect(r).toHaveLength(t[0].length);
  });
  it('round-trips as-is: all columns recognised, guidance skipped, example rows import WITH a warning', () => {
    const r = analyzeTable(t, 'dealer-data-template.csv');
    expect(r.missingColumns).toEqual([]);
    expect(r.ignoredColumns).toEqual([]);
    expect(r.optionalFound).toHaveLength(OPTIONAL_FIELDS.length);
    expect(r.skippedRows).toBe(2); // field-type + unit/rule guidance rows
    expect(r.canImport).toBe(true);
    expect(r.dealers.map((d) => d.dealer_id)).toEqual(['EXAMPLE-01', 'EXAMPLE-02', 'EXAMPLE-03']);
    expect(r.dealers.every((d) => /synthetic example/.test(d.dealer_name))).toBe(true);
    expect(r.summary.some((x) => x.tone === 'warning' && /template example rows \(synthetic\)/.test(x.text))).toBe(true);
  });
  it('per-row growth fallback, blank optional fields stay blank, previous-period values kept', () => {
    const r = analyzeTable(t, 'x.csv');
    expect(r.dealers[1].previous_year_sales).toBeCloseTo(48 / 0.92, 0); // from sales_growth_pct = -8
    expect(r.dealers[0].product_category).toBe('SUV');
    expect(r.dealers[1].product_category).toBeUndefined();
    expect(r.dealers[2].conversion_rate).toBeUndefined();
    expect(r.dealers[2].service_resolution_days).toBe(3);
    expect(r.dealers[0].prev_inventory_age_days).toBe(44);
  });
  it('a user-filled template (real IDs) imports without example warnings', () => {
    const filled = t.map((r, i) => (i >= 3 ? [r[0].replace('EXAMPLE', 'DLR'), r[1].replace(' (synthetic example)', ''), ...r.slice(2)] : r));
    const r = analyzeTable(filled, 'filled.csv');
    expect(r.canImport).toBe(true);
    expect(r.warningCount).toBe(0);
});
});

describe('malformed and invalid files', () => {
  const header = toCsv(DEALERS.slice(0, 3)).split('\n');
  it('semicolon- or tab-separated files: header not recognised, blocked with a useful message', () => {
    for (const sep of [';', '\t']) {
      const r = analyzeTable(header.map((l) => [l.split(',').join(sep)]), 'x.csv');
      expect(r.canImport).toBe(false);
      expect(r.summary[0].text).toMatch(/header row was not recognised/);
    }
  });
  it('garbage content is blocked', () => {
    const r = analyzeTable([['%PDF-1.4 ÿØÿà'], ['xx', 'yy']], 'x.csv');
    expect(r.canImport).toBe(false);
    expect(r.dealers).toHaveLength(0);
  });
  it('ragged (short) rows are reported as missing values, not filled in', () => {
    const t = header.map((l) => l.split(','));
    t[2] = t[2].slice(0, 9);
    const r = analyzeTable(t, 'x.csv');
    expect(r.canImport).toBe(false);
    expect(r.summary.map((x) => x.text).join(' ')).toMatch(/missing payment delay/);
  });
  it('invalid percentages are rejected', () => {
    const t = header.map((l) => l.split(','));
    const growthCol = t[0].length; t[0].push('sales_growth_pct'); t[1].push('-150'); t[2].push(''); t[3].push('');
    t[1][6] = ''; // previous_year_sales blank → growth % is used, and -150% is impossible
    void growthCol;
    const r = analyzeTable(t, 'x.csv');
    expect(r.canImport).toBe(false);
    expect(r.summary.map((x) => x.text).join(' ')).toMatch(/Sales growth % out of range/i);
  });
});
