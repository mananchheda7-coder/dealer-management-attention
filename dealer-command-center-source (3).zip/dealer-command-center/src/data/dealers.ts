// SYNTHETIC DATA — illustrative only. Not real manufacturer or dealer data.
//
// Rows are NOT random. Each dealer is designed from a business archetype so the
// dataset demonstrates that sales alone do not reveal dealer health. The archetype
// label is kept for documentation/testing only — the scoring model never reads it.

// Regions in the synthetic set. Imported data may use any region name.
export type SyntheticRegion = 'West' | 'North' | 'South' | 'East' | 'Central';
export type Region = string;

export interface Dealer {
  dealer_id: string;
  dealer_name: string;
  region: Region;
  city: string;
  sales_target: number;        // ₹ crore, annual
  actual_sales: number;        // ₹ crore, annual
  previous_year_sales: number; // ₹ crore
  inventory_units: number;     // vehicles in stock
  inventory_age_days: number;  // average age of stock
  payment_delay_days: number;  // avg days beyond credit terms
  service_performance: number; // 0–100 service KPI index (CSI, turnaround, first-time-fix)
  customer_complaints: number; // count, trailing 12 months
  vehicles_sold: number;       // units, trailing 12 months
  market_potential: number;    // 0–100 index of local addressable demand
  market_growth: number;       // % YoY growth of local market
  archetype?: string; // design label for synthetic rows only; never used by the model

  // ── Optional diagnostic fields. Never present in the default synthetic set and never
  //    filled in by the app: they only exist when an imported file supplies them.
  product_category?: string;          // dealer's dominant product line, e.g. SUV, EV
  product_complaint_rate?: number;    // product-related complaints per 100 vehicles
  product_damage_rate?: number;       // % of deliveries arriving damaged
  transport_complaint_rate?: number;  // transport-related complaints per 100 vehicles
  delivery_delay_days?: number;       // avg days late vs promised delivery
  storage_age_days?: number;          // avg days a unit spent in storage before delivery
  lead_volume?: number;               // enquiries / leads, trailing 12 months
  conversion_rate?: number;           // % of leads converted to sales
  competitor_price_index?: number;    // competitor price vs ours, 100 = parity, <100 = competitor cheaper
  competitor_market_share?: number;   // % of local market
  competitor_share_change?: number;   // change in competitor share, percentage points YoY
  competitor_promotion_index?: number;// competitor promotion intensity, 100 = parity
  sales_rep_performance?: number;     // 0–100 sales-team capability index
  service_resolution_days?: number;   // avg days to resolve a complaint

  // ── Optional previous-period values. Only used for "What changed?" when a file supplies them;
  //    never estimated. The default synthetic data is a single snapshot and has none.
  prev_inventory_age_days?: number;
  prev_payment_delay_days?: number;
  prev_complaints_per_100?: number;
  prev_service_performance?: number;
}

export const DIAGNOSTIC_KEYS = [
  'product_category', 'product_complaint_rate', 'product_damage_rate', 'transport_complaint_rate', 'delivery_delay_days',
  'storage_age_days', 'lead_volume', 'conversion_rate', 'competitor_price_index', 'competitor_market_share',
  'competitor_share_change', 'competitor_promotion_index', 'sales_rep_performance', 'service_resolution_days',
] as const;
export type DiagnosticKey = (typeof DIAGNOSTIC_KEYS)[number];

export const HISTORY_KEYS = ['prev_inventory_age_days', 'prev_payment_delay_days', 'prev_complaints_per_100', 'prev_service_performance'] as const;
export type HistoryKey = (typeof HISTORY_KEYS)[number];

// Designed inputs: [id, name, region, city, target ₹Cr, achievement %, growth %,
//   avg ticket ₹ lakh, stock cover (months), inventory age, payment delay,
//   service index, complaints per 100, market potential, market growth %, archetype]
type Spec = [string, string, SyntheticRegion, string, number, number, number, number, number, number, number, number, number, number, number, string];

const SPECS: Spec[] = [
  ['D001', 'Sahyadri Motors', 'West', 'Pune', 120, 108, 14, 9.5, 1.1, 32, 2, 92, 1.4, 86, 9, 'Healthy high performer'],
  ['D002', 'Capital Wheels', 'North', 'Delhi', 160, 104, 12, 10.5, 1.2, 35, 3, 90, 1.8, 90, 10, 'Healthy high performer'],
  ['D003', 'Premier Drive', 'West', 'Mumbai', 150, 95, 9, 11, 2.6, 78, 28, 76, 3.6, 82, 8, 'High sales + inventory and payment risk'],
  ['D004', 'Deccan Auto Hub', 'South', 'Hyderabad', 110, 101, 11, 9, 1.0, 34, 4, 91, 1.6, 84, 11, 'Healthy high performer'],
  ['D005', 'Coromandel Cars', 'South', 'Chennai', 100, 93, 6, 9.5, 1.3, 41, 5, 86, 2.2, 66, 6, 'Healthy moderate performer'],
  ['D006', 'Ganga Motors', 'North', 'Lucknow', 70, 91, 4, 7.5, 1.4, 44, 6, 84, 2.5, 60, 5, 'Healthy moderate performer'],
  ['D007', 'Gateway Autos', 'West', 'Ahmedabad', 95, 99, 8, 8.5, 1.2, 38, 3, 88, 1.9, 72, 7, 'Healthy high performer'],
  ['D008', 'Metro Flagship Motors', 'West', 'Mumbai', 180, 94, 7, 12, 2.4, 72, 24, 74, 4.8, 88, 9, 'Strong sales + hidden operational risk'],
  ['D009', 'Riverbend Auto', 'East', 'Kolkata', 85, 82, 8, 8.5, 1.1, 33, 3, 91, 1.5, 70, 6, 'Moderate sales + healthy operations'],
  ['D010', 'Silk City Motors', 'West', 'Surat', 90, 103, 10, 9, 2.8, 81, 9, 85, 2.4, 78, 8, 'High sales + high inventory risk'],
  ['D011', 'Pink City Autos', 'North', 'Jaipur', 80, 97, 6, 8.5, 1.3, 42, 33, 83, 2.6, 68, 6, 'High sales + payment delay risk'],
  ['D012', 'Malwa Motors', 'Central', 'Indore', 65, 74, -14, 8, 1.6, 52, 8, 80, 2.9, 62, 4, 'Declining sales'],
  ['D013', 'Garden City Motors', 'South', 'Bengaluru', 140, 71, -11, 11, 1.9, 58, 10, 79, 3.2, 92, 12, 'Declining sales + high market potential'],
  ['D014', 'Orange City Autos', 'Central', 'Nagpur', 60, 86, 2, 8, 1.3, 46, 7, 63, 5.9, 58, 5, 'Poor service'],
  ['D015', 'Hooghly Wheels', 'East', 'Kolkata', 75, 89, 3, 8, 1.2, 43, 6, 71, 7.4, 64, 5, 'High complaint rate'],
  ['D016', 'Bodhi Motors', 'East', 'Patna', 40, 76, 1, 7, 1.4, 47, 8, 80, 3.0, 32, 2, 'Low sales + low market potential'],
  ['D017', 'Ring Road Motors', 'North', 'Delhi', 130, 66, -15, 10, 2.9, 84, 31, 62, 6.8, 85, 9, 'Multiple simultaneous risks'],
  ['D018', 'Lakeview Autos', 'Central', 'Bhopal', 70, 92, 1, 8, 1.6, 57, 13, 80, 3.4, 65, 6, 'Early warning'],
  ['D019', 'Nizam Auto Plaza', 'South', 'Hyderabad', 125, 102, 12, 10, 1.5, 49, 11, 66, 5.4, 80, 10, 'Strong sales + hidden operational risk'],
  ['D020', 'Sabarmati Motors', 'West', 'Ahmedabad', 100, 98, 7, 9, 1.4, 45, 29, 86, 2.3, 70, 7, 'Good sales + poor financial discipline'],
  ['D021', 'Tech Park Motors', 'South', 'Bengaluru', 120, 76, -6, 11, 1.7, 55, 12, 74, 4.4, 94, 13, 'Strong market + weak dealer execution'],
  ['D022', 'Tricity Motors', 'North', 'Chandigarh', 85, 106, 13, 10, 1.1, 31, 2, 93, 1.3, 78, 8, 'Healthy high performer'],
  ['D023', 'Nashik Valley Motors', 'West', 'Nashik', 60, 94, 5, 8, 1.3, 40, 4, 87, 2.0, 62, 6, 'Healthy moderate performer'],
  ['D024', 'Marina Motors', 'South', 'Chennai', 110, 69, -13, 9.5, 2.5, 74, 27, 70, 5.6, 76, 7, 'Multiple simultaneous risks'],
  ['D025', 'Kaveri Autos', 'South', 'Mysuru', 50, 90, 4, 8, 1.3, 44, 6, 85, 2.4, 52, 4, 'Healthy moderate performer'],
  ['D026', 'Amber Fort Autos', 'North', 'Jaipur', 70, 72, -9, 8, 1.8, 61, 17, 77, 3.8, 66, 5, 'Declining sales + rising inventory'],
  ['D027', 'Narmada Motors', 'Central', 'Jabalpur', 45, 79, -3, 7.5, 1.4, 50, 8, 81, 3.1, 40, 3, 'Low sales + low market potential'],
  ['D028', 'Konkan Wheels', 'West', 'Thane', 95, 100, 10, 10, 1.2, 37, 5, 89, 1.9, 80, 9, 'Healthy high performer'],
  ['D029', 'Eastern Star Motors', 'East', 'Bhubaneswar', 55, 84, 2, 7.5, 1.6, 58, 18, 79, 3.6, 58, 6, 'Early warning'],
  ['D030', 'Charminar Cars', 'South', 'Hyderabad', 80, 63, -18, 8.5, 2.6, 79, 34, 64, 7.1, 74, 8, 'Multiple simultaneous risks'],
  ['D031', 'Indus Motors', 'North', 'Gurugram', 145, 105, 15, 12.5, 2.3, 74, 7, 87, 2.1, 89, 11, 'High sales + high inventory risk'],
  ['D032', 'Gomti Autos', 'North', 'Lucknow', 60, 80, -7, 7.5, 1.5, 51, 14, 76, 4.2, 70, 7, 'Early warning'],
  ['D033', 'Brahmaputra Motors', 'East', 'Guwahati', 45, 88, 6, 8, 1.2, 42, 5, 86, 2.2, 55, 7, 'Healthy moderate performer'],
  ['D034', 'Holkar Motors', 'Central', 'Indore', 75, 96, 9, 8.5, 1.2, 39, 4, 89, 1.8, 74, 8, 'Healthy high performer'],
  ['D035', 'Vidarbha Motors', 'Central', 'Nagpur', 55, 77, -8, 7.5, 1.7, 57, 22, 73, 4.6, 63, 5, 'Multiple simultaneous risks'],
  ['D036', 'Coastal Cars', 'South', 'Kochi', 70, 97, 7, 9.5, 1.2, 40, 4, 90, 1.7, 68, 6, 'Healthy high performer'],
  ['D037', 'Salt Lake Motors', 'East', 'Kolkata', 90, 99, 5, 9, 1.5, 47, 26, 81, 3.0, 75, 7, 'Good sales + poor financial discipline'],
  ['D038', 'Rajpath Autos', 'North', 'Delhi', 110, 85, -2, 10, 1.6, 53, 9, 66, 6.3, 84, 9, 'Strong market + weak dealer execution'],
  ['D039', 'Tapi Motors', 'West', 'Surat', 65, 92, 6, 8.5, 1.3, 42, 6, 84, 2.6, 64, 7, 'Healthy moderate performer'],
  ['D040', 'Pragati Motors', 'Central', 'Raipur', 40, 70, -5, 7, 1.5, 52, 11, 77, 3.5, 35, 3, 'Low sales + low market potential'],
  ['D041', 'Phoenix Motors', 'West', 'Pune', 105, 73, -12, 10, 2.2, 66, 19, 75, 4.1, 87, 10, 'Declining sales + high market potential'],
  ['D042', 'Ranchi Auto Point', 'East', 'Ranchi', 50, 65, -10, 7.5, 2.1, 63, 24, 71, 5.4, 45, 4, 'Multiple simultaneous risks'],
  ['D043', 'Golden Temple Motors', 'North', 'Amritsar', 55, 101, 9, 8.5, 1.1, 36, 3, 91, 1.6, 66, 7, 'Healthy high performer'],
  ['D044', 'Electronic City Autos', 'South', 'Bengaluru', 95, 95, 6, 10.5, 1.5, 56, 16, 82, 3.9, 86, 11, 'Early warning'],
  ['D045', 'Mahakal Motors', 'Central', 'Ujjain', 35, 89, 3, 7, 1.3, 45, 7, 83, 2.7, 48, 4, 'Healthy moderate performer'],
  ['D046', 'Western Express Motors', 'West', 'Mumbai', 135, 110, 16, 11.5, 1.0, 33, 2, 94, 1.2, 91, 10, 'Healthy high performer'],
  ['D047', 'Vizag Motors', 'South', 'Visakhapatnam', 60, 84, 1, 8, 1.4, 48, 12, 64, 5.1, 62, 6, 'Poor service'],
  ['D048', 'Doon Valley Autos', 'North', 'Dehradun', 45, 84, -2, 8, 1.6, 56, 15, 80, 3.3, 50, 5, 'Early warning'],
  ['D049', 'Himalayan Gateway Motors', 'East', 'Siliguri', 40, 93, 7, 7.5, 1.2, 41, 5, 86, 2.3, 56, 6, 'Healthy moderate performer'],
  ['D050', 'Panchganga Motors', 'West', 'Kolhapur', 50, 61, -16, 7.5, 2.4, 76, 29, 69, 6.0, 57, 4, 'Multiple simultaneous risks'],
];

const r1 = (n: number) => Math.round(n * 10) / 10;

// Convert designed specs into raw operational fields — the shape a manufacturer's DMS would export.
export const DEALERS: Dealer[] = SPECS.map(
  ([id, name, region, city, target, ach, growth, ticket, cover, age, delay, service, compRate, mkt, mktGrowth, archetype]) => {
    const actual = r1((target * ach) / 100);
    const prev = r1(actual / (1 + growth / 100));
    const sold = Math.round((actual * 100) / ticket); // ₹Cr → ₹lakh ÷ avg ticket
    return {
      dealer_id: id,
      dealer_name: name,
      region,
      city,
      sales_target: target,
      actual_sales: actual,
      previous_year_sales: prev,
      inventory_units: Math.round((sold / 12) * cover),
      inventory_age_days: age,
      payment_delay_days: delay,
      service_performance: service,
      customer_complaints: Math.round((compRate * sold) / 100),
      vehicles_sold: sold,
      market_potential: mkt,
      market_growth: mktGrowth,
      archetype,
    };
  },
);
