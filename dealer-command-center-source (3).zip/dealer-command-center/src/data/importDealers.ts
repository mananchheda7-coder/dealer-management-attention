import type { Dealer, DiagnosticKey, HistoryKey } from './dealers';
import { DIAGNOSTIC_KEYS, HISTORY_KEYS } from './dealers';

// ───────────────────────────── Import schema ─────────────────────────────
// Uses the existing Dealer field names exactly. Header matching is forgiving
// (case, spaces, units in brackets and common synonyms), values are never invented.

type Kind = 'text' | 'number';

export interface FieldSpec {
  key: keyof Dealer | 'sales_growth_pct';
  label: string;
  kind: Kind;
  unit: string;
  rule: string;
  min?: number;
  max?: number;
  minExclusive?: boolean;
  optional?: boolean; // diagnostic / history fields: may be absent or blank
  group?: 'diagnostic' | 'history';
  aliases: string[];
}

export const FIELDS: FieldSpec[] = [
  { key: 'dealer_id', label: 'Dealer ID', kind: 'text', unit: '', rule: 'Unique per row', aliases: ['id', 'dealer_code', 'code', 'dealerid'] },
  { key: 'dealer_name', label: 'Dealer name', kind: 'text', unit: '', rule: 'Required', aliases: ['name', 'dealer', 'dealership', 'dealer_name'] },
  { key: 'region', label: 'Region', kind: 'text', unit: '', rule: 'Required', aliases: ['zone', 'sales_region'] },
  { key: 'city', label: 'City', kind: 'text', unit: '', rule: 'Required', aliases: ['location', 'town'] },
  { key: 'sales_target', label: 'Sales target', kind: 'number', unit: '₹ Cr', rule: 'Greater than 0', min: 0, minExclusive: true, aliases: ['target', 'annual_target', 'sales_target_cr'] },
  { key: 'actual_sales', label: 'Actual sales', kind: 'number', unit: '₹ Cr', rule: '0 or more', min: 0, aliases: ['sales', 'actual', 'sales_actual', 'actual_sales_cr', 'revenue'] },
  { key: 'previous_year_sales', label: 'Previous year sales', kind: 'number', unit: '₹ Cr', rule: 'Greater than 0 (or give sales growth %)', min: 0, minExclusive: true, aliases: ['py_sales', 'last_year_sales', 'prior_year_sales', 'previous_sales', 'ly_sales'] },
  { key: 'sales_growth_pct', label: 'Sales growth %', kind: 'number', unit: '%', rule: 'Use when previous year sales is blank; above −100', min: -100, minExclusive: true, max: 1000, aliases: ['sales_growth', 'growth', 'growth_pct', 'yoy_growth', 'sales_growth_percent'] },
  { key: 'inventory_units', label: 'Inventory units', kind: 'number', unit: 'vehicles', rule: '0 or more', min: 0, aliases: ['inventory', 'stock', 'stock_units', 'inventory_count'] },
  { key: 'inventory_age_days', label: 'Inventory age', kind: 'number', unit: 'days', rule: '0 or more', min: 0, aliases: ['inventory_age', 'inventory_ageing', 'inventory_aging', 'stock_age', 'inventory_ageing_days', 'avg_inventory_age'] },
  { key: 'payment_delay_days', label: 'Payment delay', kind: 'number', unit: 'days', rule: '0 or more', min: 0, aliases: ['payment_delay', 'payment_delays', 'overdue_days', 'days_overdue'] },
  { key: 'service_performance', label: 'Service performance', kind: 'number', unit: 'index 0–100', rule: '0 to 100', min: 0, max: 100, aliases: ['service', 'service_score', 'service_index', 'csi'] },
  { key: 'customer_complaints', label: 'Customer complaints', kind: 'number', unit: 'count', rule: '0 or more', min: 0, aliases: ['complaints', 'complaint_count'] },
  { key: 'vehicles_sold', label: 'Vehicles sold', kind: 'number', unit: 'units', rule: 'Greater than 0', min: 0, minExclusive: true, aliases: ['units_sold', 'volume', 'retail_units', 'units'] },
  { key: 'market_potential', label: 'Market potential', kind: 'number', unit: 'index 0–100', rule: '0 to 100', min: 0, max: 100, aliases: ['market_potential_index', 'potential'] },
  { key: 'market_growth', label: 'Market growth', kind: 'number', unit: '%', rule: 'Above −100', min: -100, minExclusive: true, max: 1000, aliases: ['market_growth_pct', 'local_market_growth'] },
];

// Optional diagnostic fields: unlock deeper root-cause analysis when supplied. Never required, never filled in.
export const OPTIONAL_FIELDS: FieldSpec[] = [
  { key: 'product_category', label: 'Product category', kind: 'text', unit: '', rule: 'Text, e.g. SUV, EV', optional: true, aliases: ['category', 'product_line', 'segment'] },
  { key: 'product_complaint_rate', label: 'Product complaint rate', kind: 'number', unit: 'per 100 vehicles', rule: '0 or more', min: 0, optional: true, aliases: ['product_complaints', 'product_complaints_per_100'] },
  { key: 'product_damage_rate', label: 'Product damage rate', kind: 'number', unit: '% of deliveries', rule: '0 to 100', min: 0, max: 100, optional: true, aliases: ['damage_rate', 'transit_damage_rate', 'damage_pct'] },
  { key: 'transport_complaint_rate', label: 'Transport complaint rate', kind: 'number', unit: 'per 100 vehicles', rule: '0 or more', min: 0, optional: true, aliases: ['transport_complaints', 'logistics_complaint_rate'] },
  { key: 'delivery_delay_days', label: 'Delivery delay', kind: 'number', unit: 'days', rule: '0 or more', min: 0, optional: true, aliases: ['delivery_delay', 'transit_delay'] },
  { key: 'storage_age_days', label: 'Storage age', kind: 'number', unit: 'days', rule: '0 or more', min: 0, optional: true, aliases: ['warehouse_age', 'storage_age', 'warehouse_storage_age'] },
  { key: 'lead_volume', label: 'Lead volume', kind: 'number', unit: 'leads / year', rule: '0 or more', min: 0, optional: true, aliases: ['leads', 'enquiries', 'enquiry_volume'] },
  { key: 'conversion_rate', label: 'Conversion rate', kind: 'number', unit: '%', rule: '0 to 100', min: 0, max: 100, optional: true, aliases: ['conversion', 'lead_conversion', 'conversion_pct'] },
  { key: 'competitor_price_index', label: 'Competitor price index', kind: 'number', unit: '100 = parity', rule: 'Greater than 0', min: 0, minExclusive: true, optional: true, aliases: ['competitor_price', 'comp_price_index'] },
  { key: 'competitor_market_share', label: 'Competitor market share', kind: 'number', unit: '%', rule: '0 to 100', min: 0, max: 100, optional: true, aliases: ['competitor_share', 'comp_share'] },
  { key: 'competitor_share_change', label: 'Competitor share change', kind: 'number', unit: 'pts YoY', rule: '−100 to 100', min: -100, max: 100, optional: true, aliases: ['competitor_share_change_pts', 'comp_share_change'] },
  { key: 'competitor_promotion_index', label: 'Competitor promotion index', kind: 'number', unit: '100 = parity', rule: '0 or more', min: 0, optional: true, aliases: ['competitor_promotions', 'comp_promo_index'] },
  { key: 'sales_rep_performance', label: 'Sales representative performance', kind: 'number', unit: 'index 0–100', rule: '0 to 100', min: 0, max: 100, optional: true, aliases: ['sales_rep_score', 'sales_team_performance', 'rep_performance'] },
  { key: 'service_resolution_days', label: 'Service resolution time', kind: 'number', unit: 'days', rule: '0 or more', min: 0, optional: true, aliases: ['resolution_time', 'complaint_resolution_days', 'service_resolution_time'] },
  // Previous-period values: enable "What changed?" — never estimated when absent
  { key: 'prev_inventory_age_days', label: 'Previous inventory age', kind: 'number', unit: 'days', rule: '0 or more', min: 0, optional: true, group: 'history', aliases: ['previous_inventory_age', 'inventory_age_prev', 'last_period_inventory_age'] },
  { key: 'prev_payment_delay_days', label: 'Previous payment delay', kind: 'number', unit: 'days', rule: '0 or more', min: 0, optional: true, group: 'history', aliases: ['previous_payment_delay', 'payment_delay_prev'] },
  { key: 'prev_complaints_per_100', label: 'Previous complaints per 100', kind: 'number', unit: 'per 100 vehicles', rule: '0 or more', min: 0, optional: true, group: 'history', aliases: ['previous_complaint_rate', 'complaints_per_100_prev', 'prev_complaint_rate'] },
  { key: 'prev_service_performance', label: 'Previous service performance', kind: 'number', unit: 'index 0–100', rule: '0 to 100', min: 0, max: 100, optional: true, group: 'history', aliases: ['previous_service_performance', 'service_performance_prev'] },
];
for (const f of OPTIONAL_FIELDS) if (!f.group) f.group = 'diagnostic';
const ALL_FIELDS = [...FIELDS, ...OPTIONAL_FIELDS];

const fieldByKey = new Map(ALL_FIELDS.map((f) => [f.key, f]));

export function normalizeHeader(h: unknown): string {
  return String(h ?? '')
    .toLowerCase()
    .replace(/\(.*?\)|\[.*?\]/g, ' ') // drop units like "(days)" or "[₹ Cr]"
    .replace(/%/g, ' pct ')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

const HEADER_LOOKUP = new Map<string, FieldSpec>();
for (const f of ALL_FIELDS) {
  HEADER_LOOKUP.set(normalizeHeader(f.key), f);
  HEADER_LOOKUP.set(normalizeHeader(f.label), f);
  for (const a of f.aliases) HEADER_LOOKUP.set(normalizeHeader(a), f);
}

export function parseNumber(v: unknown): number | null {
  if (v === null || v === undefined) return null;
  if (typeof v === 'number') return Number.isFinite(v) ? v : NaN;
  const s = String(v).trim();
  if (s === '' || /^(na|n\/a|null|-|—)$/i.test(s)) return null;
  const cleaned = s.replace(/[₹,\s%]|rs\.?|inr|cr/gi, '');
  if (!/^[-+]?(\d+\.?\d*|\.\d+)$/.test(cleaned)) return NaN;
  return Number(cleaned);
}

// ───────────────────────────── Analysis ─────────────────────────────

export interface Issue {
  row: number; // 1-based spreadsheet row (header = row 1)
  field: string;
  message: string;
  kind: string; // grouping key for the summary
}

export interface RowResult {
  row: number;
  raw: Record<string, string>;
  dealer: Dealer | null;
  errors: Issue[];
  warnings: Issue[];
}

export interface ImportReport {
  fileName: string;
  headerRow: string[];
  mapping: { field: FieldSpec; header: string }[];
  ignoredColumns: string[];
  missingColumns: FieldSpec[];
  growthFromPct: boolean;
  skippedRows: number; // guidance / example rows starting with '#'
  optionalFound: FieldSpec[];
  rows: RowResult[];
  validCount: number;
  invalidCount: number;
  warningCount: number;
  summary: { tone: 'error' | 'warning'; text: string }[];
  dealers: Dealer[];
  canImport: boolean;
}

const r1 = (n: number) => Math.round(n * 10) / 10;
/** Template example rows: importable for testing, never presented as real dealers. */
export const EXAMPLE_ID = /^EXAMPLE-/i;
const isBlankRow = (r: unknown[]) => r.every((c) => String(c ?? '').trim() === '');

/** Analyse a table (array of rows; first non-empty row is the header). Pure — no I/O. */
export function analyzeTable(table: unknown[][], fileName: string): ImportReport {
  const nonEmpty = table.filter((r) => Array.isArray(r) && !isBlankRow(r));
  const headerIdx = table.findIndex((r) => Array.isArray(r) && !isBlankRow(r));
  const headerRow = (nonEmpty[0] ?? []).map((h) => String(h ?? '').trim());

  // Map columns
  const colFor = new Map<string, number>();
  const mapping: ImportReport['mapping'] = [];
  const ignoredColumns: string[] = [];
  headerRow.forEach((h, i) => {
    const f = HEADER_LOOKUP.get(normalizeHeader(h));
    if (f && !colFor.has(f.key)) {
      colFor.set(f.key, i);
      mapping.push({ field: f, header: h });
    } else if (h) ignoredColumns.push(h);
  });

  const hasPrev = colFor.has('previous_year_sales');
  const hasGrowth = colFor.has('sales_growth_pct');
  const missingColumns = FIELDS.filter((f) => {
    if (f.key === 'sales_growth_pct') return false;
    if (f.key === 'previous_year_sales') return !hasPrev && !hasGrowth;
    return !colFor.has(f.key);
  });
  const growthFromPct = !hasPrev && hasGrowth;

  const rows: RowResult[] = [];
  const seenIds = new Map<string, number>();
  let skippedRows = 0;
  const idCol = colFor.get('dealer_id');

  if (missingColumns.length === 0) {
    table.forEach((r, idx) => {
      if (idx <= headerIdx || !Array.isArray(r) || isBlankRow(r)) return;
      // Rows whose Dealer ID starts with '#' are template guidance or examples — never imported
      if (idCol !== undefined && String(r[idCol] ?? '').trim().startsWith('#')) { skippedRows++; return; }
      const rowNum = idx + 1;
      const errors: Issue[] = [];
      const warnings: Issue[] = [];
      const raw: Record<string, string> = {};
      const val: Record<string, string | number> = {};

      for (const [key, col] of colFor) {
        const f = fieldByKey.get(key as FieldSpec['key'])!;
        const cell = r[col];
        raw[key] = String(cell ?? '').trim();
        // Previous-year sales wins; if blank on this row and a growth % column exists, growth % is used instead
        const prevBlank = hasPrev && String(r[colFor.get('previous_year_sales')!] ?? '').trim() === '';
        if (key === 'sales_growth_pct' && hasPrev && !(prevBlank && hasGrowth)) continue;
        if (key === 'previous_year_sales' && (!hasPrev || (prevBlank && hasGrowth))) continue;
        if (f.optional && raw[key] === '') continue; // blank optional cell = not available; never filled in
        if (f.kind === 'text') {
          if (!raw[key]) errors.push({ row: rowNum, field: f.label, kind: `missing:${f.label}`, message: `${f.label} is empty` });
          else val[key] = raw[key];
          continue;
        }
        const n = parseNumber(cell);
        if (n === null) {
          errors.push({ row: rowNum, field: f.label, kind: `missing:${f.label}`, message: `${f.label} is empty` });
        } else if (Number.isNaN(n)) {
          errors.push({ row: rowNum, field: f.label, kind: `nan:${f.label}`, message: `${f.label} "${raw[key]}" is not a number` });
        } else if (f.min !== undefined && (f.minExclusive ? n <= f.min : n < f.min)) {
          errors.push({ row: rowNum, field: f.label, kind: `range:${f.label}`, message: `${f.label} ${n} is out of range (${f.rule.toLowerCase()})` });
        } else if (f.max !== undefined && n > f.max) {
          errors.push({ row: rowNum, field: f.label, kind: `range:${f.label}`, message: `${f.label} ${n} is out of range (${f.rule.toLowerCase()})` });
        } else val[key] = n;
      }

      const id = typeof val.dealer_id === 'string' ? val.dealer_id : '';
      if (id) {
        if (seenIds.has(id)) {
          errors.push({ row: rowNum, field: 'Dealer ID', kind: 'duplicate', message: `Dealer ID ${id} duplicates row ${seenIds.get(id)}` });
        } else seenIds.set(id, rowNum);
      }

      let dealer: Dealer | null = null;
      if (errors.length === 0) {
        const actual = val.actual_sales as number;
        const useGrowth = val.previous_year_sales === undefined && val.sales_growth_pct !== undefined;
        const prev = useGrowth ? r1(actual / (1 + (val.sales_growth_pct as number) / 100)) : (val.previous_year_sales as number);
        if (prev <= 0) {
          errors.push({ row: rowNum, field: 'Previous year sales', kind: 'range:Previous year sales', message: 'Previous year sales must be greater than 0 to calculate growth' });
        } else {
          dealer = {
            dealer_id: id,
            dealer_name: val.dealer_name as string,
            region: val.region as string,
            city: val.city as string,
            sales_target: val.sales_target as number,
            actual_sales: actual,
            previous_year_sales: prev,
            inventory_units: val.inventory_units as number,
            inventory_age_days: val.inventory_age_days as number,
            payment_delay_days: val.payment_delay_days as number,
            service_performance: val.service_performance as number,
            customer_complaints: val.customer_complaints as number,
            vehicles_sold: val.vehicles_sold as number,
            market_potential: val.market_potential as number,
            market_growth: val.market_growth as number,
          };
          for (const k of [...DIAGNOSTIC_KEYS, ...HISTORY_KEYS]) if (val[k] !== undefined) (dealer as unknown as Record<DiagnosticKey | HistoryKey, unknown>)[k] = val[k];
          // Plausibility checks: imported, but flagged for the user to double-check
          const ach = (actual / dealer.sales_target) * 100;
          if (ach > 200 || ach < 10)
            warnings.push({ row: rowNum, field: 'Sales', kind: 'w:ach', message: `Sales achievement of ${Math.round(ach)}% looks unusual — check target and sales units` });
          if (dealer.customer_complaints > dealer.vehicles_sold)
            warnings.push({ row: rowNum, field: 'Customer complaints', kind: 'w:complaints', message: 'More complaints than vehicles sold' });
          if (dealer.inventory_age_days > 365)
            warnings.push({ row: rowNum, field: 'Inventory age', kind: 'w:age', message: `Inventory age of ${dealer.inventory_age_days} days is above a year` });
          if (EXAMPLE_ID.test(dealer.dealer_id))
            warnings.push({ row: rowNum, field: 'Dealer ID', kind: 'w:example', message: 'Template example row (synthetic) — replace with your own dealer data' });
          if (dealer.payment_delay_days > 180)
            warnings.push({ row: rowNum, field: 'Payment delay', kind: 'w:delay', message: `Payment delay of ${dealer.payment_delay_days} days is above six months` });
        }
      }
      if (errors.length) dealer = null;
      rows.push({ row: rowNum, raw, dealer, errors, warnings });
    });
  }

  const validCount = rows.filter((r) => r.dealer).length;
  const invalidCount = rows.length - validCount;
  const warningCount = rows.filter((r) => r.dealer && r.warnings.length).length;

  // Grouped, human-readable summary
  const summary: ImportReport['summary'] = [];
  if (headerRow.some(Boolean) && mapping.length < 3)
    summary.push({ tone: 'error', text: 'The header row was not recognised. Check that the file is a comma-separated CSV (not semicolon- or tab-separated) or an Excel sheet, with the column names in the first row. Download the Data Template for the expected format.' });
  if (missingColumns.length)
    summary.push({ tone: 'error', text: `Missing required column${missingColumns.length > 1 ? 's' : ''}: ${missingColumns.map((f) => f.label).join(', ')}` });
  const group = (issues: Issue[], tone: 'error' | 'warning') => {
    const byKind = new Map<string, Set<number>>();
    const label = new Map<string, string>();
    for (const i of issues) {
      if (!byKind.has(i.kind)) byKind.set(i.kind, new Set());
      byKind.get(i.kind)!.add(i.row);
      label.set(i.kind, i.field);
    }
    for (const [kind, rowsSet] of byKind) {
      const n = rowsSet.size;
      const rs = `${n} row${n > 1 ? 's' : ''}`;
      const f = label.get(kind)!.toLowerCase();
      const text = kind.startsWith('missing:') ? `${rs} ${n > 1 ? 'have' : 'has'} missing ${f}`
        : kind.startsWith('nan:') ? `${rs} ${n > 1 ? 'have' : 'has'} a non-numeric ${f}`
        : kind.startsWith('range:') ? `${rs} ${n > 1 ? 'have' : 'has'} ${f} out of range`
        : kind === 'duplicate' ? `${rs} ${n > 1 ? 'repeat' : 'repeats'} a Dealer ID already used`
        : kind === 'w:ach' ? `${rs} ${n > 1 ? 'have' : 'has'} unusual sales achievement`
        : kind === 'w:complaints' ? `${rs} ${n > 1 ? 'report' : 'reports'} more complaints than vehicles sold`
        : kind === 'w:age' ? `${rs} ${n > 1 ? 'have' : 'has'} inventory older than a year`
        : kind === 'w:example' ? `${rs} ${n > 1 ? 'are template example rows' : 'is a template example row'} (synthetic) — replace with your own dealer data`
        : `${rs} ${n > 1 ? 'have' : 'has'} payment delays above six months`;
      summary.push({ tone, text: `${text} (row${n > 1 ? 's' : ''} ${[...rowsSet].slice(0, 6).join(', ')}${n > 6 ? '…' : ''})` });
    }
  };
  group(rows.flatMap((r) => r.errors), 'error');
  group(rows.filter((r) => r.dealer).flatMap((r) => r.warnings), 'warning');
  if (headerRow.length && missingColumns.length === 0 && rows.length === 0)
    summary.push({ tone: 'error', text: skippedRows ? `No dealer rows yet — the ${skippedRows} rows starting with # are template guidance/examples and are skipped. Add one row per dealer.` : 'The file has a header row but no dealer rows' });
  if (!headerRow.length) summary.push({ tone: 'error', text: 'The file is empty' });

  return {
    fileName,
    headerRow,
    mapping,
    ignoredColumns,
    missingColumns,
    growthFromPct,
    skippedRows,
    optionalFound: OPTIONAL_FIELDS.filter((f) => colFor.has(f.key)),
    rows,
    validCount,
    invalidCount,
    warningCount,
    summary,
    dealers: rows.flatMap((r) => (r.dealer ? [r.dealer] : [])),
    canImport: missingColumns.length === 0 && rows.length > 0 && invalidCount === 0,
  };
}

/** Read a CSV or Excel file into a table. SheetJS is loaded on demand. */
export async function readFileToTable(file: File): Promise<unknown[][]> {
  const XLSX = await import('xlsx');
  const isCsv = /\.(csv|txt)$/i.test(file.name) || file.type === 'text/csv';
  const wb = isCsv
    ? XLSX.read(await file.text(), { type: 'string', raw: true })
    : XLSX.read(await file.arrayBuffer(), { type: 'array' });
  const sheet = wb.Sheets[wb.SheetNames[0]];
  if (!sheet) return [];
  return XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, defval: '', blankrows: false });
}

/** CSV in the import schema, e.g. the synthetic dataset as a ready-made template. */
export function toCsv(dealers: Dealer[]): string {
  const keys: (keyof Dealer)[] = [
    'dealer_id', 'dealer_name', 'region', 'city', 'sales_target', 'actual_sales', 'previous_year_sales', 'inventory_units',
    'inventory_age_days', 'payment_delay_days', 'service_performance', 'customer_complaints', 'vehicles_sold', 'market_potential', 'market_growth',
  ];
  for (const k of [...DIAGNOSTIC_KEYS, ...HISTORY_KEYS]) if (dealers.some((d) => d[k] !== undefined)) keys.push(k);
  const esc = (v: unknown) => (/[",\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : String(v));
  return [keys.join(','), ...dealers.map((d) => keys.map((k) => esc(d[k] ?? '')).join(','))].join('\n');
}

// ───────────────────────────── Data template ─────────────────────────────
// Header = the importer's exact internal field names (core, then optional), so the file
// round-trips without any mapping. Rows starting with '#' are guidance/examples: the
// importer skips them. Example rows (EXAMPLE-xx) import, but always carry a warning.
export function buildTemplateCsv(): string {
  const all = [...FIELDS, ...OPTIONAL_FIELDS];
  const esc = (v: unknown) => (/[",\n]/.test(String(v)) ? `"${String(v).replace(/"/g, '""')}"` : String(v));
  const kind = (f: FieldSpec) =>
    f.key === 'sales_growth_pct' ? 'REQUIRED if previous_year_sales is blank' : !f.optional ? 'REQUIRED' : f.group === 'history' ? 'optional (what changed)' : 'optional (diagnostic)';
  const guide = all.map((f, i) => (i === 0 ? '# FIELD TYPE →' : kind(f)));
  const units = all.map((f, i) => (i === 0 ? '# UNIT / RULE →' : [f.unit, f.rule].filter(Boolean).join(' · ')));
  // Example rows are importable so the template round-trips as-is, but they are unmistakably
  // labelled and the importer warns about them (see EXAMPLE_ID below).
  const blankOptional = OPTIONAL_FIELDS.map(() => '');
  const ex: (string | number)[][] = [
    // A: all fields incl. diagnostic + previous-period values
    ['EXAMPLE-01', 'Example Dealer A (synthetic example)', 'West', 'Pune', 100, 92, 85, '', 120, 48, 6, 84, 30, 1100, 72, 7,
     'SUV', 1.1, 0.8, 0.5, 2, 52, 5200, 21, 99, 27, 0.4, 102, 78, 3.5, 44, 5, 2.4, 86],
    // B: core only, sales growth % instead of previous-year sales, optional fields blank
    ['EXAMPLE-02', 'Example Dealer B (synthetic example)', 'North', 'Jaipur', 60, 48, '', -8, 90, 66, 18, 74, 41, 600, 80, 8, ...blankOptional],
    // C: core + a few optional fields; the rest blank
    ['EXAMPLE-03', 'Example Dealer C (synthetic example)', 'South', 'Chennai', 80, 83, 76, '', 95, 40, 3, 90, 15, 900, 65, 6,
     'Sedan', 0.9, '', '', '', '', '', '', '', '', '', '', '', 3.0, '', '', '', ''],
  ];
  return [all.map((f) => f.key), guide, units, ...ex].map((r) => r.map(esc).join(',')).join('\n');
}
